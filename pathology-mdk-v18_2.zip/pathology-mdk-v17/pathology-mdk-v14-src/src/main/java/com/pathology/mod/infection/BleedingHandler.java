package com.pathology.mod.infection;

import com.pathology.mod.util.ProtectionUtil;
import com.pathology.mod.virus.Virus;
import com.pathology.mod.virus.VirusManager;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.*;

/**
 * Bleeding vector:
 *  – Infected mobs emit blood particles continuously (visual).
 *  – Every bleedingIntervalTicks a BloodZone is spawned at their feet (1 block radius).
 *  – BloodZones linger, tick, and infect entities that step in them.
 *    Infection chance: 100% for unarmored; reduced proportionally by armor protection.
 *  – Players who hit a bleeding mob within melee range also roll for infection
 *    (100% base, reduced by armor).
 *  – Direct particle contact (entity inside the bleed-burst radius at spawn time)
 *    also triggers infection at 100% without armor; reduced by armor.
 */
public class BleedingHandler {

    private static final List<BloodZone> ACTIVE_ZONES = new ArrayList<>();
    private static final Random RNG = new Random();
    private static final double BLOOD_ZONE_RADIUS = 1.0; // Constrained to 1 block

    // ── Blood zones ───────────────────────────────────────────────────────────

    public static class BloodZone {
        public final Vec3 pos;
        public final Virus virus;
        public final double radius;
        public int remainingTicks;

        BloodZone(Vec3 pos, Virus virus) {
            this.pos = pos;
            this.virus = virus;
            this.radius = BLOOD_ZONE_RADIUS; // Always 1 block
            this.remainingTicks = virus.getBleedingZoneDurationTicks();
        }

        boolean tick(ServerLevel level) {
            remainingTicks--;
            // Blood particle effect every 8 ticks using DAMAGE_INDICATOR (red particles)
            if (remainingTicks % 8 == 0) {
                for (int i = 0; i < 4; i++) {
                    double ox = (RNG.nextDouble()-0.5)*radius*2;
                    double oz = (RNG.nextDouble()-0.5)*radius*2;
                    level.sendParticles(ParticleTypes.DAMAGE_INDICATOR,
                        pos.x+ox, pos.y+0.05, pos.z+oz, 1, 0,0,0, 0.01);
                }
            }
            // Infection check every 10 ticks.
            // 100% chance if no armor; armor proportionally reduces the chance.
            if (remainingTicks % 10 == 0) {
                AABB box = new AABB(pos.x-radius, pos.y-0.5, pos.z-radius,
                                    pos.x+radius, pos.y+2.0, pos.z+radius);
                for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, box,
                        en -> !VirusManager.isInfected(en, virus.getId()))) {
                    double dist = Math.sqrt(Math.pow(e.getX()-pos.x,2)+Math.pow(e.getZ()-pos.z,2));
                    if (dist > radius) continue;
                    double protection = ProtectionUtil.getProtectionReduction(e);
                    // 100% infection for unarmored; armor reduces chance
                    double chance = 1.0 - protection;
                    if (RNG.nextDouble() < chance)
                        VirusManager.infect(e, virus);
                }
            }
            return remainingTicks > 0;
        }
    }

    // ── Called every bleedingIntervalTicks from ModEvents ────────────────────

    public static void onBleedPulse(LivingEntity source, Virus virus) {
        if (!(source.level() instanceof ServerLevel sl)) return;

        Vec3 srcPos = source.position();
        ACTIVE_ZONES.add(new BloodZone(srcPos, virus));

        // Emit a burst of blood particles at source location
        for (int i = 0; i < 8; i++) {
            double ox = (RNG.nextDouble()-0.5)*0.6;
            double oy = RNG.nextDouble()*1.2;
            double oz = (RNG.nextDouble()-0.5)*0.6;
            sl.sendParticles(ParticleTypes.DAMAGE_INDICATOR,
                source.getX()+ox, source.getY()+oy, source.getZ()+oz, 1, 0,0,0, 0.05);
        }

        // ── Direct particle contact infection at bleed-burst moment ──────────
        // Any entity inside the blood burst radius when the bleed fires is considered
        // to have touched the particles. 100% infection if no armor; armor reduces chance.
        AABB burstBox = new AABB(
            srcPos.x - BLOOD_ZONE_RADIUS, srcPos.y - 0.5, srcPos.z - BLOOD_ZONE_RADIUS,
            srcPos.x + BLOOD_ZONE_RADIUS, srcPos.y + 2.0, srcPos.z + BLOOD_ZONE_RADIUS
        );
        for (LivingEntity e : sl.getEntitiesOfClass(LivingEntity.class, burstBox,
                en -> en != source && !VirusManager.isInfected(en, virus.getId()))) {
            double dist = Math.sqrt(Math.pow(e.getX()-srcPos.x,2)+Math.pow(e.getZ()-srcPos.z,2));
            if (dist > BLOOD_ZONE_RADIUS) continue;
            double protection = ProtectionUtil.getProtectionReduction(e);
            double chance = 1.0 - protection;
            if (RNG.nextDouble() < chance)
                VirusManager.infect(e, virus);
        }
    }

    /** Called when a player hits a bleeding mob at close range. */
    public static void onMeleeContact(LivingEntity attacker, LivingEntity victim, Virus virus) {
        if (VirusManager.isInfected(attacker, virus.getId())) return;
        double protection = ProtectionUtil.getProtectionReduction(attacker);
        // 100% base infection for melee contact with blood; armor reduces chance
        double chance = 1.0 - protection;
        if (RNG.nextDouble() < Math.min(chance, 1.0))
            VirusManager.infect(attacker, virus);
    }

    public static void tickAllZones(ServerLevel level) {
        ACTIVE_ZONES.removeIf(z -> !z.tick(level));
    }

    public static void clearAll() { ACTIVE_ZONES.clear(); }
    public static int activeZoneCount() { return ACTIVE_ZONES.size(); }
}
