package com.pathology.mod.corpse;

import com.pathology.mod.PathologyMod;
import com.pathology.mod.config.CorpseLootConfig;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.phys.Vec3;

import java.util.*;

/**
 * Central manager for all active corpses in a level.
 *
 * v18 changes:
 *  - MAX_PER_CHUNK reduced to 3, MAX_GLOBAL reduced to 50
 *  - Corpses auto-despawn after 1 minute (1200 ticks) without being looted
 *  - INFECTION_CHECK_TICKS raised to 80
 *  - Airborne infection chance halved (BASE_CHANCE 0.025, MAX_CHANCE 0.05)
 */
public class CorpseManager {

    // ── Limits ────────────────────────────────────────────────────────────────
    public static final int    MAX_PER_CHUNK  = 3;
    public static final int    MAX_GLOBAL     = 50;
    public static final double MERGE_RADIUS   = 2.0;

    // ── Decay thresholds ──────────────────────────────────────────────────────
    public static final long DECAY_STAGE_1_TICKS =  6_000L;
    public static final long DECAY_STAGE_2_TICKS = 18_000L;
    public static final long DECAY_DESPAWN_TICKS  = 36_000L;

    /** Ticks without a loot interaction before the corpse auto-despawns (1 minute). */
    public static final long UNLOOT_DESPAWN_TICKS = 1200L;

    // ── Corpse proximity-infection parameters ─────────────────────────────────
    public static final double INFECTION_RADIUS      = 5.0;
    public static final int    FULL_EXPOSURE_TICKS   = 1200;
    /** Base chance per check – halved from v17 (was 0.05). */
    public static final double BASE_CHANCE           = 0.025;
    /** Max chance per check – halved from v17 (was 0.10). */
    public static final double MAX_CHANCE            = 0.05;
    public static final int    INFECTION_CHECK_TICKS = 80;

    // ── State ─────────────────────────────────────────────────────────────────
    private final Map<UUID, CorpseData> corpses        = new LinkedHashMap<>();
    private final Map<UUID, Integer>    exposureTicks  = new HashMap<>();
    private final Map<UUID, Long>       lastLootedTime = new HashMap<>();
    private final Map<UUID, Long>       burningCorpses = new HashMap<>();

    private static final long BURN_DURATION_TICKS = 100L;
    private static final CorpseManager INSTANCE = new CorpseManager();
    public  static CorpseManager get() { return INSTANCE; }
    private CorpseManager() {}
    private static final Random RNG = new Random();

    // ── Public API ────────────────────────────────────────────────────────────

    public UUID addCorpse(ServerLevel level, CorpseData data) {
        if (tryMerge(data)) {
            PathologyMod.LOGGER.debug("Corpse merged into pile at {}", data.deathPos);
            return null;
        }
        long chunkKey = chunkKey(data.deathPos);
        long chunkCount = corpses.values().stream()
            .filter(c -> chunkKey(c.deathPos) == chunkKey).count();
        if (chunkCount >= MAX_PER_CHUNK) removeOldestInChunk(chunkKey);
        if (corpses.size() >= MAX_GLOBAL)  removeOldest();

        UUID id = UUID.randomUUID();
        data.lootItems = CorpseLootConfig.generateLoot(level.random);
        corpses.put(id, data);
        lastLootedTime.put(id, data.deathTime);
        PathologyMod.LOGGER.debug("Corpse added [{}]: {} at {}", id, data.entityTypeId, data.deathPos);
        return id;
    }

    /** Call whenever a player opens the corpse inventory to reset the idle timer. */
    public void markLooted(UUID corpseId, long gameTime) {
        if (corpses.containsKey(corpseId)) lastLootedTime.put(corpseId, gameTime);
    }

    public void destroyByFire(UUID corpseId, ServerLevel level) {
        CorpseData data = corpses.remove(corpseId);
        if (data == null) return;
        lastLootedTime.remove(corpseId);
        burningCorpses.put(corpseId, level.getGameTime());
        PathologyMod.LOGGER.debug("Corpse {} set on fire (data removed)", corpseId);
        level.sendParticles(ParticleTypes.LARGE_SMOKE,
            data.deathPos.x, data.deathPos.y + 0.5, data.deathPos.z, 20, 0.4, 0.5, 0.4, 0.02);
        level.sendParticles(ParticleTypes.FLAME,
            data.deathPos.x, data.deathPos.y + 0.3, data.deathPos.z, 15, 0.3, 0.3, 0.3, 0.02);
    }

    public void remove(UUID corpseId) {
        corpses.remove(corpseId);
        burningCorpses.remove(corpseId);
        lastLootedTime.remove(corpseId);
    }

    public void tick(ServerLevel level) {
        long now = level.getGameTime();
        List<UUID> toRemove = new ArrayList<>();

        for (Map.Entry<UUID, CorpseData> entry : corpses.entrySet()) {
            UUID id = entry.getKey();
            CorpseData d = entry.getValue();
            long age = now - d.deathTime;

            // ── Idle despawn: 1 minute without being looted ────────────────
            long lastLooted = lastLootedTime.getOrDefault(id, d.deathTime);
            if (now - lastLooted >= UNLOOT_DESPAWN_TICKS) {
                toRemove.add(id);
                PathologyMod.LOGGER.debug("Corpse {} auto-despawned (not looted within 1 min)", id);
                continue;
            }

            int oldStage = d.decayStage;
            if      (age >= DECAY_DESPAWN_TICKS) { toRemove.add(id); continue; }
            else if (age >= DECAY_STAGE_2_TICKS) d.decayStage = 2;
            else if (age >= DECAY_STAGE_1_TICKS) d.decayStage = 1;
            if (d.decayStage != oldStage)
                PathologyMod.LOGGER.debug("Corpse decay {} → {} at {}", oldStage, d.decayStage, d.deathPos);
        }

        for (Iterator<Map.Entry<UUID, Long>> it = burningCorpses.entrySet().iterator(); it.hasNext();) {
            Map.Entry<UUID, Long> e = it.next();
            if (now - e.getValue() >= BURN_DURATION_TICKS) {
                it.remove();
                PathologyMod.LOGGER.debug("Burn timer expired for {}", e.getKey());
            }
        }

        toRemove.forEach(id -> {
            corpses.remove(id);
            lastLootedTime.remove(id);
            PathologyMod.LOGGER.debug("Corpse {} removed", id);
        });

        if (now % INFECTION_CHECK_TICKS == 0 && !corpses.isEmpty()) tickCorpseInfection(level, now);
    }

    private void tickCorpseInfection(ServerLevel level, long now) {
        for (net.minecraft.server.level.ServerPlayer player : level.players()) {
            UUID pid = player.getUUID();
            boolean nearCorpse = corpses.values().stream()
                .anyMatch(d -> d.deathPos.distanceTo(player.position()) <= INFECTION_RADIUS);

            if (nearCorpse) {
                int ticks = exposureTicks.getOrDefault(pid, 0) + INFECTION_CHECK_TICKS;
                exposureTicks.put(pid, ticks);
                double t = Math.min(1.0, (double) ticks / FULL_EXPOSURE_TICKS);
                double chance = BASE_CHANCE + t * (MAX_CHANCE - BASE_CHANCE);
                if (RNG.nextDouble() < chance) {
                    com.pathology.mod.virus.VirusRegistry.get("decay_disease")
                        .ifPresent(v -> com.pathology.mod.virus.VirusManager.infect(player, v));
                    com.pathology.mod.virus.VirusRegistry.get("airbornehuskflu")
                        .ifPresent(v -> com.pathology.mod.virus.VirusManager.infect(player, v));
                    exposureTicks.put(pid, 0);
                }
            } else {
                int ticks = exposureTicks.getOrDefault(pid, 0);
                if (ticks > 0) exposureTicks.put(pid, Math.max(0, ticks - INFECTION_CHECK_TICKS));
            }
        }
    }

    // ── Query helpers ─────────────────────────────────────────────────────────
    public Collection<CorpseData> all()        { return Collections.unmodifiableCollection(corpses.values()); }
    public Optional<CorpseData>   get(UUID id) { return Optional.ofNullable(corpses.get(id)); }
    public int                    size()        { return corpses.size(); }
    public boolean                isBurning(UUID id) { return burningCorpses.containsKey(id); }
    public long                   getBurnStartTime(UUID id) { return burningCorpses.getOrDefault(id, -1L); }
    public static long            getBurnDuration() { return BURN_DURATION_TICKS; }

    public Optional<UUID> getUUIDAt(Vec3 pos) {
        return corpses.entrySet().stream()
            .filter(e -> e.getValue().deathPos.distanceTo(pos) < 1.0)
            .map(Map.Entry::getKey).findFirst();
    }

    public void clear() {
        corpses.clear();
        burningCorpses.clear();
        exposureTicks.clear();
        lastLootedTime.clear();
    }

    // ── Persistence ───────────────────────────────────────────────────────────
    public CompoundTag saveAll() {
        CompoundTag root = new CompoundTag();
        ListTag list = new ListTag();
        for (Map.Entry<UUID, CorpseData> e : corpses.entrySet()) {
            CompoundTag entry = e.getValue().save();
            entry.putUUID("corpseId", e.getKey());
            entry.putLong("lastLootedTime", lastLootedTime.getOrDefault(e.getKey(), e.getValue().deathTime));
            list.add(entry);
        }
        root.put("corpses", list);
        return root;
    }

    public void loadAll(CompoundTag root) {
        corpses.clear();
        lastLootedTime.clear();
        if (!root.contains("corpses", Tag.TAG_LIST)) return;
        ListTag list = root.getList("corpses", Tag.TAG_COMPOUND);
        for (int i = 0; i < list.size(); i++) {
            CompoundTag entry = list.getCompound(i);
            UUID id = entry.getUUID("corpseId");
            CorpseData data = CorpseData.load(entry);
            corpses.put(id, data);
            lastLootedTime.put(id, entry.contains("lastLootedTime")
                ? entry.getLong("lastLootedTime") : data.deathTime);
        }
        PathologyMod.LOGGER.info("Loaded {} corpse record(s).", corpses.size());
    }

    // ── Private helpers ───────────────────────────────────────────────────────
    private boolean tryMerge(CorpseData incoming) {
        for (CorpseData existing : corpses.values())
            if (existing.deathPos.distanceTo(incoming.deathPos) <= MERGE_RADIUS) { existing.bodyCount++; return true; }
        return false;
    }

    private void removeOldest() {
        corpses.entrySet().stream().findFirst().map(Map.Entry::getKey)
            .ifPresent(id -> { corpses.remove(id); lastLootedTime.remove(id); });
    }

    private void removeOldestInChunk(long chunkKey) {
        corpses.entrySet().stream().filter(e -> chunkKey(e.getValue().deathPos) == chunkKey)
            .findFirst().map(Map.Entry::getKey)
            .ifPresent(id -> { corpses.remove(id); lastLootedTime.remove(id); });
    }

    private static long chunkKey(Vec3 pos) {
        int cx = (int) Math.floor(pos.x) >> 4;
        int cz = (int) Math.floor(pos.z) >> 4;
        return ((long) cx & 0xFFFFFFFFL) | (((long) cz & 0xFFFFFFFFL) << 32);
    }
}
