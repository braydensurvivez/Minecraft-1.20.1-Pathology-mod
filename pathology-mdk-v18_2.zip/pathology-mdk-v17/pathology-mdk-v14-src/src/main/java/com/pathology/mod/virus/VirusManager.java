package com.pathology.mod.virus;

import com.pathology.mod.PathologyMod;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;

import java.util.*;
import java.util.HashSet;
import java.util.Set;

public class VirusManager {

    private static final String NBT_KEY = "pathologymod_infections";
    private static final Map<UUID, Map<String, InfectionRecord>> INFECTIONS = new HashMap<>();

    /**
     * Entities marked as carriers spread viruses normally but do NOT advance
     * through infection stages, preventing spawn-infected mobs from dying to
     * their own infections.
     */
    private static final Set<UUID> CARRIERS = new HashSet<>();

    private VirusManager() {}

    public static void markCarrier(LivingEntity entity) { CARRIERS.add(entity.getUUID()); }
    public static boolean isCarrier(LivingEntity entity) { return CARRIERS.contains(entity.getUUID()); }

    public static class InfectionRecord {
        public final Virus virus;
        public int currentStage;
        public int ticksInStage;
        /** True once hordes:infected MobEffect has been applied for this infection's final stage. */
        public boolean hordesEffectApplied;

        public InfectionRecord(Virus virus) {
            this.virus = virus;
            this.currentStage = 0;
            this.ticksInStage = 0;
            this.hordesEffectApplied = false;
        }

        public InfectionRecord(Virus virus, int stage, int ticks) {
            this.virus = virus;
            this.currentStage = stage;
            this.ticksInStage = ticks;
            this.hordesEffectApplied = false;
        }
    }

    // ── NBT persistence ───────────────────────────────────────────────────────

    /** Save all infections for this entity into its PersistentData NBT. */
    public static void saveToNBT(LivingEntity entity) {
        Map<String, InfectionRecord> map = INFECTIONS.get(entity.getUUID());
        CompoundTag persistent = entity.getPersistentData();
        if (map == null || map.isEmpty()) {
            persistent.remove(NBT_KEY);
            return;
        }
        ListTag list = new ListTag();
        for (InfectionRecord rec : map.values()) {
            CompoundTag tag = new CompoundTag();
            tag.putString("virusId", rec.virus.getId());
            tag.putInt("stage", rec.currentStage);
            tag.putInt("ticks", rec.ticksInStage);
            list.add(tag);
        }
        persistent.put(NBT_KEY, list);
    }

    /** Load infections for this entity from its PersistentData NBT. */
    public static void loadFromNBT(LivingEntity entity) {
        CompoundTag persistent = entity.getPersistentData();
        if (!persistent.contains(NBT_KEY, Tag.TAG_LIST)) return;
        ListTag list = persistent.getList(NBT_KEY, Tag.TAG_COMPOUND);
        if (list.isEmpty()) return;
        Map<String, InfectionRecord> map = INFECTIONS.computeIfAbsent(entity.getUUID(), k -> new HashMap<>());
        for (int i = 0; i < list.size(); i++) {
            CompoundTag tag = list.getCompound(i);
            String virusId = tag.getString("virusId");
            int stage = tag.getInt("stage");
            int ticks = tag.getInt("ticks");
            VirusRegistry.get(virusId).ifPresent(virus -> {
                if (!map.containsKey(virusId)) {
                    map.put(virusId, new InfectionRecord(virus, stage, ticks));
                    PathologyMod.LOGGER.debug("Loaded infection {} for entity {}", virusId, entity.getUUID());
                }
            });
        }
    }

    // ── Standard API ──────────────────────────────────────────────────────────

    public static boolean isInfected(LivingEntity entity, String virusId) {
        Map<String, InfectionRecord> map = INFECTIONS.get(entity.getUUID());
        return map != null && map.containsKey(virusId);
    }

    public static boolean isInfectedByAny(LivingEntity entity) {
        Map<String, InfectionRecord> map = INFECTIONS.get(entity.getUUID());
        return map != null && !map.isEmpty();
    }

    public static void infect(LivingEntity entity, Virus virus) {
        if (isInfected(entity, virus.getId())) return;
        INFECTIONS.computeIfAbsent(entity.getUUID(), k -> new HashMap<>())
                  .put(virus.getId(), new InfectionRecord(virus));
        saveToNBT(entity);
        PathologyMod.LOGGER.debug("Entity {} infected with {}", entity.getUUID(), virus.getId());
    }

    public static void cure(LivingEntity entity, String virusId) {
        Map<String, InfectionRecord> map = INFECTIONS.get(entity.getUUID());
        if (map != null) {
            InfectionRecord rec = map.remove(virusId);
            // Clear all MobEffects that were applied by the stages of this virus
            if (rec != null) {
                for (InfectionStage stage : rec.virus.getStages()) {
                    for (InfectionStage.StagedEffect se : stage.getEffects()) {
                        net.minecraft.world.effect.MobEffect resolved = se.getEffect();
                        if (resolved != null) {
                            entity.removeEffect(resolved);
                        }
                    }
                }
            }
            if (map.isEmpty()) INFECTIONS.remove(entity.getUUID());
        }
        // Remove the hordes:infected MobEffect if no remaining virus at final stage still needs it
        boolean anyHordesVirus = false;
        Map<String, InfectionRecord> remaining = INFECTIONS.get(entity.getUUID());
        if (remaining != null) {
            for (InfectionRecord r : remaining.values()) {
                String id = r.virus.getId();
                if ((id.equals("airbornehuskflu") || id.equals("bloodbornehuskvirus"))
                        && r.hordesEffectApplied) {
                    anyHordesVirus = true;
                    break;
                }
            }
        }
        if (!anyHordesVirus) {
            net.minecraft.world.effect.MobEffect hordesEffect =
                net.minecraftforge.registries.ForgeRegistries.MOB_EFFECTS.getValue(
                    new net.minecraft.resources.ResourceLocation("hordes", "infected"));
            if (hordesEffect != null) {
                entity.removeEffect(hordesEffect);
            }
            // Also clear the NBT tag in case it was set by older versions
            entity.getPersistentData().remove("hordes:infected");
        }
        saveToNBT(entity);
    }

    public static Collection<InfectionRecord> getInfections(LivingEntity entity) {
        Map<String, InfectionRecord> map = INFECTIONS.get(entity.getUUID());
        return map == null ? Collections.emptyList() : new ArrayList<>(map.values());
    }

    public static InfectionRecord getRecord(LivingEntity entity, String virusId) {
        Map<String, InfectionRecord> map = INFECTIONS.get(entity.getUUID());
        return map == null ? null : map.get(virusId);
    }

    public static void tick(LivingEntity entity) {
        Map<String, InfectionRecord> map = INFECTIONS.get(entity.getUUID());
        if (map == null || map.isEmpty()) return;

        // Carriers spread the virus but do not advance stages or suffer effects.
        if (CARRIERS.contains(entity.getUUID())) return;

        List<String> toRemove = new ArrayList<>();
        boolean changed = false;

        for (Map.Entry<String, InfectionRecord> entry : map.entrySet()) {
            InfectionRecord record = entry.getValue();
            Virus virus = record.virus;
            List<InfectionStage> stages = virus.getStages();

            if (record.currentStage >= stages.size()) { toRemove.add(entry.getKey()); continue; }

            InfectionStage stage = stages.get(record.currentStage);

            // Reapply effects every 60 ticks with a 70-tick duration.
            // The 10-tick overlap prevents flickering while still allowing
            // effects to fully expire between cycles — this is especially
            // important for MobEffects.HUNGER, which drains food continuously;
            // applying it every 20t with 40t duration kept it permanently active.
            if (record.ticksInStage % 60 == 0) {
                for (InfectionStage.StagedEffect se : stage.getEffects()) {
                    // hordes:infected is applied only once and left for the Hordes mod to manage.
                    boolean isHordesInfected = "hordes:infected".equals(se.getEffectId());
                    if (isHordesInfected && record.hordesEffectApplied) continue;

                    // getEffect() resolves through ForgeRegistries, covering all mods.
                    // Returns null only if the providing mod is not loaded – skip gracefully.
                    MobEffect resolved = se.getEffect();
                    if (resolved == null) {
                        PathologyMod.LOGGER.warn(
                            "Pathology: effect '{}' not found in ForgeRegistries (mod not loaded?), skipping.",
                            se.getEffectId());
                        continue;
                    }
                    // Apply with visible=false so potion effect particles are hidden on mobs.
                    // hordes:infected is applied with no explicit duration (0) so the Hordes
                    // mod fills in the duration from its own config, matching /effect give behaviour.
                    if (isHordesInfected) {
                        entity.addEffect(new MobEffectInstance(resolved, 0, se.getAmplifier(), false, true));
                        record.hordesEffectApplied = true;
                    } else {
                        entity.addEffect(new MobEffectInstance(resolved, 70, se.getAmplifier(), false, false));
                    }
                }
            }

            record.ticksInStage++;

            if (record.ticksInStage >= stage.getDurationTicks()) {
                boolean isPermanent = virus.getId().equals("bloodbornehuskvirus") || virus.getId().equals("airbornehuskflu");
                boolean isLastStage = (record.currentStage >= stages.size() - 1);
                if (isPermanent && isLastStage) {
                    record.ticksInStage = 0;
                    changed = true;
                } else {
                    record.currentStage++;
                    record.ticksInStage = 0;
                    changed = true;
                    if (record.currentStage >= stages.size()) {
                        PathologyMod.LOGGER.debug("Entity {} recovered from {}", entity.getUUID(), virus.getId());
                        toRemove.add(entry.getKey());
                    } else {
                        PathologyMod.LOGGER.debug("Entity {} -> stage {} of {}", entity.getUUID(), record.currentStage, virus.getId());
                    }
                }
            }
        }

        toRemove.forEach(map::remove);
        if (map.isEmpty()) INFECTIONS.remove(entity.getUUID());

        // Persist every 100 ticks (~5 seconds) or on stage change
        if (changed || entity.tickCount % 100 == 0) {
            saveToNBT(entity);
        }
    }
}
