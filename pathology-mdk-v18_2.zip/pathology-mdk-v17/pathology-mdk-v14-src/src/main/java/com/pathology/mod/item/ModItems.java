package com.pathology.mod.item;

import com.pathology.mod.PathologyMod;
import net.minecraft.world.item.Item;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModItems {

    public static final DeferredRegister<Item> ITEMS =
        DeferredRegister.create(ForgeRegistries.ITEMS, PathologyMod.MOD_ID);

    /** Pathogen Syringe: left-click mob to infect, right-click mob for status. */
    public static final RegistryObject<Item> PATHOGEN_SYRINGE =
        ITEMS.register("pathogen_syringe",
            () -> new PathogenSyringeItem(new Item.Properties().stacksTo(1)));

    /**
     * Virus Vial: throwable glass vial filled with a virus.
     */
    public static final RegistryObject<Item> VIRUS_VIAL =
        ITEMS.register("virus_vial",
            () -> new VirusVialItem(new Item.Properties().stacksTo(16)));

    /**
     * Body Bag: allows picking up and placing corpse entities.
     * Right-click near a corpse to store it; right-click again to place.
     * Holds exactly one corpse at a time.
     * Appears in the Pathology creative tab.
     */
    public static final RegistryObject<Item> BODY_BAG =
        ITEMS.register("body_bag",
            () -> new BodyBagItem(new Item.Properties().stacksTo(1)));

    /** Digital Thermometer: right-click entity to detect fever viruses. */
    public static final RegistryObject<Item> DIGITAL_THERMOMETER =
        ITEMS.register("digital_thermometer",
            () -> new DigitalThermometerItem(new Item.Properties().stacksTo(1)));

    /** Field Assessment Kit: right-click entity; 60-second delay then reveals infection + stage. */
    public static final RegistryObject<Item> FIELD_ASSESSMENT_KIT =
        ITEMS.register("field_assessment_kit",
            () -> new FieldAssessmentKitItem(new Item.Properties().stacksTo(1)));
}
