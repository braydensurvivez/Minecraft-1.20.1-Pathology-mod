package com.pathology.mod.entity;

import com.pathology.mod.corpse.CorpseData;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraftforge.network.NetworkHooks;

import java.util.UUID;

/**
 * CorpseEntity v14 — fully interactive corpse container.
 *
 * Fix list vs v13:
 *  - Inventory expanded to 27 slots so ChestMenu.threeRows() works correctly.
 *    Previously 9 slots caused the chest GUI to silently fail / show blank rows.
 *  - interact() now returns CONSUME on the server so vanilla does not double-fire
 *    and ModEvents.onPlayerRightClickEntity gets a clean first shot.
 *  - canBeCollidedWith() / isPickable() / getPickRadius() unchanged (still true).
 *  - setInvulnerable(true) kept; fire ignition is handled via Forge event, not
 *    vanilla damage.
 */
public class CorpseEntity extends Entity {

    // ── Synced data keys ──────────────────────────────────────────────────────
    public static final EntityDataAccessor<String>  ENTITY_TYPE_ID =
            SynchedEntityData.defineId(CorpseEntity.class, EntityDataSerializers.STRING);
    public static final EntityDataAccessor<Integer> DECAY_STAGE =
            SynchedEntityData.defineId(CorpseEntity.class, EntityDataSerializers.INT);
    public static final EntityDataAccessor<Integer> BODY_COUNT =
            SynchedEntityData.defineId(CorpseEntity.class, EntityDataSerializers.INT);
    public static final EntityDataAccessor<String>  CORPSE_UUID =
            SynchedEntityData.defineId(CorpseEntity.class, EntityDataSerializers.STRING);
    public static final EntityDataAccessor<Boolean> IS_BURNING =
            SynchedEntityData.defineId(CorpseEntity.class, EntityDataSerializers.BOOLEAN);
    /** 0.0 = just ignited, 1.0 = fully charred / about to despawn. Synced to clients. */
    public static final EntityDataAccessor<Float> BURN_PROGRESS =
            SynchedEntityData.defineId(CorpseEntity.class, EntityDataSerializers.FLOAT);

    // ── Inventory — 27 slots so ChestMenu.threeRows() is satisfied ───────────
    private final SimpleContainer inventory = new SimpleContainer(27);

    // ── Constructor ───────────────────────────────────────────────────────────

    public CorpseEntity(EntityType<?> type, Level level) {
        super(type, level);
        this.noPhysics = true;
        this.setNoGravity(true);
        this.setSilent(true);
        this.setInvulnerable(true);
    }

    // ── Factory helper ────────────────────────────────────────────────────────

    public static CorpseEntity fromData(Level level, CorpseData data, UUID corpseUUID) {
        CorpseEntity e = new CorpseEntity(ModEntityTypes.CORPSE.get(), level);
        e.moveTo(data.deathPos.x, data.deathPos.y, data.deathPos.z, data.yaw, 0f);
        e.getEntityData().set(ENTITY_TYPE_ID, data.entityTypeId);
        e.getEntityData().set(DECAY_STAGE,    data.decayStage);
        e.getEntityData().set(BODY_COUNT,     data.bodyCount);
        e.getEntityData().set(CORPSE_UUID,    corpseUUID.toString());
        e.getEntityData().set(IS_BURNING,     false);
        e.getEntityData().set(BURN_PROGRESS,  0.0f);
        return e;
    }

    // ── SynchedEntityData ─────────────────────────────────────────────────────

    @Override
    protected void defineSynchedData() {
        this.entityData.define(ENTITY_TYPE_ID, "minecraft:zombie");
        this.entityData.define(DECAY_STAGE,    0);
        this.entityData.define(BODY_COUNT,     1);
        this.entityData.define(CORPSE_UUID,    "00000000-0000-0000-0000-000000000000");
        this.entityData.define(IS_BURNING,     false);
        this.entityData.define(BURN_PROGRESS,  0.0f);
    }

    // ── Interaction ───────────────────────────────────────────────────────────

    /**
     * Return CONSUME (server) / SUCCESS (client) so:
     *  1. The click is NOT consumed by vanilla before Forge fires EntityInteract.
     *  2. The hand-swing animation plays on the client.
     *  3. ModEvents.onPlayerRightClickEntity handles all real logic.
     */
    @Override
    public InteractionResult interact(Player player, InteractionHand hand) {
        // CONSUME lets Forge's EntityInteract event fire first on the server.
        // SUCCESS_NO_ITEM_USED plays the swing animation on the client without
        // triggering a second server round-trip.
        return level().isClientSide
                ? InteractionResult.SUCCESS
                : InteractionResult.CONSUME;
    }

    // ── Hit-box / pickability ─────────────────────────────────────────────────

    @Override public boolean isPickable()          { return true; }
    @Override public boolean canBeCollidedWith()   { return true; }
    @Override public float   getPickRadius()       { return 1.0F; }

    // ── Convenience getters / setters ─────────────────────────────────────────

    public String  getEntityTypeId()   { return this.entityData.get(ENTITY_TYPE_ID); }
    public int     getDecayStage()     { return this.entityData.get(DECAY_STAGE); }
    public int     getBodyCount()      { return this.entityData.get(BODY_COUNT); }
    public UUID    getCorpseUUID()     {
        try { return UUID.fromString(this.entityData.get(CORPSE_UUID)); }
        catch (IllegalArgumentException e) { return new UUID(0, 0); }
    }
    public boolean isBurning()         { return this.entityData.get(IS_BURNING); }
    public float   getBurnProgress()   { return this.entityData.get(BURN_PROGRESS); }

    /** Never report as on-fire to vanilla — the vanilla flame overlay is scaled to
     *  the entity bounding box and looks enormous on a flat corpse. We render our
     *  own fire via custom particles in ModEvents instead. */
    @Override
    public boolean isOnFire() { return false; }

    public void setDecayStage(int s)   { this.entityData.set(DECAY_STAGE, s); }
    public void setBodyCount(int n)    { this.entityData.set(BODY_COUNT, n); }
    public void setCorpseUUID(UUID id) { this.entityData.set(CORPSE_UUID, id.toString()); }
    public void setBurning(boolean b)  { this.entityData.set(IS_BURNING, b); }
    public void setBurnProgress(float p) { this.entityData.set(BURN_PROGRESS, Math.max(0f, Math.min(1f, p))); }

    /** Direct access to the 27-slot inventory for loot population and GUI. */
    public SimpleContainer getInventory() { return inventory; }

    // ── NBT ───────────────────────────────────────────────────────────────────

    @Override
    protected void readAdditionalSaveData(CompoundTag tag) {
        this.entityData.set(ENTITY_TYPE_ID, tag.getString("corpseEntityType"));
        this.entityData.set(DECAY_STAGE,    tag.getInt("corpseDecayStage"));
        this.entityData.set(BODY_COUNT,     Math.max(1, tag.getInt("corpseBodyCount")));
        this.entityData.set(IS_BURNING,     tag.getBoolean("corpseIsBurning"));
        this.entityData.set(BURN_PROGRESS,  tag.getFloat("corpseBurnProgress"));
        if (tag.contains("corpseUUID")) {
            this.entityData.set(CORPSE_UUID, tag.getString("corpseUUID"));
        }
        if (tag.contains("corpseInventory")) {
            ListTag items = tag.getList("corpseInventory", 10);
            inventory.clearContent();
            for (int i = 0; i < items.size(); i++) {
                CompoundTag slotTag = items.getCompound(i);
                int slot = slotTag.getByte("Slot") & 0xFF;
                if (slot < inventory.getContainerSize()) {
                    inventory.setItem(slot, net.minecraft.world.item.ItemStack.of(slotTag));
                }
            }
        }
    }

    @Override
    protected void addAdditionalSaveData(CompoundTag tag) {
        tag.putString("corpseEntityType", getEntityTypeId());
        tag.putInt("corpseDecayStage",    getDecayStage());
        tag.putInt("corpseBodyCount",     getBodyCount());
        tag.putBoolean("corpseIsBurning", isBurning());
        tag.putFloat("corpseBurnProgress", getBurnProgress());
        tag.putString("corpseUUID",       this.entityData.get(CORPSE_UUID));
        ListTag items = new ListTag();
        for (int i = 0; i < inventory.getContainerSize(); i++) {
            net.minecraft.world.item.ItemStack stack = inventory.getItem(i);
            if (!stack.isEmpty()) {
                CompoundTag slotTag = stack.save(new CompoundTag());
                slotTag.putByte("Slot", (byte) i);
                items.add(slotTag);
            }
        }
        tag.put("corpseInventory", items);
    }

    // ── Networking ────────────────────────────────────────────────────────────

    @Override
    public Packet<ClientGamePacketListener> getAddEntityPacket() {
        return NetworkHooks.getEntitySpawningPacket(this);
    }

    // ── Disable unwanted behaviours ───────────────────────────────────────────

    @Override public boolean isPushable() { return false; }
    @Override public boolean isInvulnerableTo(net.minecraft.world.damagesource.DamageSource src) { return true; }
}
