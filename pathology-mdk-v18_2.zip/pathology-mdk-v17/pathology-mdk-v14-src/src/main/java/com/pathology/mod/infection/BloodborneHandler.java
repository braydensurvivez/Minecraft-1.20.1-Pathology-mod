package com.pathology.mod.infection;

import com.pathology.mod.util.ProtectionUtil;
import com.pathology.mod.virus.Virus;
import com.pathology.mod.virus.VirusManager;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.List;
import java.util.Random;

/**
 * Bloodborne vector:
 *  – On death or hurt (damage), infected entity splashes blood in all directions.
 *  – Blood particles spread in look direction with 1-1.5 block range constraint.
 *  – 100% infection chance for unprotected entities within range.
 */
public class BloodborneHandler {

    private static final Random RNG = new Random();
    private static final double BLOODBORNE_RADIUS = 1.5; // Constrained to 1.5 blocks

    public static void onInfectedDeath(LivingEntity deceased, Virus virus) {
        if (!virus.isBloodborne()) return;
        spreadBlood(deceased, virus);
    }

    public static void onInfectedHurt(LivingEntity injured, Virus virus) {
        if (!virus.isBloodborne()) return;
        spreadBlood(injured, virus);
    }

    private static void spreadBlood(LivingEntity source, Virus virus) {
        if (!(source.level() instanceof ServerLevel sl)) return;
        
        double radius = BLOODBORNE_RADIUS; // Always 1-1.5 blocks
        double chance = virus.getBloodborneChance();
        
        // Emit particle spray in look direction
        Vec3 look = source.getLookAngle();
        for (int i = 0; i < 12; i++) {
            double angleOffset = (RNG.nextDouble() - 0.5) * Math.PI * 0.4; // Spread cone
            double distanceOffset = (RNG.nextDouble() - 0.5) * 0.3;
            
            Vec3 direction = look.yRot((float)angleOffset).normalize();
            Vec3 particlePos = source.getEyePosition().add(
                direction.x * (0.8 + distanceOffset),
                direction.y * (0.8 + distanceOffset),
                direction.z * (0.8 + distanceOffset)
            );
            
            sl.sendParticles(ParticleTypes.DAMAGE_INDICATOR,
                particlePos.x, particlePos.y, particlePos.z, 1, 0.05, 0.05, 0.05, 0.1);
        }
        
        // Infection spread
        AABB box = source.getBoundingBox().inflate(radius);
        List<LivingEntity> nearby = source.level().getEntitiesOfClass(LivingEntity.class, box,
            e -> e != source && !VirusManager.isInfected(e, virus.getId()));
        for (LivingEntity target : nearby) {
            if (source.distanceTo(target) > radius) continue;
            double protection = ProtectionUtil.getProtectionReduction(target);
            // 100% infection if unprotected; reduced by protection
            double infectionChance = 1.0 * (1.0 - protection);
            if (RNG.nextDouble() < infectionChance)
                VirusManager.infect(target, virus);
        }
    }
}
