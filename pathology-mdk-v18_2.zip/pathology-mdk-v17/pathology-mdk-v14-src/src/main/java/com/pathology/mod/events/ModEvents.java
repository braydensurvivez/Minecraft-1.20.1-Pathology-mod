package com.pathology.mod.events;

import com.pathology.mod.config.VirusConfig;
import com.pathology.mod.corpse.CorpseData;
import com.pathology.mod.corpse.CorpseManager;
import com.pathology.mod.corpse.CorpseSavedData;
import com.pathology.mod.corpse.DecayDisease;
import com.pathology.mod.entity.CorpseEntity;
import com.pathology.mod.entity.ModEntityTypes;
import com.pathology.mod.PathologyMod;
import com.pathology.mod.infection.AirborneHandler;
import com.pathology.mod.infection.BloodborneHandler;
import com.pathology.mod.infection.BleedingHandler;
import com.pathology.mod.infection.VomitHandler;
import com.pathology.mod.item.BodyBagItem;
import com.pathology.mod.item.ModItems;
import com.pathology.mod.util.ModSounds;
import com.pathology.mod.virus.Virus;
import com.pathology.mod.virus.VirusManager;
import com.pathology.mod.virus.VirusRegistry;
import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.animal.Pig;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ChestMenu;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.EntityJoinLevelEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.living.LivingEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.event.entity.living.MobSpawnEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.event.server.ServerStartedEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.registries.ForgeRegistries;
import org.joml.Vector3f;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Random;
import java.util.UUID;

public class ModEvents {

    private static final int AIRBORNE_INTERVAL = 80;
    private static final Random RNG = new Random();

    private static final int RASP_INTERVAL_TICKS      = 80;
    private static final int BREATHING_INTERVAL_TICKS = 1200;
    private static final double PROXIMITY_BREATHING_RANGE = 1.0;

    private static final DustParticleOptions WHITE_BREATH =
        new DustParticleOptions(new Vector3f(0.92f, 0.92f, 0.92f), 0.6f);
    private static final DustParticleOptions RED_BREATH =
        new DustParticleOptions(new Vector3f(0.75f, 0.0f, 0.05f), 0.5f);

    public static final java.util.Set<java.util.UUID> INFECTION_DEBUG_PLAYERS = new java.util.HashSet<>();

    @SubscribeEvent
    public void onServerStarted(ServerStartedEvent event) {
        VirusRegistry.reload();
        BleedingHandler.clearAll();
        VomitHandler.clearAll();
    }

    // ── Entity joins level ────────────────────────────────────────────────────

    @SubscribeEvent
    public void onEntityJoinLevel(EntityJoinLevelEvent event) {
        if (event.getLevel().isClientSide()) return;
        if (!(event.getEntity() instanceof LivingEntity entity)) return;
        VirusManager.loadFromNBT(entity);
        applySpawnInfection(entity);
    }

    // ── Per-entity tick ───────────────────────────────────────────────────────

    @SubscribeEvent
    public void onLivingTick(LivingEvent.LivingTickEvent event) {
        LivingEntity entity = event.getEntity();
        if (entity.level().isClientSide()) return;

        VirusManager.tick(entity);
        if (!VirusManager.isInfectedByAny(entity)) return;

        for (VirusManager.InfectionRecord rec : VirusManager.getInfections(entity)) {
            Virus v = rec.virus;

            if (v.isAirborne() && entity.tickCount % AIRBORNE_INTERVAL == 0)
                AirborneHandler.spreadFrom(entity, v);

            if (v.isBleeding() && entity.tickCount % v.getBleedingIntervalTicks() == 0)
                BleedingHandler.onBleedPulse(entity, v);

            if (v.isVomit()) {
                int interval = v.getVomitIntervalTicks();
                boolean isBbhv = v.getId().equals("bloodbornehuskvirus");
                boolean isFinalStage = rec.currentStage >= v.getStages().size() - 1;
                boolean stageOk = !isBbhv || isFinalStage;

                if (entity.tickCount % interval == 0 && stageOk)
                    VomitHandler.onVomitFire(entity, v);

                if (stageOk && entity instanceof ServerPlayer) {
                    int warnOffset = interval - 100;
                    if (warnOffset > 0 && entity.tickCount % interval == warnOffset)
                        VomitHandler.scheduleWarning(entity, v);
                }
            }

            if (v.isAirborne() && entity.level() instanceof ServerLevel sl) {
                int entityOffset = (int)(entity.getUUID().getLeastSignificantBits() & 0x3FF);
                int phase = (entity.tickCount + entityOffset) % BREATHING_INTERVAL_TICKS;

                if (phase == 0) {
                    boolean isHuskFlu = v.getId().equals("airbornehuskflu");
                    playBreathingSound(entity, sl, isHuskFlu);
                    spawnBreathParticles(entity, sl, isHuskFlu);
                }

                if (entity.tickCount % 60 == 0 && !(entity instanceof Player)) {
                    List<ServerPlayer> closePlayers = sl.getPlayers(p ->
                        p.distanceTo(entity) <= PROXIMITY_BREATHING_RANGE);
                    if (!closePlayers.isEmpty()) {
                        net.minecraft.core.Holder<net.minecraft.sounds.SoundEvent> breathHolder =
                            ModSounds.BREATHING.getHolder().orElse(null);
                        if (breathHolder != null) {
                            sl.playSound(null, entity.getX(), entity.getY(), entity.getZ(),
                                ModSounds.BREATHING.get(), SoundSource.NEUTRAL,
                                0.3f + RNG.nextFloat() * 0.1f, 0.9f + RNG.nextFloat() * 0.2f);
                        }
                    }
                }
            }

            if (v.getId().equals("airbornehuskflu")) {
                if (rec.currentStage >= 1 && entity instanceof ServerPlayer sp) {
                    if (entity.tickCount % RASP_INTERVAL_TICKS == 0) {
                        net.minecraft.core.Holder<net.minecraft.sounds.SoundEvent> raspHolder =
                            ModSounds.RASP.getHolder().orElse(null);
                        if (raspHolder != null) {
                            net.minecraft.network.protocol.game.ClientboundSoundPacket pkt =
                                new net.minecraft.network.protocol.game.ClientboundSoundPacket(
                                    raspHolder, SoundSource.PLAYERS,
                                    sp.getX(), sp.getY(), sp.getZ(),
                                    0.8f + RNG.nextFloat() * 0.2f,
                                    0.85f + RNG.nextFloat() * 0.15f,
                                    sp.getRandom().nextLong());
                            sp.connection.send(pkt);
                        }
                    }
                }
            }

            if (v.getId().equals("influenza") && entity.tickCount % 1200 == 0) {
                if (entity.getRandom().nextFloat() < 0.15f && entity.level() instanceof ServerLevel sl) {
                    Pig pig = EntityType.PIG.create(sl);
                    if (pig != null) {
                        pig.moveTo(entity.getX() + (entity.getRandom().nextDouble() - 0.5) * 6,
                                   entity.getY(),
                                   entity.getZ() + (entity.getRandom().nextDouble() - 0.5) * 6,
                                   entity.getYRot(), 0f);
                        sl.addFreshEntity(pig);
                        VirusRegistry.get("influenza").ifPresent(flu -> VirusManager.infect(pig, flu));
                    }
                }
            }
        }
    }

    // ── Breathing / particle helpers ──────────────────────────────────────────

    private static void playBreathingSound(LivingEntity entity, ServerLevel sl, boolean isHuskFlu) {
        net.minecraft.core.Holder<net.minecraft.sounds.SoundEvent> breathHolder =
            ModSounds.BREATHING.getHolder().orElse(null);
        if (breathHolder == null) return;
        float vol = 0.6f + RNG.nextFloat() * 0.2f;
        float pitch = 0.85f + RNG.nextFloat() * 0.2f;
        if (entity instanceof ServerPlayer sp) {
            net.minecraft.network.protocol.game.ClientboundSoundPacket pkt =
                new net.minecraft.network.protocol.game.ClientboundSoundPacket(
                    breathHolder, SoundSource.PLAYERS,
                    sp.getX(), sp.getY(), sp.getZ(), vol, pitch, sp.getRandom().nextLong());
            sp.connection.send(pkt);
        } else {
            sl.playSound(null, entity.getX(), entity.getY(), entity.getZ(),
                ModSounds.BREATHING.get(), SoundSource.HOSTILE, vol, pitch);
        }
    }

    private static void spawnBreathParticles(LivingEntity entity, ServerLevel sl, boolean isHuskFlu) {
        Vec3 eye = entity.getEyePosition();
        Vec3 look = entity.getLookAngle();
        double fwdX = look.x * 0.3;
        double fwdZ = look.z * 0.3;
        int count = 2 + RNG.nextInt(3);
        for (int i = 0; i < count; i++) {
            double ox = (RNG.nextDouble() - 0.5) * 0.15;
            double oy = (RNG.nextDouble() - 0.5) * 0.1;
            double oz = (RNG.nextDouble() - 0.5) * 0.15;
            sl.sendParticles(WHITE_BREATH, eye.x + fwdX + ox, eye.y - 0.1 + oy, eye.z + fwdZ + oz,
                1, 0.02, 0.02, 0.02, 0.0);
        }
        if (isHuskFlu && RNG.nextDouble() < 0.15) {
            double ox = (RNG.nextDouble() - 0.5) * 0.12;
            double oy = (RNG.nextDouble() - 0.5) * 0.08;
            double oz = (RNG.nextDouble() - 0.5) * 0.12;
            sl.sendParticles(RED_BREATH, eye.x + fwdX + ox, eye.y - 0.1 + oy, eye.z + fwdZ + oz,
                1, 0.01, 0.01, 0.01, 0.0);
        }
    }

    // ── Zone ticks ────────────────────────────────────────────────────────────

    @SubscribeEvent
    public void onLivingTickForZones(LivingEvent.LivingTickEvent event) {
        LivingEntity entity = event.getEntity();
        if (entity.level().isClientSide()) return;
        if (!(entity.level() instanceof ServerLevel sl)) return;
        if (entity.tickCount % 3 == 1) VomitHandler.tickAllPools(sl);
        if (entity.tickCount % 20 == 7) BleedingHandler.tickAllZones(sl);
        VomitHandler.tickWarnings();
    }

    // ── Death: bloodborne spread + Decay Disease corpse spawn ─────────────────

    @SubscribeEvent
    public void onLivingDeath(LivingDeathEvent event) {
        LivingEntity entity = event.getEntity();
        if (entity.level().isClientSide()) return;

        for (VirusManager.InfectionRecord rec : VirusManager.getInfections(entity))
            BloodborneHandler.onInfectedDeath(entity, rec.virus);

        if (!(entity.level() instanceof ServerLevel sl)) return;

        ResourceLocation typeKey = ForgeRegistries.ENTITY_TYPES.getKey(entity.getType());
        if (typeKey == null) return;
        String typeId = typeKey.toString();

        boolean isZombie = typeId.equals("minecraft:zombie")
                || typeId.equals("minecraft:zombie_villager")
                || typeId.equals("minecraft:husk")
                || typeId.equals("minecraft:drowned")
                || typeId.equals("minecraft:zombified_piglin");

        if (!isZombie) return;

        CompoundTag inv = new CompoundTag();
        entity.saveWithoutId(inv);

        CorpseData corpse = new CorpseData(
            entity.getUUID(), typeId, inv,
            entity.getYRot(), entity.getXRot(),
            entity.position(), sl.getGameTime(),
            true
        );

        UUID corpseId = CorpseManager.get().addCorpse(sl, corpse);
        CorpseSavedData.markDirty(sl);

        if (corpseId == null) {
            PathologyMod.LOGGER.debug("Corpse merged for {}", typeId);
            return;
        }

        PathologyMod.LOGGER.debug("Corpse dropped by {} at {}", typeId, entity.position());

        sl.sendParticles(ParticleTypes.EFFECT,
            entity.getX(), entity.getY() + 0.5, entity.getZ(),
            12, 0.3, 0.3, 0.3, 0.05);

        CorpseEntity corpseEntity = CorpseEntity.fromData(sl, corpse, corpseId);
        populateCorpseEntityInventory(corpseEntity, corpse);
        sl.addFreshEntity(corpseEntity);
        PathologyMod.LOGGER.debug("CorpseEntity spawned for {} (id {})", typeId, corpseEntity.getId());
    }

    private static void populateCorpseEntityInventory(CorpseEntity entity, CorpseData data) {
        var inv = entity.getInventory();
        inv.clearContent();
        for (int i = 0; i < data.lootItems.size() && i < inv.getContainerSize(); i++) {
            inv.setItem(i, data.lootItems.get(i).copy());
        }
    }

    // ── Server tick: decay advancement + CorpseEntity sync / burn despawn ─────

    @SubscribeEvent
    public void onServerTick(TickEvent.ServerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        event.getServer().getAllLevels().forEach(level -> {
            CorpseManager.get().tick(level);

            // NOTE: Double.MIN_VALUE is the smallest *positive* double (~5e-324), NOT
            // a negative number.  Using it as the min corner makes start > end which
            // crashes Minecraft's LongAVLTreeSet range check.  Use -Double.MAX_VALUE.
            AABB infiniteBox = new AABB(
                -Double.MAX_VALUE, -Double.MAX_VALUE, -Double.MAX_VALUE,
                Double.MAX_VALUE,  Double.MAX_VALUE,  Double.MAX_VALUE);

            // Snapshot to avoid ConcurrentModificationException if discard() modifies the list
            java.util.List<CorpseEntity> corpseEntities = new java.util.ArrayList<>(
                level.getEntitiesOfClass(CorpseEntity.class, infiniteBox));

            for (CorpseEntity ce : corpseEntities) {
                UUID cid = ce.getCorpseUUID();

                // ── Burning corpse: spray particles every tick, then discard ───
                if (ce.isBurning()) {
                    // level is already ServerLevel (getAllLevels() guarantees this)
                    ServerLevel sl = level;
                    double x = ce.getX(), y = ce.getY(), z = ce.getZ();

                    // Compute progress 0.0→1.0 based on how long it has been burning.
                    long burnStart  = CorpseManager.get().getBurnStartTime(cid);
                    long burnDur    = CorpseManager.getBurnDuration();
                    float progress  = (burnStart < 0) ? 1.0f
                        : Math.min(1.0f, (float)(level.getGameTime() - burnStart) / burnDur);
                    ce.setBurnProgress(progress);

                    // ── Particles: small flames hugging the body on the ground ──
                    // The corpse lies flat so we keep everything close to y+0.1–0.3.
                    // Low spread values (0.3 horiz, 0.05 vert) keep fire tight to
                    // the model rather than blooming into a large column.

                    // Steady small flame every tick
                    sl.sendParticles(ParticleTypes.FLAME,
                        x, y + 0.1, z, 2, 0.3, 0.05, 0.3, 0.01);

                    // Smoke drifts up from the body every tick
                    sl.sendParticles(ParticleTypes.SMOKE,
                        x, y + 0.2, z, 1, 0.25, 0.05, 0.25, 0.01);

                    // Slightly larger pulse every 8 ticks
                    if (sl.getGameTime() % 8 == 0) {
                        sl.sendParticles(ParticleTypes.FLAME,
                            x, y + 0.15, z, 4, 0.35, 0.08, 0.35, 0.02);
                        sl.sendParticles(ParticleTypes.LARGE_SMOKE,
                            x, y + 0.3, z, 1, 0.2, 0.05, 0.2, 0.005);
                    }

                    // Brief ember burst only in the first 15 ticks (ignition flash)
                    if (burnStart >= 0 && (level.getGameTime() - burnStart) < 15) {
                        sl.sendParticles(ParticleTypes.FLAME,
                            x, y + 0.2, z, 5, 0.4, 0.1, 0.4, 0.03);
                    }

                    // Burn window ended — entity fully consumed, remove it.
                    // kill() is used instead of discard() to ensure the entity
                    // is fully removed from the world (equivalent to /kill).
                    if (!CorpseManager.get().isBurning(cid)) {
                        ce.setBurnProgress(1.0f);
                        ce.kill();
                    }
                    continue; // never update decay on a burning corpse
                }

                // ── Just ignited this tick ─────────────────────────────────────
                if (CorpseManager.get().isBurning(cid)) {
                    ce.setBurning(true);
                    ce.setBurnProgress(0.0f);
                    continue;
                }

                // ── Normal decay sync ──────────────────────────────────────────
                Optional<CorpseData> dataOpt = CorpseManager.get().get(cid);

                if (dataOpt.isEmpty()) {
                    // Fallback: match by position
                    dataOpt = CorpseManager.get().all().stream()
                        .filter(d -> d.deathPos.distanceTo(ce.position()) < 1.0)
                        .findFirst();
                }

                if (dataOpt.isEmpty()) {
                    // No record at all — despawn orphan entity
                    ce.kill();
                    continue;
                }

                CorpseData d = dataOpt.get();
                if (ce.getDecayStage() != d.decayStage) ce.setDecayStage(d.decayStage);
                if (ce.getBodyCount()  != d.bodyCount)  ce.setBodyCount(d.bodyCount);
            }

            if (level.getGameTime() % 100 == 0) CorpseSavedData.markDirty(level);
        });
    }

    // ── Right-click entity: body bag pickup, ignite, or open inventory ────────

    @SubscribeEvent
    public void onPlayerRightClickEntity(PlayerInteractEvent.EntityInteract event) {
        if (event.getLevel().isClientSide()) return;
        if (!(event.getTarget() instanceof CorpseEntity corpse)) return;
        if (!(event.getLevel() instanceof ServerLevel sl)) return;

        Player player = event.getEntity();
        ItemStack held = player.getItemInHand(event.getHand());

        // ── Body Bag → pick up the corpse ────────────────────────────────────
        if (held.getItem() instanceof BodyBagItem) {
            // Delegate to BodyBagItem's entity-interaction path
            handleBodyBagEntityInteract((BodyBagItem) held.getItem(), held, player, corpse, sl);
            event.setCanceled(true);
            return;
        }

        // ── Flint & Steel / Fire Charge → ignite ─────────────────────────────
        if (held.is(Items.FLINT_AND_STEEL) || held.is(Items.FIRE_CHARGE)) {
            UUID cid = corpse.getCorpseUUID();
            boolean alreadyBurning = CorpseManager.get().isBurning(cid) || corpse.isBurning();
            boolean hasData = CorpseManager.get().get(cid).isPresent();

            if (hasData && !alreadyBurning) {
                CorpseManager.get().destroyByFire(cid, sl);
                corpse.setBurning(true);

                // Kill the entity immediately — equivalent to /kill.
                // This guarantees the CorpseEntity is removed from the world
                // right when it is ignited, preventing gameplay and performance issues.
                corpse.kill();

                if (held.is(Items.FLINT_AND_STEEL)) {
                    held.hurtAndBreak(1, player, p -> p.broadcastBreakEvent(event.getHand()));
                } else {
                    if (!player.isCreative()) held.shrink(1);
                }

                player.displayClientMessage(
                    Component.literal("You light the corpse on fire.")
                        .withStyle(ChatFormatting.GOLD), true);
                CorpseSavedData.markDirty(sl);
            } else if (alreadyBurning) {
                player.displayClientMessage(
                    Component.literal("The corpse is already burning.")
                        .withStyle(ChatFormatting.GRAY), true);
            }
            event.setCanceled(true);
            return;
        }

        // ── Any other right-click → open 3-row chest inventory ───────────────
        if (player instanceof ServerPlayer sp) {
            // Guard: don't open a burning corpse
            if (corpse.isBurning()) {
                sp.displayClientMessage(
                    Component.literal("The corpse is on fire!")
                        .withStyle(ChatFormatting.RED), true);
                event.setCanceled(true);
                return;
            }

            var inventory = corpse.getInventory();
            // Reset the idle despawn timer each time the inventory is opened
            CorpseManager.get().markLooted(corpse.getCorpseUUID(), sl.getGameTime());
            sp.openMenu(new SimpleMenuProvider(
                (containerId, playerInv, p) ->
                    ChestMenu.threeRows(containerId, playerInv, inventory),
                Component.literal("Corpse")
            ));
        }
        event.setCanceled(true);
    }

    /**
     * Handles body bag pickup when the player RIGHT-CLICKS a CorpseEntity
     * directly (EntityInteract event).  BodyBagItem.use() only fires when
     * clicking air; this method handles the entity-targeting case.
     */
    private static void handleBodyBagEntityInteract(
            BodyBagItem item, ItemStack stack, Player player,
            CorpseEntity corpse, ServerLevel sl) {

        // If bag already holds a corpse, don't pick up another
        if (stack.hasTag() && stack.getTag().hasUUID("storedCorpseUUID")) {
            player.displayClientMessage(
                Component.literal("Body bag is already full.")
                    .withStyle(ChatFormatting.RED), true);
            return;
        }

        UUID corpseId = corpse.getCorpseUUID();

        Optional<CorpseData> dataOpt = CorpseManager.get().get(corpseId);
        if (dataOpt.isEmpty()) {
            corpseId = CorpseManager.get().getUUIDAt(corpse.position()).orElse(null);
            if (corpseId == null) {
                player.displayClientMessage(
                    Component.literal("Corpse data missing.")
                        .withStyle(ChatFormatting.RED), true);
                return;
            }
        }

        // Store UUID in item NBT
        CompoundTag tag = stack.getOrCreateTag();
        tag.putUUID("storedCorpseUUID", corpseId);

        // Despawn the entity
        corpse.kill();

        player.displayClientMessage(
            Component.literal("Corpse stored in body bag.")
                .withStyle(ChatFormatting.GREEN), true);
        PathologyMod.LOGGER.debug("Body bag (entity click) picked up corpse {}", corpseId);
        CorpseSavedData.markDirty(sl);
    }

    // ── Melee hit ─────────────────────────────────────────────────────────────

    @SubscribeEvent
    public void onLivingHurt(LivingHurtEvent event) {
        LivingEntity victim = event.getEntity();
        if (victim.level().isClientSide()) return;
        if (!(event.getSource().getEntity() instanceof LivingEntity attacker)) return;
        for (VirusManager.InfectionRecord rec : VirusManager.getInfections(victim)) {
            if (rec.virus.isBleeding())
                BleedingHandler.onMeleeContact(attacker, victim, rec.virus);
            if (rec.virus.isBloodborne())
                BloodborneHandler.onInfectedHurt(victim, rec.virus);
        }
    }

    // ── FinalizeSpawn ──────────────────────────────────────────────────────────

    @SubscribeEvent
    public void onMobSpawn(MobSpawnEvent.FinalizeSpawn event) {
        LivingEntity entity = event.getEntity();
        if (entity.level().isClientSide()) return;
        applySpawnInfection(entity);
    }

    // ── Spawn infection (zombies always get decay_disease) ────────────────────

    private static void applySpawnInfection(LivingEntity entity) {
        ResourceLocation entityId = ForgeRegistries.ENTITY_TYPES.getKey(entity.getType());
        if (entityId == null) return;
        String entityKey = entityId.toString();

        boolean isZombieLike = entityKey.equals("minecraft:zombie") || entityKey.equals("minecraft:zombie_villager") ||
            entityKey.equals("minecraft:zombified_piglin") || entityKey.equals("minecraft:husk") ||
            entityKey.equals("minecraft:drowned") ||
            entityKey.equals("mca:male_zombie_villager") || entityKey.equals("mca:female_zombie_villager") ||
            entityKey.equals("hordes:zombie_player");

        if (isZombieLike) {
            // Infect and mark as CARRIER: spreads disease but never advances stages or dies from it
            VirusRegistry.get("airbornehuskflu").ifPresent(v -> {
                VirusManager.infect(entity, v);
                VirusManager.markCarrier(entity);
            });
            VirusRegistry.get("bloodbornehuskvirus").ifPresent(v -> {
                VirusManager.infect(entity, v);
                VirusManager.markCarrier(entity);
            });
        } else {
            Map<String, String> spawnMap = VirusConfig.getNaturalSpawnMap();
            String virusId = spawnMap.get(entityKey);
            if (virusId != null) {
                VirusRegistry.get(virusId).ifPresent(v -> {
                    VirusManager.infect(entity, v);
                    VirusManager.markCarrier(entity);
                });
            }
        }

        if (entityKey.equals(DecayDisease.ZOMBIE_KEY)
                || entityKey.equals("minecraft:zombie_villager")
                || entityKey.equals("minecraft:husk")
                || entityKey.equals("minecraft:drowned")
                || entityKey.equals("minecraft:zombified_piglin")) {
            VirusRegistry.get(DecayDisease.VIRUS_ID).ifPresent(v -> {
                VirusManager.infect(entity, v);
                VirusManager.markCarrier(entity);
            });
            PathologyMod.LOGGER.debug("Zombie {} infected with Decay Disease on spawn (carrier)", entity.getUUID());
        }
    }

    // ── Cure items ────────────────────────────────────────────────────────────

    @SubscribeEvent
    public void onPlayerRightClick(PlayerInteractEvent.RightClickItem event) {
        if (event.getLevel().isClientSide()) return;
        var player = event.getEntity();
        ItemStack stack = event.getItemStack();
        ResourceLocation itemId = ForgeRegistries.ITEMS.getKey(stack.getItem());
        if (itemId == null) return;
        Map<String, String> cureMap = VirusConfig.getCureItemMap();
        String virusId = cureMap.get(itemId.toString());
        if (virusId == null) return;
        if (virusId.equals("any")) {
            for (VirusManager.InfectionRecord rec : VirusManager.getInfections(player))
                VirusManager.cure(player, rec.virus.getId());
        } else {
            VirusManager.cure(player, virusId);
        }
    }
}
