package com.pathology.mod.util;

import com.pathology.mod.PathologyMod;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModSounds {

    public static final DeferredRegister<SoundEvent> SOUND_EVENTS =
            DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, PathologyMod.MOD_ID);

    public static final RegistryObject<SoundEvent> VOMIT =
            SOUND_EVENTS.register("vomit",
                    () -> SoundEvent.createVariableRangeEvent(new ResourceLocation(PathologyMod.MOD_ID, "vomit")));

    /** Rasp/cough sound played to airborne-infected players */
    public static final RegistryObject<SoundEvent> RASP =
            SOUND_EVENTS.register("rasp",
                    () -> SoundEvent.createVariableRangeEvent(new ResourceLocation(PathologyMod.MOD_ID, "rasp")));

    /**
     * Breathing sound played occasionally for all airborne-infected entities.
     * Heard by the infected entity itself (private) and by anyone within 1 block (proximity).
     */
    public static final RegistryObject<SoundEvent> BREATHING =
            SOUND_EVENTS.register("breathing",
                    () -> SoundEvent.createVariableRangeEvent(new ResourceLocation(PathologyMod.MOD_ID, "breathing")));
}
