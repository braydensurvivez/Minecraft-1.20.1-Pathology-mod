package com.pathology.mod.util;

import com.pathology.mod.config.ProtectionConfig;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.registries.ForgeRegistries;

import java.util.Map;

public class ProtectionUtil {
    private ProtectionUtil() {}

    public static double getProtectionReduction(LivingEntity entity) {
        Map<String, Double> map = ProtectionConfig.getProtectionMap();
        double total = 0.0;
        for (ItemStack stack : entity.getArmorSlots()) {
            total += getStackProtection(stack, map);
        }
        total += getStackProtection(entity.getMainHandItem(), map);
        return Math.min(total, 1.0);
    }

    public static double getStackProtection(ItemStack stack, Map<String, Double> map) {
        if (stack.isEmpty()) return 0.0;
        ResourceLocation id = ForgeRegistries.ITEMS.getKey(stack.getItem());
        if (id == null) return 0.0;
        Double v = map.get(id.toString());
        return v != null ? v : 0.0;
    }

    public static double getStackProtection(ItemStack stack) {
        return getStackProtection(stack, ProtectionConfig.getProtectionMap());
    }
}
