package com.pathology.mod.item;

import com.pathology.mod.PathologyMod;
import com.pathology.mod.virus.VirusManager;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.*;

/**
 * Field Assessment Kit – right-click a LivingEntity to begin a 60-second
 * (1200-tick) assessment. When the timer expires the assessor receives a
 * full report: every active virus and its current stage.
 */
@Mod.EventBusSubscriber(modid = PathologyMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public class FieldAssessmentKitItem extends Item {

    private static final int ASSESSMENT_TICKS = 1200; // 60 seconds

    /** assessorUUID -> pending assessment */
    private static final Map<UUID, Pending> PENDING = new HashMap<>();

    public FieldAssessmentKitItem(Properties props) {
        super(props);
    }

    @Override
    public InteractionResult interactLivingEntity(ItemStack stack, Player player, LivingEntity target, InteractionHand hand) {
        if (player.level().isClientSide()) return InteractionResult.SUCCESS;

        UUID aid = player.getUUID();
        if (PENDING.containsKey(aid)) {
            player.displayClientMessage(
                Component.literal("[FAK] Previous assessment cancelled. Starting new one.")
                    .withStyle(ChatFormatting.GRAY), true);
        }

        String targetName = target instanceof Player p
            ? p.getName().getString()
            : target.getType().getDescription().getString();

        PENDING.put(aid, new Pending(target.getUUID(), targetName,
            player.level().getGameTime() + ASSESSMENT_TICKS));

        player.displayClientMessage(
            Component.literal("[FAK] Assessment started on ")
                .withStyle(ChatFormatting.AQUA)
                .append(Component.literal(targetName).withStyle(ChatFormatting.WHITE))
                .append(Component.literal(". Results in 60 seconds.").withStyle(ChatFormatting.AQUA)),
            false);

        player.level().playSound(null, player.blockPosition(),
            net.minecraft.sounds.SoundEvents.AMETHYST_CLUSTER_PLACE,
            net.minecraft.sounds.SoundSource.PLAYERS, 0.5f, 1.2f);

        return InteractionResult.SUCCESS;
    }

    @SubscribeEvent
    public static void onServerTick(TickEvent.ServerTickEvent event) {
        if (event.phase != TickEvent.Phase.END || PENDING.isEmpty()) return;

        long now = -1;
        for (var level : event.getServer().getAllLevels()) { now = level.getGameTime(); break; }
        if (now < 0) return;

        long currentTime = now;
        List<UUID> done = new ArrayList<>();
        for (var e : PENDING.entrySet()) if (currentTime >= e.getValue().readyAt) done.add(e.getKey());

        for (UUID aid : done) {
            Pending p = PENDING.remove(aid);
            if (p == null) continue;

            ServerPlayer assessor = event.getServer().getPlayerList().getPlayer(aid);
            if (assessor == null) continue;

            LivingEntity target = null;
            for (var level : event.getServer().getAllLevels()) {
                var ent = level.getEntity(p.targetId);
                if (ent instanceof LivingEntity le) { target = le; break; }
            }
            deliver(assessor, p.targetName, target);
        }
    }

    private static void deliver(ServerPlayer assessor, String targetName, LivingEntity target) {
        assessor.displayClientMessage(Component.literal("==============================")
            .withStyle(ChatFormatting.DARK_AQUA), false);
        assessor.displayClientMessage(Component.literal("[FAK] FIELD ASSESSMENT: " + targetName)
            .withStyle(ChatFormatting.AQUA, ChatFormatting.BOLD), false);

        if (target == null) {
            assessor.displayClientMessage(Component.literal("  Target lost / despawned.")
                .withStyle(ChatFormatting.RED), false);
        } else {
            var infections = VirusManager.getInfections(target);
            if (infections.isEmpty()) {
                assessor.displayClientMessage(Component.literal("  No active infections detected.")
                    .withStyle(ChatFormatting.GREEN), false);
            } else {
                for (var rec : infections) {
                    assessor.displayClientMessage(
                        Component.literal("  > ").withStyle(ChatFormatting.YELLOW)
                            .append(Component.literal(rec.virus.getId()).withStyle(ChatFormatting.RED))
                            .append(Component.literal("  [Stage " + (rec.currentStage + 1) + "]")
                                .withStyle(ChatFormatting.GOLD)),
                        false);
                }
                if (VirusManager.isCarrier(target)) {
                    assessor.displayClientMessage(
                        Component.literal("  ! Carrier (asymptomatic spreader)")
                            .withStyle(ChatFormatting.YELLOW), false);
                }
            }
        }

        assessor.displayClientMessage(Component.literal("==============================")
            .withStyle(ChatFormatting.DARK_AQUA), false);

        assessor.level().playSound(null, assessor.blockPosition(),
            net.minecraft.sounds.SoundEvents.EXPERIENCE_ORB_PICKUP,
            net.minecraft.sounds.SoundSource.PLAYERS, 0.6f, 1.0f);
    }

    private static class Pending {
        final UUID   targetId;
        final String targetName;
        final long   readyAt;
        Pending(UUID t, String n, long r) { targetId = t; targetName = n; readyAt = r; }
    }
}
