package com.pathology.mod.virus;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffects;
import net.minecraftforge.registries.ForgeRegistries;

import java.util.ArrayList;
import java.util.List;

/**
 * Represents a single stage of a viral infection.
 * Each stage has a duration (in ticks) and a list of effects applied during that stage.
 */
public class InfectionStage {

    private final int durationTicks;
    private final List<StagedEffect> effects;

    public InfectionStage(int durationTicks, List<StagedEffect> effects) {
        this.durationTicks = durationTicks;
        this.effects = effects;
    }

    public int getDurationTicks() {
        return durationTicks;
    }

    public List<StagedEffect> getEffects() {
        return effects;
    }

    /**
     * A single effect entry within a stage (effect + amplifier).
     *
     * Two construction paths:
     *  - Direct MobEffect reference (vanilla effects known at compile time)
     *  - String resource location (any modded effect, resolved lazily via
     *    ForgeRegistries at apply-time so load order never matters)
     */
    public static class StagedEffect {
        // One or both may be set. resolvedEffect is populated eagerly when
        // constructed from a MobEffect, or lazily on first getEffect() call
        // when constructed from a String.
        private final String effectId;       // "namespace:path", always set
        private MobEffect    resolvedEffect; // null until resolved
        private final int    amplifier;

        /** Direct reference – for vanilla effects known at class-load time. */
        public StagedEffect(MobEffect effect, int amplifier) {
            this.resolvedEffect = effect;
            ResourceLocation key = ForgeRegistries.MOB_EFFECTS.getKey(effect);
            this.effectId = (key != null) ? key.toString() : "";
            this.amplifier = amplifier;
        }

        /**
         * Deferred reference – for any mod's effect, including "hordes:infected".
         * Resolution is deferred to {@link #getEffect()} via ForgeRegistries,
         * which covers all registered MobEffects from all loaded mods.
         */
        public StagedEffect(String effectId, int amplifier) {
            this.effectId       = effectId;
            this.resolvedEffect = null; // resolved lazily
            this.amplifier      = amplifier;
        }

        /**
         * Returns the MobEffect, resolving through ForgeRegistries if needed.
         * Returns null only if the providing mod is not loaded.
         */
        public MobEffect getEffect() {
            if (resolvedEffect != null) return resolvedEffect;
            if (effectId == null || effectId.isEmpty()) return null;
            try {
                resolvedEffect = ForgeRegistries.MOB_EFFECTS.getValue(new ResourceLocation(effectId));
            } catch (Exception ignored) {
                // malformed ResourceLocation – caller handles null
            }
            return resolvedEffect;
        }

        public String getEffectId()  { return effectId; }
        public int    getAmplifier() { return amplifier; }

        /** True if the effect is currently resolvable (the providing mod is loaded). */
        public boolean isAvailable() { return getEffect() != null; }
    }

    // -------------------------------------------------------------------------
    // Factory helpers – used when building default stages from config values
    // -------------------------------------------------------------------------

    public static InfectionStage buildDefault(int stageIndex, int durationTicks) {
        List<StagedEffect> effects = new ArrayList<>();
        switch (stageIndex) {
            case 0 -> effects.add(new StagedEffect(MobEffects.HUNGER, 0));  // Hunger I  – mild
            case 1 -> {
                effects.add(new StagedEffect(MobEffects.HUNGER, 0));         // Hunger I  – still mild
                effects.add(new StagedEffect(MobEffects.WEAKNESS, 0));
            }
            case 2 -> {
                effects.add(new StagedEffect(MobEffects.HUNGER, 1));         // Hunger II – moderate
                effects.add(new StagedEffect(MobEffects.WEAKNESS, 1));
                effects.add(new StagedEffect(MobEffects.POISON, 0));
            }
            default -> effects.add(new StagedEffect(MobEffects.WEAKNESS, 0));
        }
        return new InfectionStage(durationTicks, effects);
    }
}
