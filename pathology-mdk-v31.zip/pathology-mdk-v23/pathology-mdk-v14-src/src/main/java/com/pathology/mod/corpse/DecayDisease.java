package com.pathology.mod.corpse;

/**
 * Constants and helpers for the "Decay Disease" virus.
 *
 * The virus itself is registered in {@link com.pathology.mod.virus.VirusRegistry}
 * via {@code registerDecayDisease()}.  This class is a lightweight companion
 * that keeps the corpse package self-contained and avoids circular imports.
 */
public final class DecayDisease {

    /** Registry ID used throughout the codebase. */
    public static final String VIRUS_ID = "decay_disease";

    /** Minecraft entity key for a standard zombie. */
    public static final String ZOMBIE_KEY = "minecraft:zombie";

    /**
     * All zombie variants carry Decay Disease unconditionally so that every
     * zombie death produces a corpse.  The constant is kept here for reference
     * but is no longer used as a random threshold.
     */
    public static final double NATURAL_SPAWN_CHANCE = 1.0;

    private DecayDisease() {}
}
