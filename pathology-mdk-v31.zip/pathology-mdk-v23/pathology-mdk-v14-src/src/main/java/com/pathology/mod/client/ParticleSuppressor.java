package com.pathology.mod.client;

/**
 * Particle suppression for infected entities.
 *
 * All MobEffectInstances applied to infected entities are set with visible=false
 * (no ambient particles) at the point of application:
 *
 *   – Staged virus effects: VirusManager.tick() applies with visible=false
 *   – Vomit session effects (slowness, nausea): VomitHandler applies with visible=false
 *
 * This means the swirling potion-effect particles (slowness grey, nausea green)
 * will NOT appear on any mob or player affected by the pathology system.
 *
 * The airborne infection spread itself never emitted particles (AirborneHandler is pure logic).
 * The intentional particle systems (vomit stream, blood pools, bleeding zones) are unaffected
 * because they use sendParticles() directly on ServerLevel, not MobEffectInstance.
 */
public class ParticleSuppressor {
    // Implementation is server-side in VirusManager and VomitHandler.
    // No client-side hooks required.
}
