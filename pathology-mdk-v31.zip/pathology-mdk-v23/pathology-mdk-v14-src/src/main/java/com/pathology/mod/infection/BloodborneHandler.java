package com.pathology.mod.infection;

import com.pathology.mod.util.ProtectionUtil;
import com.pathology.mod.virus.Virus;
import com.pathology.mod.virus.VirusManager;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import org.joml.Vector3f;

import java.util.List;
import java.util.Random;

/**
 * Bloodborne vector:
 *  – On death: large omnidirectional blood explosion from the entity's body.
 *  – On hurt: smaller directional blood spray from impact point.
 *  – Both events spread infection to nearby unprotected entities.
 */
public class BloodborneHandler {

    private static final Random RNG = new Random();
    private static final double BLOODBORNE_RADIUS = 1.5;

    // Deep crimson red for blood splatter
    private static final DustParticleOptions BLOOD_RED =
        new DustParticleOptions(new Vector3f(0.72f, 0.02f, 0.02f), 1.2f);
    private static final DustParticleOptions BLOOD_DARK =
        new DustParticleOptions(new Vector3f(0.45f, 0.01f, 0.01f), 0.8f);

    // ── Public API ────────────────────────────────────────────────────────────

    public static void onInfectedDeath(LivingEntity deceased, Virus virus) {
        if (!virus.isBloodborne()) return;
        spawnDeathBloodBurst(deceased);
        spreadInfection(deceased, virus);
    }

    public static void onInfectedHurt(LivingEntity injured, Virus virus) {
        if (!virus.isBloodborne()) return;
        spawnHurtBloodSplatter(injured);
        spreadInfection(injured, virus);
    }

    // ── Particle effects ──────────────────────────────────────────────────────

    /**
     * Large omnidirectional explosion of blood on death.
     * ~40 particles bursting outward in all directions from the body centre.
     */
    private static void spawnDeathBloodBurst(LivingEntity entity) {
        if (!(entity.level() instanceof ServerLevel sl)) return;

        double x = entity.getX();
        double y = entity.getY() + entity.getBbHeight() * 0.5; // body centre
        double z = entity.getZ();

        // Primary burst — large crimson particles flying outward in all directions
        // speedX/Y/Z are used as velocity when count=0; with count>0 they act as spread
        sl.sendParticles(BLOOD_RED,   x, y, z, 30, 0.35, 0.35, 0.35, 0.18);
        sl.sendParticles(BLOOD_DARK,  x, y, z, 15, 0.25, 0.25, 0.25, 0.12);

        // Upward geyser component
        sl.sendParticles(BLOOD_RED,   x, y + 0.2, z, 10, 0.2, 0.1, 0.2, 0.25);

        // Ground splatter — low particles fanning outward near the feet
        sl.sendParticles(BLOOD_DARK,  x, entity.getY() + 0.05, z, 12, 0.5, 0.02, 0.5, 0.05);
    }

    /**
     * Smaller directional blood spray on damage — flies in the direction the
     * entity is facing (away from the attacker's impact).
     * ~12 particles in a tight cone.
     */
    private static void spawnHurtBloodSplatter(LivingEntity entity) {
        if (!(entity.level() instanceof ServerLevel sl)) return;

        Vec3 pos = entity.position().add(0, entity.getBbHeight() * 0.6, 0);

        // Medium burst centred on the hit entity — smaller than death
        sl.sendParticles(BLOOD_RED,  pos.x, pos.y, pos.z, 10, 0.2, 0.2, 0.2, 0.12);
        sl.sendParticles(BLOOD_DARK, pos.x, pos.y, pos.z,  4, 0.15, 0.15, 0.15, 0.08);

        // Small drip toward the ground
        sl.sendParticles(BLOOD_DARK, pos.x, entity.getY() + 0.05, pos.z, 3, 0.25, 0.02, 0.25, 0.03);
    }

    // ── Infection spread ──────────────────────────────────────────────────────

    private static void spreadInfection(LivingEntity source, Virus virus) {
        double radius = BLOODBORNE_RADIUS;
        double chance = virus.getBloodborneChance();

        AABB box = source.getBoundingBox().inflate(radius);
        List<LivingEntity> nearby = source.level().getEntitiesOfClass(LivingEntity.class, box,
            e -> e != source && !VirusManager.isInfected(e, virus.getId()));
        for (LivingEntity target : nearby) {
            if (source.distanceTo(target) > radius) continue;
            double protection = ProtectionUtil.getProtectionReduction(target);
            double infectionChance = chance * (1.0 - protection);
            if (RNG.nextDouble() < infectionChance)
                VirusManager.infect(target, virus);
        }
    }
}
