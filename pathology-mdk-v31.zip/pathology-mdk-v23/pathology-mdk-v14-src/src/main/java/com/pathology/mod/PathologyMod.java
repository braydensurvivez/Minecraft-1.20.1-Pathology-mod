package com.pathology.mod;

import com.pathology.mod.config.CorpseLootConfig;
import com.pathology.mod.config.ProtectionConfig;
import com.pathology.mod.config.VirusConfig;
import com.pathology.mod.entity.ModEntityTypes;
import com.pathology.mod.events.CommandEvents;
import com.pathology.mod.events.ModEvents;
import com.pathology.mod.item.ModCreativeTab;
import com.pathology.mod.util.ModSounds;
import com.pathology.mod.item.ModItems;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.event.config.ModConfigEvent;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

@Mod(PathologyMod.MOD_ID)
public class PathologyMod {

    public static final String MOD_ID = "pathologymod";
    public static final Logger LOGGER = LogManager.getLogger(MOD_ID);

    public PathologyMod() {
        IEventBus modEventBus = FMLJavaModLoadingContext.get().getModEventBus();
        modEventBus.addListener(this::setup);
        modEventBus.addListener(this::onConfigLoad);
        modEventBus.addListener(this::onConfigReload);

        // Register configs
        ModLoadingContext.get().registerConfig(ModConfig.Type.SERVER, VirusConfig.SPEC,      "pathologymod-viruses.toml");
        ModLoadingContext.get().registerConfig(ModConfig.Type.COMMON, ProtectionConfig.SPEC, "pathologymod-protection.toml");
        ModLoadingContext.get().registerConfig(ModConfig.Type.SERVER, CorpseLootConfig.SPEC, "pathologymod-corpse-loot.toml");

        // Register deferred registries
        ModItems.ITEMS.register(modEventBus);
        ModCreativeTab.CREATIVE_TABS.register(modEventBus);
        ModSounds.SOUND_EVENTS.register(modEventBus);
        ModEntityTypes.ENTITY_TYPES.register(modEventBus);

        // Register event listeners
        MinecraftForge.EVENT_BUS.register(new ModEvents());
        MinecraftForge.EVENT_BUS.register(new CommandEvents());

        LOGGER.info("Pathology Mod v12 initialized.");
    }

    private void setup(final FMLCommonSetupEvent event) {
        LOGGER.info("Pathology Mod common setup complete.");
    }

    private void onConfigLoad(final ModConfigEvent.Loading event) {
        if (event.getConfig().getSpec() == ProtectionConfig.SPEC)
            ProtectionConfig.invalidateCache();
    }

    private void onConfigReload(final ModConfigEvent.Reloading event) {
        if (event.getConfig().getSpec() == ProtectionConfig.SPEC)
            ProtectionConfig.invalidateCache();
    }
}
