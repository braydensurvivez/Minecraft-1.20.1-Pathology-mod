package com.pathology.mod.client;

import com.pathology.mod.entity.ModEntityTypes;
import net.minecraft.client.renderer.entity.ThrownItemRenderer;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = com.pathology.mod.PathologyMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ClientSetup {

    @SubscribeEvent
    public static void onRegisterRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(ModEntityTypes.VIRUS_VIAL.get(), ThrownItemRenderer::new);
        // Corpse renderer – reuses vanilla ZombieModel, no new assets needed
        event.registerEntityRenderer(ModEntityTypes.CORPSE.get(), CorpseRenderer::new);
    }
}
