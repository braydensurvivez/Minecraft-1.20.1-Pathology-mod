package com.pathology.mod.virus;

import java.util.ArrayList;
import java.util.List;

public class Virus {

    public enum InfectionType {
        AIRBORNE,
        BLOODBORNE,
        BLEEDING,
        VOMIT
    }

    private final String id;
    private final List<InfectionStage> stages;
    private final List<InfectionType> infectionTypes;

    // Airborne
    private final double airborneRadius;
    private final double airborneChance;

    // Bloodborne
    private final double bloodborneRadius;
    private final double bloodborneChance;
    private final int bloodborneDurationTicks;

    // Bleeding
    private final int bleedingIntervalTicks;
    private final double bleedingZoneRadius;
    private final int bleedingZoneDurationTicks;
    private final double bleedingInfectChance;

    // Vomit
    private final int vomitIntervalTicks;
    private final double vomitFireChance;
    private final double vomitInfectChance;
    private final double vomitSplashRadius;

    public Virus(String id, List<InfectionStage> stages, List<InfectionType> infectionTypes,
                 double airborneRadius, double airborneChance,
                 double bloodborneRadius, double bloodborneChance, int bloodborneDurationTicks,
                 int bleedingIntervalTicks, double bleedingZoneRadius,
                 int bleedingZoneDurationTicks, double bleedingInfectChance,
                 int vomitIntervalTicks, double vomitFireChance,
                 double vomitInfectChance, double vomitSplashRadius) {
        this.id = id;
        this.stages = stages;
        this.infectionTypes = infectionTypes;
        this.airborneRadius = airborneRadius;
        this.airborneChance = airborneChance;
        this.bloodborneRadius = bloodborneRadius;
        this.bloodborneChance = bloodborneChance;
        this.bloodborneDurationTicks = bloodborneDurationTicks;
        this.bleedingIntervalTicks = bleedingIntervalTicks;
        this.bleedingZoneRadius = bleedingZoneRadius;
        this.bleedingZoneDurationTicks = bleedingZoneDurationTicks;
        this.bleedingInfectChance = bleedingInfectChance;
        this.vomitIntervalTicks = vomitIntervalTicks;
        this.vomitFireChance = vomitFireChance;
        this.vomitInfectChance = vomitInfectChance;
        this.vomitSplashRadius = vomitSplashRadius;
    }

    public String getId()                      { return id; }
    public List<InfectionStage> getStages()    { return stages; }
    public List<InfectionType> getInfectionTypes() { return infectionTypes; }
    public double getAirborneRadius()          { return airborneRadius; }
    public double getAirborneChance()          { return airborneChance; }
    public double getBloodborneRadius()        { return bloodborneRadius; }
    public double getBloodborneChance()        { return bloodborneChance; }
    public int    getBloodborneDurationTicks() { return bloodborneDurationTicks; }
    public int    getBleedingIntervalTicks()   { return bleedingIntervalTicks; }
    public double getBleedingZoneRadius()      { return bleedingZoneRadius; }
    public int    getBleedingZoneDurationTicks(){ return bleedingZoneDurationTicks; }
    public double getBleedingInfectChance()    { return bleedingInfectChance; }
    public int    getVomitIntervalTicks()      { return vomitIntervalTicks; }
    public double getVomitFireChance()         { return vomitFireChance; }
    public double getVomitInfectChance()       { return vomitInfectChance; }
    public double getVomitSplashRadius()       { return vomitSplashRadius; }

    public boolean isAirborne()   { return infectionTypes.contains(InfectionType.AIRBORNE); }
    public boolean isBloodborne() { return infectionTypes.contains(InfectionType.BLOODBORNE); }
    public boolean isBleeding()   { return infectionTypes.contains(InfectionType.BLEEDING); }
    public boolean isVomit()      { return infectionTypes.contains(InfectionType.VOMIT); }
}
