package com.pathology.mod.item;

import com.pathology.mod.entity.VirusVialEntity;
import com.pathology.mod.virus.Virus;
import com.pathology.mod.virus.VirusRegistry;
import net.minecraft.ChatFormatting;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

import javax.annotation.Nullable;
import java.util.List;
import java.util.Optional;

/**
 * Virus Vial — throwable item that breaks on impact and exposes nearby entities to the stored virus.
 *
 * NBT key: "VirusId" (same convention as the syringe).
 * Throw with right-click; the projectile entity handles impact logic.
 */
public class VirusVialItem extends Item {

    public static final String NBT_VIRUS_ID = "VirusId";
    public static final String DEFAULT_VIRUS = "influenza";

    public VirusVialItem(Properties properties) {
        super(properties);
    }

    public static String getLoadedVirus(ItemStack stack) {
        CompoundTag tag = stack.getTag();
        if (tag != null && tag.contains(NBT_VIRUS_ID)) {
            return tag.getString(NBT_VIRUS_ID);
        }
        return DEFAULT_VIRUS;
    }

    public static void setLoadedVirus(ItemStack stack, String virusId) {
        stack.getOrCreateTag().putString(NBT_VIRUS_ID, virusId);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);

        level.playSound(null, player.getX(), player.getY(), player.getZ(),
                SoundEvents.SPLASH_POTION_THROW, SoundSource.PLAYERS,
                0.5f, 0.4f / (level.getRandom().nextFloat() * 0.4f + 0.8f));

        if (!level.isClientSide()) {
            String virusId = getLoadedVirus(stack);
            VirusVialEntity vial = new VirusVialEntity(level, player, virusId);
            vial.setItem(stack);
            vial.shootFromRotation(player, player.getXRot(), player.getYRot(), 0.0f, 1.5f, 1.0f);
            level.addFreshEntity(vial);
        }

        if (!player.getAbilities().instabuild) {
            stack.shrink(1);
        }

        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide());
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level,
                                 List<Component> tooltip, TooltipFlag flag) {
        String virusId = getLoadedVirus(stack);
        Optional<Virus> virus = VirusRegistry.get(virusId);
        String displayName = virus.map(v -> v.getId()).orElse(virusId + " (unknown)");
        tooltip.add(Component.literal("Contains: " + displayName).withStyle(ChatFormatting.RED));
        tooltip.add(Component.literal("Right-click to throw").withStyle(ChatFormatting.GRAY));
        tooltip.add(Component.literal("Breaks on impact, exposing nearby entities").withStyle(ChatFormatting.DARK_GRAY));
    }
}
