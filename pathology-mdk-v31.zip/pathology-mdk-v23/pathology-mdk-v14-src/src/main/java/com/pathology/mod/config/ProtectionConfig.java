package com.pathology.mod.config;

import net.minecraftforge.common.ForgeConfigSpec;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * COMMON config (loaded on both client and server) for protective equipment entries.
 * Kept separate from VirusConfig (SERVER) so the client can read protection values
 * for item tooltips without needing a server connection.
 */
public class ProtectionConfig {

    public static final ForgeConfigSpec SPEC;
    public static final ForgeConfigSpec.ConfigValue<List<? extends String>> PROTECTION_ENTRIES;

    /** Cached map rebuilt whenever the config is loaded or reloaded. */
    private static Map<String, Double> cachedMap = null;

    static {
        ForgeConfigSpec.Builder b = new ForgeConfigSpec.Builder();

        b.comment(
            "=== Protective Equipment ===",
            "Flat alternating list: item registry id (e.g. minecraft:leather_helmet or modid:custom_item), then protection value (0.0-1.0).",
            "Values stack up to 1.0. Supports any Forge-registered item from any mod."
        ).push("protection");

        PROTECTION_ENTRIES = b.defineList("items", List.of(
            // ── Vanilla leather ───────────────────────────────────────────────
            "minecraft:leather_helmet",                             "0.05",
            "minecraft:leather_chestplate",                         "0.05",
            "minecraft:leather_leggings",                           "0.05",
            "minecraft:leather_boots",                              "0.05",
            // ── Vanilla chainmail ─────────────────────────────────────────────
            "minecraft:chainmail_helmet",                           "0.05",
            "minecraft:chainmail_chestplate",                       "0.05",
            "minecraft:chainmail_leggings",                         "0.05",
            "minecraft:chainmail_boots",                            "0.05",
            // ── Vanilla iron ──────────────────────────────────────────────────
            "minecraft:iron_helmet",                                "0.10",
            "minecraft:iron_chestplate",                            "0.10",
            "minecraft:iron_leggings",                              "0.10",
            "minecraft:iron_boots",                                 "0.10",
            // ── Vanilla gold ──────────────────────────────────────────────────
            "minecraft:golden_helmet",                              "0.10",
            "minecraft:golden_chestplate",                          "0.10",
            "minecraft:golden_leggings",                            "0.10",
            "minecraft:golden_boots",                               "0.10",
            // ── Vanilla diamond ───────────────────────────────────────────────
            "minecraft:diamond_helmet",                             "0.15",
            "minecraft:diamond_chestplate",                         "0.15",
            "minecraft:diamond_leggings",                           "0.15",
            "minecraft:diamond_boots",                              "0.15",
            // ── Vanilla netherite ─────────────────────────────────────────────
            "minecraft:netherite_helmet",                           "0.20",
            "minecraft:netherite_chestplate",                       "0.20",
            "minecraft:netherite_leggings",                         "0.20",
            "minecraft:netherite_boots",                            "0.20",
            // ── Marbled's Arsenal: berets (cosmetic) ──────────────────────────
            "marbledsarsenal:red_military_beret",                   "0.00",
            "marbledsarsenal:un_military_beret",                    "0.00",
            "marbledsarsenal:black_military_beret",                 "0.00",
            // ── Marbled's Arsenal: combat helmets ─────────────────────────────
            "marbledsarsenal:combat_helmet",                        "0.05",
            "marbledsarsenal:olive_combat_helmet",                  "0.05",
            "marbledsarsenal:un_combat_helmet",                     "0.05",
            // ── Marbled's Arsenal: gas masks ──────────────────────────────────
            "marbledsarsenal:cm6m_gas_mask",                        "0.65",
            "marbledsarsenal:cm7m_gas_mask",                        "0.70",
            "marbledsarsenal:cm8m_gas_mask",                        "0.75",
            "marbledsarsenal:helmet_cm6m_gas_mask",                 "0.70",
            "marbledsarsenal:helmet_cm7m_gas_mask",                 "0.75",
            "marbledsarsenal:helmet_cm8m_gas_mask",                 "0.80",
            "marbledsarsenal:olive_helmet_cm6m_gas_mask",           "0.70",
            "marbledsarsenal:olive_helmet_cm7m_gas_mask",           "0.75",
            "marbledsarsenal:olive_helmet_cm8m_gas_mask",           "0.80",
            "marbledsarsenal:un_helmet_cm6m_gas_mask",              "0.70",
            "marbledsarsenal:un_helmet_cm7m_gas_mask",              "0.75",
            "marbledsarsenal:un_helmet_cm8m_gas_mask",              "0.80",
            "marbledsarsenal:white_gp5_gas_mask",                   "0.45",
            "marbledsarsenal:black_gp5_gas_mask",                   "0.45",
            // ── Marbled's Arsenal: plate carriers ─────────────────────────────
            "marbledsarsenal:black_plate_carrier_light",            "0.10",
            "marbledsarsenal:black_plate_carrier_heavy",            "0.15",
            "marbledsarsenal:olive_plate_carrier_light",            "0.10",
            "marbledsarsenal:olive_plate_carrier_heavy",            "0.15",
            // ── Marbled's Arsenal: riot armor ─────────────────────────────────
            "marbledsarsenal:riot_armor_helmet",                    "0.20",
            "marbledsarsenal:riot_armor_chestplate",                "0.15",
            "marbledsarsenal:riot_armor_leggings",                  "0.10",
            "marbledsarsenal:riot_armor_boots",                     "0.05",
            // ── Marbled's Arsenal: SWAT armor ─────────────────────────────────
            "marbledsarsenal:swat_armor_helmet",                    "0.15",
            "marbledsarsenal:swat_armor_chestplate",                "0.10",
            "marbledsarsenal:swat_armor_leggings",                  "0.05",
            "marbledsarsenal:swat_armor_boots",                     "0.05",
            // ── Marbled's Arsenal: hazmat armor ───────────────────────────────
            "marbledsarsenal:hazmat_armor_helmet",                  "0.95",
            "marbledsarsenal:hazmat_armor_chestplate",              "0.90",
            "marbledsarsenal:hazmat_armor_leggings",                "0.85",
            "marbledsarsenal:hazmat_armor_boots",                   "0.80",
            // ── Marbled's Arsenal: black juggernaut armor ─────────────────────
            "marbledsarsenal:black_juggernaut_armor_helmet",        "0.25",
            "marbledsarsenal:black_juggernaut_armor_chestplate",    "0.20",
            "marbledsarsenal:black_juggernaut_armor_leggings",      "0.15",
            "marbledsarsenal:black_juggernaut_armor_boots",         "0.10",
            // ── Marbled's Arsenal: olive juggernaut armor ─────────────────────
            "marbledsarsenal:olive_juggernaut_armor_helmet",        "0.25",
            "marbledsarsenal:olive_juggernaut_armor_chestplate",    "0.20",
            "marbledsarsenal:olive_juggernaut_armor_leggings",      "0.15",
            "marbledsarsenal:olive_juggernaut_armor_boots",         "0.10"
        ), e -> e instanceof String);

        b.pop();
        SPEC = b.build();
    }

    /** Call this when the config loads/reloads to warm the cache. */
    public static void invalidateCache() {
        cachedMap = null;
    }

    /** Returns the cached protection map, building it on first access. */
    public static Map<String, Double> getProtectionMap() {
        if (cachedMap == null) {
            Map<String, Double> map = new HashMap<>();
            List<? extends String> entries = PROTECTION_ENTRIES.get();
            for (int i = 0; i + 1 < entries.size(); i += 2) {
                try { map.put(entries.get(i), Double.parseDouble(entries.get(i + 1))); }
                catch (NumberFormatException ignored) {}
            }
            cachedMap = map;
        }
        return cachedMap;
    }
}
