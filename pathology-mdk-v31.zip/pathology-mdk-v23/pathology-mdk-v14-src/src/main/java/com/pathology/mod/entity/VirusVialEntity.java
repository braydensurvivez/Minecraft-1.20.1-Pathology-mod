package com.pathology.mod.entity;

import com.pathology.mod.util.ProtectionUtil;
import com.pathology.mod.virus.Virus;
import com.pathology.mod.virus.VirusManager;
import com.pathology.mod.virus.VirusRegistry;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.ThrowableItemProjectile;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraftforge.network.NetworkHooks;

import java.util.List;
import java.util.Optional;
import java.util.Random;

/**
 * Projectile for the Virus Vial. Shatters on impact and infects nearby entities.
 */
public class VirusVialEntity extends ThrowableItemProjectile {

    private static final double SPLASH_RADIUS = 4.0;
    private static final Random RNG = new Random();
    private String virusId = "influenza";

    /** Deserialization constructor (required by EntityType) */
    public VirusVialEntity(EntityType<? extends VirusVialEntity> type, Level level) {
        super(type, level);
    }

    /** Spawn constructor called when player throws the vial */
    public VirusVialEntity(Level level, LivingEntity thrower, String virusId) {
        super(ModEntityTypes.VIRUS_VIAL.get(), thrower, level);
        this.virusId = virusId;
    }

    @Override
    protected Item getDefaultItem() {
        return Items.GLASS_BOTTLE;
    }

    @Override
    protected void onHit(HitResult result) {
        super.onHit(result);
        if (!this.level().isClientSide()) {
            shatter((ServerLevel) this.level());
        }
    }

    @Override
    protected void onHitEntity(EntityHitResult result) {
        super.onHitEntity(result);
        // Direct hit always infects
        if (!this.level().isClientSide() && result.getEntity() instanceof LivingEntity target) {
            VirusRegistry.get(virusId).ifPresent(v -> {
                if (!VirusManager.isInfected(target, virusId)) {
                    VirusManager.infect(target, v);
                }
            });
        }
    }

    private void shatter(ServerLevel level) {
        Optional<Virus> virusOpt = VirusRegistry.get(virusId);
        if (virusOpt.isEmpty()) { this.discard(); return; }
        Virus virus = virusOpt.get();

        // Red particle burst at impact point
        for (int i = 0; i < 30; i++) {
            double ox = (RNG.nextDouble() - 0.5) * 2.0;
            double oy = RNG.nextDouble() * 1.5;
            double oz = (RNG.nextDouble() - 0.5) * 2.0;
            level.sendParticles(ParticleTypes.DAMAGE_INDICATOR,
                this.getX() + ox, this.getY() + oy, this.getZ() + oz,
                1, 0.1, 0.1, 0.1, 0.05);
        }
        for (int i = 0; i < 15; i++) {
            double ox = (RNG.nextDouble() - 0.5) * 3.0;
            double oz = (RNG.nextDouble() - 0.5) * 3.0;
            level.sendParticles(ParticleTypes.FALLING_HONEY,
                this.getX() + ox, this.getY() + 0.3, this.getZ() + oz,
                1, 0.2, 0.1, 0.2, 0.0);
        }

        // Infect all entities in splash radius
        AABB box = new AABB(
            this.getX() - SPLASH_RADIUS, this.getY() - 1, this.getZ() - SPLASH_RADIUS,
            this.getX() + SPLASH_RADIUS, this.getY() + SPLASH_RADIUS, this.getZ() + SPLASH_RADIUS
        );
        List<LivingEntity> nearby = level.getEntitiesOfClass(LivingEntity.class, box,
            e -> !VirusManager.isInfected(e, virusId));

        for (LivingEntity target : nearby) {
            double dist = this.distanceTo(target);
            if (dist > SPLASH_RADIUS) continue;
            double distFactor = 1.0 - (dist / SPLASH_RADIUS);
            double protection = ProtectionUtil.getProtectionReduction(target);
            double chance = distFactor * (1.0 - protection);
            if (RNG.nextDouble() < chance) {
                VirusManager.infect(target, virus);
            }
        }

        this.discard();
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putString("VirusId", virusId);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        if (tag.contains("VirusId")) virusId = tag.getString("VirusId");
    }

    @Override
    public Packet<ClientGamePacketListener> getAddEntityPacket() {
        return NetworkHooks.getEntitySpawningPacket(this);
    }
}
