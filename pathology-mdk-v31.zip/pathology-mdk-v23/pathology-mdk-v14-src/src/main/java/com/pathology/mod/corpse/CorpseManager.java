package com.pathology.mod.corpse;

import com.pathology.mod.PathologyMod;
import com.pathology.mod.config.CorpseLootConfig;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.phys.Vec3;

import java.util.*;

/**
 * Central manager for all active corpses in a level.
 *
 * v18 changes:
 *  - MAX_PER_CHUNK reduced to 3, MAX_GLOBAL reduced to 50
 *  - Corpses auto-despawn after 5 minutes (6000 ticks)
 *  - INFECTION_CHECK_TICKS raised to 80
 *  - Airborne infection chance halved (BASE_CHANCE 0.025, MAX_CHANCE 0.05)
 *
 * v19 fixes:
 *  - Idle-despawn timer now uses spawnTime (real game-time when registered)
 *    instead of deathTime, so bodies that survive a server reload correctly
 *    start their 1-minute idle clock from when the server next ticks them,
 *    rather than from their (possibly ancient) death timestamp.
 *  - spawnTime map added; cleaned up across all add/remove/clear/load paths.
 *
 * v20 changes (performance):
 *  - Despawn timer is now a fixed 1-minute lifetime from spawnTime — it no
 *    longer resets on loot/interaction.  Bodies always despawn 1 minute after
 *    they are registered, regardless of whether they were opened or looted.
 *  - lastLootedTime map and markLooted() removed entirely.
 *
 * v21 changes:
 *  - INFECTION_RADIUS reduced from 5.0 to 2.0 blocks (tight airborne zone).
 *  - touchedCorpses set added: call markTouched(UUID) when a player opens or
 *    body-bags a corpse.  Untouched corpses that expire are destroyed via the
 *    fire-removal code path (destroyByFire) so the CorpseEntity is cleanly
 *    killed exactly as flint-and-steel does, without orphaned entities.
 *  - Touched corpses that expire are also cleanly removed (no silent discard).
 */
public class CorpseManager {

    // ── Limits ────────────────────────────────────────────────────────────────
    public static final int    MAX_PER_CHUNK  = 3;
    public static final int    MAX_GLOBAL     = 50;
    public static final double MERGE_RADIUS   = 2.0;

    // ── Decay thresholds ──────────────────────────────────────────────────────
    public static final long DECAY_STAGE_1_TICKS =  6_000L;
    public static final long DECAY_STAGE_2_TICKS = 18_000L;
    public static final long DECAY_DESPAWN_TICKS  = 36_000L;

    /** Ticks before the corpse auto-despawns (5 minutes). */
    public static final long UNLOOT_DESPAWN_TICKS = 6000L; // 5 minutes

    // ── Corpse proximity-infection parameters ─────────────────────────────────
    /** Reduced to 2 blocks in v21 — tight airborne zone around corpse only. */
    public static final double INFECTION_RADIUS      = 2.0;
    public static final int    FULL_EXPOSURE_TICKS   = 1200;
    /** Base chance per check – halved from v17 (was 0.05). */
    public static final double BASE_CHANCE           = 0.025;
    /** Max chance per check – halved from v17 (was 0.10). */
    public static final double MAX_CHANCE            = 0.05;
    public static final int    INFECTION_CHECK_TICKS = 80;

    // ── State ─────────────────────────────────────────────────────────────────
    private final Map<UUID, CorpseData> corpses        = new LinkedHashMap<>();
    private final Map<UUID, Integer>    exposureTicks  = new HashMap<>();
    /** Tracks the real game-time when each corpse was registered (used for fixed 1-min despawn). */
    private final Map<UUID, Long>       spawnTime      = new HashMap<>();
    private final Map<UUID, Long>       burningCorpses = new HashMap<>();
    /** Corpses that a player has interacted with (opened or body-bagged).
     *  When an untouched corpse expires its lifetime it is destroyed via the
     *  fire code path so the CorpseEntity is removed cleanly. */
    private final java.util.Set<UUID>   touchedCorpses = new java.util.HashSet<>();

    private static final long BURN_DURATION_TICKS = 100L;
    private static final CorpseManager INSTANCE = new CorpseManager();
    public  static CorpseManager get() { return INSTANCE; }
    private CorpseManager() {}
    private static final Random RNG = new Random();

    // ── Public API ────────────────────────────────────────────────────────────

    public UUID addCorpse(ServerLevel level, CorpseData data) {
        if (tryMerge(data)) {
            PathologyMod.LOGGER.debug("Corpse merged into pile at {}", data.deathPos);
            return null;
        }
        long chunkKey = chunkKey(data.deathPos);
        long chunkCount = corpses.values().stream()
            .filter(c -> chunkKey(c.deathPos) == chunkKey).count();
        if (chunkCount >= MAX_PER_CHUNK) removeOldestInChunk(chunkKey);
        if (corpses.size() >= MAX_GLOBAL)  removeOldest();

        UUID id = UUID.randomUUID();
        data.lootItems = CorpseLootConfig.generateLoot(level.random);
        corpses.put(id, data);
        long now = level.getGameTime();
        spawnTime.put(id, now);
        PathologyMod.LOGGER.debug("Corpse added [{}]: {} at {}", id, data.entityTypeId, data.deathPos);
        return id;
    }


    public void destroyByFire(UUID corpseId, ServerLevel level) {
        CorpseData data = corpses.remove(corpseId);
        if (data == null) return;
        spawnTime.remove(corpseId);
        burningCorpses.put(corpseId, level.getGameTime());
        PathologyMod.LOGGER.debug("Corpse {} set on fire (data removed)", corpseId);
        level.sendParticles(ParticleTypes.LARGE_SMOKE,
            data.deathPos.x, data.deathPos.y + 0.5, data.deathPos.z, 20, 0.4, 0.5, 0.4, 0.02);
        level.sendParticles(ParticleTypes.FLAME,
            data.deathPos.x, data.deathPos.y + 0.3, data.deathPos.z, 15, 0.3, 0.3, 0.3, 0.02);
    }

    public void remove(UUID corpseId) {
        corpses.remove(corpseId);
        burningCorpses.remove(corpseId);
        spawnTime.remove(corpseId);
        touchedCorpses.remove(corpseId);
    }

    /** Call this whenever a player opens or body-bags the corpse.
     *  Touched corpses still despawn on schedule but via a clean remove (no
     *  fire effect), while untouched ones are destroyed via the burn path so
     *  the CorpseEntity is properly killed. */
    public void markTouched(UUID corpseId) {
        touchedCorpses.add(corpseId);
    }

    public boolean wasTouched(UUID corpseId) {
        return touchedCorpses.contains(corpseId);
    }

    public void tick(ServerLevel level) {
        long now = level.getGameTime();
        // Single removal list — every expired corpse goes here regardless of
        // whether it was touched.  discardEntityById() is called immediately so
        // the CorpseEntity is gone the same tick the timer fires.  No multi-step
        // fire state machine is needed for auto-despawn; fire visuals are only
        // used for player-triggered ignition (flint-and-steel / fire charge).
        List<UUID> toRemove = new ArrayList<>();

        for (Map.Entry<UUID, CorpseData> entry : corpses.entrySet()) {
            UUID id = entry.getKey();
            CorpseData d = entry.getValue();
            long age = now - d.deathTime;

            // ── Fixed 1-minute lifetime despawn ───────────────────────────
            // -1L is the sentinel set on server reload — reset to now so the
            // body gets a fresh 1-minute window after each reload.
            long registeredAt = spawnTime.getOrDefault(id, now);
            if (registeredAt == -1L) { spawnTime.put(id, now); registeredAt = now; }
            if (now - registeredAt >= UNLOOT_DESPAWN_TICKS) {
                toRemove.add(id);
                PathologyMod.LOGGER.debug("Corpse {} queued for removal (1 min lifetime expired)", id);
                continue;
            }

            int oldStage = d.decayStage;
            if      (age >= DECAY_DESPAWN_TICKS) { toRemove.add(id); continue; }
            else if (age >= DECAY_STAGE_2_TICKS) d.decayStage = 2;
            else if (age >= DECAY_STAGE_1_TICKS) d.decayStage = 1;
            if (d.decayStage != oldStage)
                PathologyMod.LOGGER.debug("Corpse decay {} → {} at {}", oldStage, d.decayStage, d.deathPos);
        }

        for (Iterator<Map.Entry<UUID, Long>> it = burningCorpses.entrySet().iterator(); it.hasNext();) {
            Map.Entry<UUID, Long> e = it.next();
            if (now - e.getValue() >= BURN_DURATION_TICKS) {
                it.remove();
                PathologyMod.LOGGER.debug("Burn timer expired for {}", e.getKey());
            }
        }

        // Remove manager data AND kill the world entity atomically via /kill path.
        toRemove.forEach(id -> {
            corpses.remove(id);
            spawnTime.remove(id);
            touchedCorpses.remove(id);
            discardEntityById(id, level); // uses kill() internally
            PathologyMod.LOGGER.debug("Corpse {} removed + entity killed (1-min timer)", id);
        });

        if (now % INFECTION_CHECK_TICKS == 0 && !corpses.isEmpty()) tickCorpseInfection(level, now);
    }

    private void tickCorpseInfection(ServerLevel level, long now) {
        for (net.minecraft.server.level.ServerPlayer player : level.players()) {
            UUID pid = player.getUUID();

            // Creative and Spectator players are fully immune to corpse infection.
            net.minecraft.world.level.GameType gm = player.gameMode.getGameModeForPlayer();
            if (gm == net.minecraft.world.level.GameType.CREATIVE
                    || gm == net.minecraft.world.level.GameType.SPECTATOR) {
                // Drain any accumulated exposure so switching back to survival
                // doesn't carry a hidden infection debt.
                exposureTicks.remove(pid);
                continue;
            }

            boolean nearCorpse = corpses.values().stream()
                .anyMatch(d -> d.deathPos.distanceTo(player.position()) <= INFECTION_RADIUS);

            if (nearCorpse) {
                int ticks = exposureTicks.getOrDefault(pid, 0) + INFECTION_CHECK_TICKS;
                exposureTicks.put(pid, ticks);
                double t = Math.min(1.0, (double) ticks / FULL_EXPOSURE_TICKS);
                double chance = BASE_CHANCE + t * (MAX_CHANCE - BASE_CHANCE);
                if (RNG.nextDouble() < chance) {
                    com.pathology.mod.virus.VirusRegistry.get("decay_disease")
                        .ifPresent(v -> com.pathology.mod.virus.VirusManager.infect(player, v));
                    com.pathology.mod.virus.VirusRegistry.get("airbornehuskflu")
                        .ifPresent(v -> com.pathology.mod.virus.VirusManager.infect(player, v));
                    exposureTicks.put(pid, 0);
                }
            } else {
                int ticks = exposureTicks.getOrDefault(pid, 0);
                if (ticks > 0) exposureTicks.put(pid, Math.max(0, ticks - INFECTION_CHECK_TICKS));
            }
        }
    }

    // ── Query helpers ─────────────────────────────────────────────────────────
    public Collection<CorpseData> all()        { return Collections.unmodifiableCollection(corpses.values()); }
    public Optional<CorpseData>   get(UUID id) { return Optional.ofNullable(corpses.get(id)); }
    public int                    size()        { return corpses.size(); }
    public boolean                isBurning(UUID id) { return burningCorpses.containsKey(id); }
    public long                   getBurnStartTime(UUID id) { return burningCorpses.getOrDefault(id, -1L); }
    public static long            getBurnDuration() { return BURN_DURATION_TICKS; }

    public Optional<UUID> getUUIDAt(Vec3 pos) {
        return corpses.entrySet().stream()
            .filter(e -> e.getValue().deathPos.distanceTo(pos) < 1.0)
            .map(Map.Entry::getKey).findFirst();
    }

    public void clear() {
        corpses.clear();
        burningCorpses.clear();
        exposureTicks.clear();
        spawnTime.clear();
        touchedCorpses.clear();
    }

    /**
     * Removes ALL corpses from both the manager and the world using the /kill command path.
     * Every CorpseEntity in the level is killed immediately so nothing is left
     * behind as an orphan.  Used by the /pathology clearcorpses command.
     *
     * @return the number of corpses that were removed
     */
    public int clearAll(ServerLevel level) {
        int count = corpses.size();

        // Kill every CorpseEntity currently in the world via kill() — the same
        // code path as the /kill command — so they are properly removed.
        net.minecraft.world.phys.AABB everywhere = new net.minecraft.world.phys.AABB(
            -Double.MAX_VALUE, -Double.MAX_VALUE, -Double.MAX_VALUE,
             Double.MAX_VALUE,  Double.MAX_VALUE,  Double.MAX_VALUE);
        for (com.pathology.mod.entity.CorpseEntity ce :
                new java.util.ArrayList<>(level.getEntitiesOfClass(com.pathology.mod.entity.CorpseEntity.class, everywhere))) {
            ce.kill();
        }

        // Wipe all manager state.
        corpses.clear();
        burningCorpses.clear();
        exposureTicks.clear();
        spawnTime.clear();
        touchedCorpses.clear();

        PathologyMod.LOGGER.info("clearAll: /kill-ed {} corpse record(s) and all CorpseEntities.", count);
        return count;
    }

    // ── Persistence ───────────────────────────────────────────────────────────
    public CompoundTag saveAll() {
        CompoundTag root = new CompoundTag();
        ListTag list = new ListTag();
        for (Map.Entry<UUID, CorpseData> e : corpses.entrySet()) {
            CompoundTag entry = e.getValue().save();
            entry.putUUID("corpseId", e.getKey());
            list.add(entry);
        }
        root.put("corpses", list);
        return root;
    }

    public void loadAll(CompoundTag root) {
        corpses.clear();
        spawnTime.clear();
        if (!root.contains("corpses", Tag.TAG_LIST)) return;
        ListTag list = root.getList("corpses", Tag.TAG_COMPOUND);
        for (int i = 0; i < list.size(); i++) {
            CompoundTag entry = list.getCompound(i);
            UUID id = entry.getUUID("corpseId");
            CorpseData data = CorpseData.load(entry);
            corpses.put(id, data);
            // spawnTime not persisted — use -1L as sentinel so the first tick
            // resets the timer to the current game-time (giving the body a
            // fresh 1-minute window after every server reload).
            spawnTime.put(id, -1L);
        }
        PathologyMod.LOGGER.info("Loaded {} corpse record(s).", corpses.size());
    }

    // ── Private helpers ───────────────────────────────────────────────────────
    private boolean tryMerge(CorpseData incoming) {
        for (CorpseData existing : corpses.values())
            if (existing.deathPos.distanceTo(incoming.deathPos) <= MERGE_RADIUS) { existing.bodyCount++; return true; }
        return false;
    }

    private void removeOldest() {
        corpses.entrySet().stream().findFirst().map(Map.Entry::getKey)
            .ifPresent(id -> { corpses.remove(id); spawnTime.remove(id); });
    }

    private void removeOldestInChunk(long chunkKey) {
        corpses.entrySet().stream().filter(e -> chunkKey(e.getValue().deathPos) == chunkKey)
            .findFirst().map(Map.Entry::getKey)
            .ifPresent(id -> { corpses.remove(id); spawnTime.remove(id); });
    }

    /** Find and immediately discard the CorpseEntity whose CORPSE_UUID matches id. */
    /** Kill the CorpseEntity whose UUID matches id, using the /kill command path (kill()). */
    private static void discardEntityById(UUID id, ServerLevel level) {
        net.minecraft.world.phys.AABB everywhere = new net.minecraft.world.phys.AABB(
            -Double.MAX_VALUE, -Double.MAX_VALUE, -Double.MAX_VALUE,
             Double.MAX_VALUE,  Double.MAX_VALUE,  Double.MAX_VALUE);
        for (com.pathology.mod.entity.CorpseEntity ce :
                level.getEntitiesOfClass(com.pathology.mod.entity.CorpseEntity.class, everywhere)) {
            if (id.equals(ce.getCorpseUUID())) {
                ce.kill(); // equivalent to /kill — uses the damage system now that corpses are mortal
                return;
            }
        }
    }

    private static long chunkKey(Vec3 pos) {
        int cx = (int) Math.floor(pos.x) >> 4;
        int cz = (int) Math.floor(pos.z) >> 4;
        return ((long) cx & 0xFFFFFFFFL) | (((long) cz & 0xFFFFFFFFL) << 32);
    }
}
