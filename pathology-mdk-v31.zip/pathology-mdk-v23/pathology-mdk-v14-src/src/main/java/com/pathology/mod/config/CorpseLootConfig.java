package com.pathology.mod.config;

import com.pathology.mod.PathologyMod;
import net.minecraft.util.RandomSource;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraftforge.common.ForgeConfigSpec;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraft.resources.ResourceLocation;

import java.util.*;

/**
 * Configures the randomised loot that populates a corpse's 9-slot inventory.
 *
 * Config file: pathologymod-corpse-loot.toml  (type: SERVER)
 *
 * ── Pool format ───────────────────────────────────────────────────────────────
 * Flat list of groups of 4 strings:
 *   "itemId"   – Forge registry key, e.g. "minecraft:arrow" or "mymod:shotgun"
 *   "weight"   – relative probability (higher = more common)
 *   "minCount" – minimum stack size
 *   "maxCount" – maximum stack size
 *
 * Example TOML entry to add a modded item:
 *   corpseLoot.pool = [ ..., "mymod:bandage", "15", "1", "3", ... ]
 *
 * Unknown registry keys are skipped with a WARN log so a missing mod will not
 * crash the game, it will just silently omit that entry.
 *
 * ── Slot count ────────────────────────────────────────────────────────────────
 * corpseLoot.minSlots / maxSlots control how many of the 9 inventory slots
 * are filled.  Each filled slot draws one independent weighted roll from the
 * pool, so the same item can appear in multiple slots.
 *
 * ── Default pool categories ───────────────────────────────────────────────────
 *  • Ammo      – arrows, gunpowder (reload analogue)
 *  • Bandages  – paper, string (field dressing analogue)
 *  • Food      – rotten flesh, bread, cooked beef
 *  • Infection – spider eyes, fermented spider eye (infection sample analogue)
 *  • Money     – gold/iron nuggets, emeralds
 *  • Tools     – flint & steel, shears, iron sword, chainmail helm
 *  • Misc      – bone, leather, gravel, flint
 */
public class CorpseLootConfig {

    public static final ForgeConfigSpec SPEC;

    /** Number of loot slots to fill: rolls between minSlots and maxSlots. */
    public static final ForgeConfigSpec.IntValue MIN_SLOTS;
    public static final ForgeConfigSpec.IntValue MAX_SLOTS;

    /**
     * Flat loot pool: groups of 4 strings per entry.
     *   [itemId, weight, minCount, maxCount, ...]
     *
     * Kept as a flat list because Forge TOML does not support nested tables
     * without a custom codec.  4-token grouping is enforced in buildPool().
     */
    public static final ForgeConfigSpec.ConfigValue<List<? extends String>> LOOT_POOL;

    static {
        ForgeConfigSpec.Builder b = new ForgeConfigSpec.Builder();

        b.comment(
            "=== Pathology Mod – Corpse Loot Configuration ===",
            "",
            "Controls what items randomly appear inside a corpse's inventory when",
            "a mob dies and its corpse entity spawns.",
            "",
            "Supports any item registered in the Forge item registry, including",
            "items added by other mods (e.g. \"mymod:shotgun\").",
            "",
            "Pool format – flat list, 4 strings per entry:",
            "  [\"itemId\", \"weight\", \"minCount\", \"maxCount\", ...]",
            "",
            "  itemId    – Forge registry key (namespace:path)",
            "  weight    – relative draw weight; higher = more common",
            "  minCount  – minimum items in the stack",
            "  maxCount  – maximum items in the stack",
            "",
            "Unknown item IDs are silently skipped (log level WARN)."
        ).push("corpseLoot");

        MIN_SLOTS = b
            .comment("Minimum number of inventory slots to fill per corpse (0–9).")
            .defineInRange("minSlots", 2, 0, 9);

        MAX_SLOTS = b
            .comment("Maximum number of inventory slots to fill per corpse (0–9).",
                     "Must be >= minSlots.")
            .defineInRange("maxSlots", 5, 0, 9);

        LOOT_POOL = b.comment(
            "Weighted item pool.  Flat list of groups of 4 strings.",
            "Format: [\"itemId\", \"weight\", \"minCount\", \"maxCount\", ...]",
            "",
            "--- AMMO ---",
            "  minecraft:arrow           weight 35  count 1-8",
            "  minecraft:gunpowder       weight 20  count 1-3",
            "",
            "--- BANDAGES (field dressing analogues) ---",
            "  minecraft:paper           weight 30  count 1-4",
            "  minecraft:string          weight 25  count 1-3",
            "",
            "--- FOOD ---",
            "  minecraft:rotten_flesh    weight 60  count 1-3",
            "  minecraft:bread           weight 20  count 1-2",
            "  minecraft:cooked_beef     weight 10  count 1-2",
            "",
            "--- INFECTION SAMPLES ---",
            "  minecraft:spider_eye            weight 15  count 1-2",
            "  minecraft:fermented_spider_eye  weight  8  count 1-1",
            "",
            "--- MONEY ---",
            "  minecraft:gold_nugget     weight 20  count 1-4",
            "  minecraft:iron_nugget     weight 25  count 1-6",
            "  minecraft:emerald         weight  5  count 1-1",
            "",
            "--- TOOLS ---",
            "  minecraft:flint_and_steel weight  8  count 1-1",
            "  minecraft:shears          weight  6  count 1-1",
            "  minecraft:iron_sword      weight  5  count 1-1",
            "  minecraft:chainmail_helmet weight 3  count 1-1",
            "",
            "--- MISC ---",
            "  minecraft:bone            weight 50  count 1-4",
            "  minecraft:leather         weight 15  count 1-2",
            "  minecraft:flint           weight 20  count 1-3",
            "  minecraft:gravel          weight 12  count 1-2",
            "",
            "To add a modded item append 4 more strings, e.g.:",
            "  ..., \"mymod:bandage_roll\", \"20\", \"1\", \"3\""
        ).defineList("pool", List.of(
            // ── AMMO ──────────────────────────────────────────────────────────
            "minecraft:arrow",                "35", "1", "8",
            "minecraft:gunpowder",            "20", "1", "3",
            // ── BANDAGES (paper + string as field-dressing analogues) ─────────
            "minecraft:paper",                "30", "1", "4",
            "minecraft:string",               "25", "1", "3",
            // ── FOOD ──────────────────────────────────────────────────────────
            "minecraft:rotten_flesh",         "60", "1", "3",
            "minecraft:bread",                "20", "1", "2",
            "minecraft:cooked_beef",          "10", "1", "2",
            // ── INFECTION SAMPLES ─────────────────────────────────────────────
            "minecraft:spider_eye",           "15", "1", "2",
            "minecraft:fermented_spider_eye", "8",  "1", "1",
            // ── MONEY ─────────────────────────────────────────────────────────
            "minecraft:gold_nugget",          "20", "1", "4",
            "minecraft:iron_nugget",          "25", "1", "6",
            "minecraft:emerald",              "5",  "1", "1",
            // ── TOOLS ─────────────────────────────────────────────────────────
            "minecraft:flint_and_steel",      "8",  "1", "1",
            "minecraft:shears",               "6",  "1", "1",
            "minecraft:iron_sword",           "5",  "1", "1",
            "minecraft:chainmail_helmet",     "3",  "1", "1",
            // ── MISC ──────────────────────────────────────────────────────────
            "minecraft:bone",                 "50", "1", "4",
            "minecraft:leather",              "15", "1", "2",
            "minecraft:flint",                "20", "1", "3",
            "minecraft:gravel",               "12", "1", "2"
        ), e -> e instanceof String);

        b.pop();
        SPEC = b.build();
    }

    // ── Loot generation ───────────────────────────────────────────────────────

    /** Weighted entry parsed from config. */
    private record LootEntry(ResourceLocation itemId, int weight, int minCount, int maxCount) {}

    /**
     * Draw a randomised list of ItemStack from the configured pool.
     * Returns between minSlots and maxSlots stacks (capped at 9).
     *
     * Called by CorpseManager.addCorpse() on the server thread only.
     */
    public static List<ItemStack> generateLoot(RandomSource rng) {
        List<LootEntry> pool = buildPool();
        if (pool.isEmpty()) return List.of();

        int totalWeight = pool.stream().mapToInt(LootEntry::weight).sum();
        if (totalWeight <= 0) return List.of();

        int minSlots = MIN_SLOTS.get();
        int maxSlots = MAX_SLOTS.get();
        // Guard against misconfiguration (maxSlots < minSlots)
        if (maxSlots < minSlots) maxSlots = minSlots;
        int slotCount = minSlots + rng.nextInt(maxSlots - minSlots + 1);
        slotCount = Math.min(slotCount, 9);

        List<ItemStack> result = new ArrayList<>();
        for (int i = 0; i < slotCount; i++) {
            LootEntry entry = weightedPick(pool, totalWeight, rng);
            if (entry == null) continue;

            var item = ForgeRegistries.ITEMS.getValue(entry.itemId());
            if (item == null || item == Items.AIR) {
                PathologyMod.LOGGER.warn(
                    "CorpseLootConfig: unknown item '{}' in loot pool, skipping.", entry.itemId());
                continue;
            }

            int count = entry.minCount()
                + rng.nextInt(Math.max(1, entry.maxCount() - entry.minCount() + 1));
            result.add(new ItemStack(item, count));
        }
        return result;
    }

    // ── Private helpers ───────────────────────────────────────────────────────

    private static LootEntry weightedPick(List<LootEntry> pool, int totalWeight, RandomSource rng) {
        int roll = rng.nextInt(totalWeight);
        int cum  = 0;
        for (LootEntry e : pool) {
            cum += e.weight();
            if (roll < cum) return e;
        }
        return pool.isEmpty() ? null : pool.get(pool.size() - 1);
    }

    private static List<LootEntry> buildPool() {
        List<? extends String> raw = LOOT_POOL.get();
        List<LootEntry> pool = new ArrayList<>();
        for (int i = 0; i + 3 < raw.size(); i += 4) {
            try {
                String rawId   = raw.get(i);
                ResourceLocation id = rawId.contains(":")
                    ? new ResourceLocation(rawId.split(":", 2)[0], rawId.split(":", 2)[1])
                    : new ResourceLocation("minecraft", rawId);
                int weight   = Integer.parseInt(raw.get(i + 1));
                int minCount = Integer.parseInt(raw.get(i + 2));
                int maxCount = Integer.parseInt(raw.get(i + 3));
                if (weight > 0) pool.add(new LootEntry(id, weight, minCount, maxCount));
            } catch (Exception ex) {
                PathologyMod.LOGGER.warn(
                    "CorpseLootConfig: bad pool entry at index {}: {}", i, ex.getMessage());
            }
        }
        return pool;
    }
}
