package com.pathology.mod.corpse;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.saveddata.SavedData;

/**
 * Persists corpse records across server restarts using Forge's SavedData mechanism.
 * Attached to the overworld (or whichever level is passed in); each dimension
 * keeps its own file under world/data/pathologymod_corpses.dat.
 */
public class CorpseSavedData extends SavedData {

    private static final String KEY = "pathologymod_corpses";

    public static CorpseSavedData getOrCreate(ServerLevel level) {
        return level.getDataStorage().computeIfAbsent(
            tag -> load(tag, level),
            () -> new CorpseSavedData(),
            KEY
        );
    }

    private static CorpseSavedData load(CompoundTag tag, ServerLevel level) {
        CorpseSavedData data = new CorpseSavedData();
        CorpseManager.get().loadAll(tag);
        return data;
    }

    @Override
    public CompoundTag save(CompoundTag tag) {
        CompoundTag corpseData = CorpseManager.get().saveAll();
        // Merge corpseData into tag
        corpseData.getAllKeys().forEach(key -> tag.put(key, corpseData.get(key)));
        return tag;
    }

    /** Call this whenever the corpse list changes so the data gets written on next save. */
    public static void markDirty(ServerLevel level) {
        getOrCreate(level).setDirty();
    }
}
