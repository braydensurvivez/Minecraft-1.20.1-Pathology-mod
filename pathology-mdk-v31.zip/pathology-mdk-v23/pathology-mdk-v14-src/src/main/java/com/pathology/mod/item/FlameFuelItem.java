package com.pathology.mod.item;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

import javax.annotation.Nullable;
import java.util.List;

/**
 * Flame Fuel — single-use canister that refills a Flamethrower.
 *
 * Usage:
 *   - Hold Flame Fuel in main hand and right-click while the Flamethrower is in
 *     the off-hand: refuels the flamethrower and consumes one Flame Fuel.
 *   - Hold Flamethrower in main hand and right-click while Flame Fuel is in
 *     off-hand: same effect (handled here via off-hand check).
 *
 * Each canister adds FUEL_PER_CANISTER fuel to the flamethrower (default 100).
 */
public class FlameFuelItem extends Item {

    /** Amount of fuel added per canister. */
    public static final int FUEL_PER_CANISTER = 100;

    public FlameFuelItem(Properties props) {
        super(props);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        if (level.isClientSide) return InteractionResultHolder.pass(player.getItemInHand(hand));

        ItemStack fuelStack = player.getItemInHand(hand);
        // Look for a flamethrower in the opposite hand
        InteractionHand otherHand = (hand == InteractionHand.MAIN_HAND)
                ? InteractionHand.OFF_HAND : InteractionHand.MAIN_HAND;
        ItemStack otherStack = player.getItemInHand(otherHand);

        if (otherStack.getItem() instanceof FlameThrowerItem) {
            int current = FlameThrowerItem.getFuel(otherStack);
            if (current >= FlameThrowerItem.MAX_FUEL) {
                player.displayClientMessage(
                    Component.literal("Flamethrower is already full.")
                        .withStyle(ChatFormatting.YELLOW), true);
                return InteractionResultHolder.fail(fuelStack);
            }
            FlameThrowerItem.addFuel(otherStack, FUEL_PER_CANISTER);
            if (!player.isCreative()) fuelStack.shrink(1);
            int newFuel = FlameThrowerItem.getFuel(otherStack);
            player.displayClientMessage(
                Component.literal("Flamethrower refuelled! Fuel: " + newFuel + " / " + FlameThrowerItem.MAX_FUEL)
                    .withStyle(ChatFormatting.GOLD), true);
            return InteractionResultHolder.consume(fuelStack);
        }

        player.displayClientMessage(
            Component.literal("Hold a Flamethrower in the other hand to refuel it.")
                .withStyle(ChatFormatting.GRAY), true);
        return InteractionResultHolder.pass(fuelStack);
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level,
                                List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.literal("Adds " + FUEL_PER_CANISTER + " fuel to a Flamethrower.")
            .withStyle(ChatFormatting.GRAY));
        tooltip.add(Component.literal("Hold in one hand, Flamethrower in the other, then right-click.")
            .withStyle(ChatFormatting.DARK_GRAY));
    }
}
