package com.pathology.mod.corpse;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * Compact, serializable snapshot of everything needed to display a corpse.
 *
 * New in v12:
 *  - lootItems: pre-rolled list of ItemStack stored in the corpse's inventory.
 *    Populated by CorpseLootConfig when the corpse is first created.
 */
public class CorpseData {

    public UUID  originalEntity;
    public String entityTypeId;
    public CompoundTag inventory;       // raw entity NBT snapshot
    public float yaw;
    public float pitch;
    public Vec3  deathPos;
    public long  deathTime;
    public int   decayStage;
    public int   bodyCount;
    public boolean wasDecayDiseaseCorpse;

    /** Pre-rolled loot items for the corpse's interactive inventory. */
    public List<ItemStack> lootItems = new ArrayList<>();

    public CorpseData() {}

    public CorpseData(UUID originalEntity, String entityTypeId, CompoundTag inventory,
                      float yaw, float pitch, Vec3 deathPos, long deathTime,
                      boolean wasDecayDiseaseCorpse) {
        this.originalEntity        = originalEntity;
        this.entityTypeId          = entityTypeId;
        this.inventory             = inventory != null ? inventory : new CompoundTag();
        this.yaw                   = yaw;
        this.pitch                 = pitch;
        this.deathPos              = deathPos;
        this.deathTime             = deathTime;
        this.decayStage            = 0;
        this.bodyCount             = 1;
        this.wasDecayDiseaseCorpse = wasDecayDiseaseCorpse;
    }

    // ── NBT serialisation ─────────────────────────────────────────────────────

    public CompoundTag save() {
        CompoundTag tag = new CompoundTag();
        tag.putUUID("uuid",          originalEntity);
        tag.putString("entityType",  entityTypeId);
        tag.put("inventory",         inventory);
        tag.putFloat("yaw",          yaw);
        tag.putFloat("pitch",        pitch);
        tag.putDouble("x",           deathPos.x);
        tag.putDouble("y",           deathPos.y);
        tag.putDouble("z",           deathPos.z);
        tag.putLong("deathTime",     deathTime);
        tag.putInt("decayStage",     decayStage);
        tag.putInt("bodyCount",      bodyCount);
        tag.putBoolean("decayDisease", wasDecayDiseaseCorpse);

        // Save loot items
        ListTag loot = new ListTag();
        for (int i = 0; i < lootItems.size(); i++) {
            ItemStack stack = lootItems.get(i);
            if (!stack.isEmpty()) {
                CompoundTag slotTag = stack.save(new CompoundTag());
                slotTag.putByte("Slot", (byte) i);
                loot.add(slotTag);
            }
        }
        tag.put("lootItems", loot);
        return tag;
    }

    public static CorpseData load(CompoundTag tag) {
        CorpseData d = new CorpseData();
        d.originalEntity        = tag.getUUID("uuid");
        d.entityTypeId          = tag.getString("entityType");
        d.inventory             = tag.getCompound("inventory");
        d.yaw                   = tag.getFloat("yaw");
        d.pitch                 = tag.getFloat("pitch");
        d.deathPos              = new Vec3(tag.getDouble("x"), tag.getDouble("y"), tag.getDouble("z"));
        d.deathTime             = tag.getLong("deathTime");
        d.decayStage            = tag.getInt("decayStage");
        d.bodyCount             = Math.max(1, tag.getInt("bodyCount"));
        d.wasDecayDiseaseCorpse = tag.getBoolean("decayDisease");

        // Load loot items
        if (tag.contains("lootItems")) {
            ListTag loot = tag.getList("lootItems", 10);
            d.lootItems = new ArrayList<>();
            for (int i = 0; i < loot.size(); i++) {
                d.lootItems.add(ItemStack.of(loot.getCompound(i)));
            }
        }
        return d;
    }
}
