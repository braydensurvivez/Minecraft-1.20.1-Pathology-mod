package com.pathology.mod.virus;

import com.pathology.mod.PathologyMod;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.nbt.Tag;
import net.minecraft.world.entity.LivingEntity;

import java.util.*;

/**
 * Tracks per-entity virus immunity.
 *
 * An entity that is immune to a virus cannot be infected by it — all infection
 * attempts are silently blocked regardless of vector (airborne, bloodborne,
 * bleeding, vomit, command).  Creative / Spectator immunity is separate and
 * handled in VirusManager.
 *
 * Immunity is earned in two ways:
 *   1. Via command: /pathology immune <targets> <virusId>
 *   2. Naturally: a very small random chance (0.5 %) fires when a player
 *      recovers from a virus (infection advances past its last stage).
 *
 * Immunity is stored in PersistentData NBT so it survives reloads and respawns.
 */
public class ImmunityManager {

    private static final String NBT_KEY = "pathologymod_immunity";
    /** Key to remove (revoke) immunity via command. */
    public static final String REMOVE_KEY = "pathologymod_immunity";

    // UUID → set of virus IDs the entity is immune to
    private static final Map<UUID, Set<String>> IMMUNITIES = new HashMap<>();

    private ImmunityManager() {}

    // ── Public API ────────────────────────────────────────────────────────────

    /** Returns true if {@code entity} is immune to the virus with the given ID. */
    public static boolean isImmune(LivingEntity entity, String virusId) {
        Set<String> set = IMMUNITIES.get(entity.getUUID());
        return set != null && set.contains(virusId);
    }

    /** Returns an unmodifiable view of all virus IDs the entity is immune to. */
    public static Set<String> getImmunities(LivingEntity entity) {
        Set<String> set = IMMUNITIES.get(entity.getUUID());
        return set == null ? Collections.emptySet() : Collections.unmodifiableSet(set);
    }

    /**
     * Grants immunity to {@code virusId} for {@code entity}.
     * Also cures the entity of that virus if currently infected.
     */
    public static void grantImmunity(LivingEntity entity, String virusId) {
        IMMUNITIES.computeIfAbsent(entity.getUUID(), k -> new HashSet<>()).add(virusId);
        // Auto-cure if currently infected
        if (VirusManager.isInfected(entity, virusId)) {
            VirusManager.cure(entity, virusId);
        }
        saveToNBT(entity);
        PathologyMod.LOGGER.debug("Entity {} gained immunity to {}", entity.getUUID(), virusId);
    }

    /** Revokes immunity to {@code virusId} for {@code entity}. */
    public static void revokeImmunity(LivingEntity entity, String virusId) {
        Set<String> set = IMMUNITIES.get(entity.getUUID());
        if (set != null) {
            set.remove(virusId);
            if (set.isEmpty()) IMMUNITIES.remove(entity.getUUID());
        }
        saveToNBT(entity);
        PathologyMod.LOGGER.debug("Entity {} lost immunity to {}", entity.getUUID(), virusId);
    }

    /** Revokes ALL immunities for {@code entity}. */
    public static void revokeAll(LivingEntity entity) {
        IMMUNITIES.remove(entity.getUUID());
        entity.getPersistentData().remove(NBT_KEY);
        PathologyMod.LOGGER.debug("Entity {} lost all immunities", entity.getUUID());
    }

    // ── NBT persistence ───────────────────────────────────────────────────────

    public static void saveToNBT(LivingEntity entity) {
        Set<String> set = IMMUNITIES.get(entity.getUUID());
        CompoundTag persistent = entity.getPersistentData();
        if (set == null || set.isEmpty()) {
            persistent.remove(NBT_KEY);
            return;
        }
        ListTag list = new ListTag();
        for (String id : set) list.add(StringTag.valueOf(id));
        persistent.put(NBT_KEY, list);
    }

    public static void loadFromNBT(LivingEntity entity) {
        CompoundTag persistent = entity.getPersistentData();
        if (!persistent.contains(NBT_KEY, Tag.TAG_LIST)) return;
        ListTag list = persistent.getList(NBT_KEY, Tag.TAG_STRING);
        if (list.isEmpty()) return;
        Set<String> set = IMMUNITIES.computeIfAbsent(entity.getUUID(), k -> new HashSet<>());
        for (int i = 0; i < list.size(); i++) {
            set.add(list.getString(i));
        }
        PathologyMod.LOGGER.debug("Loaded {} immunity record(s) for entity {}", set.size(), entity.getUUID());
    }

    /** Clears in-memory state (called on server stop / world unload). */
    public static void clearAll() {
        IMMUNITIES.clear();
    }
}
