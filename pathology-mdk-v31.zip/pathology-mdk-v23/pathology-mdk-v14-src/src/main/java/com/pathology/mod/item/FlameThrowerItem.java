package com.pathology.mod.item;

import com.pathology.mod.corpse.CorpseManager;
import com.pathology.mod.corpse.CorpseSavedData;
import com.pathology.mod.entity.CorpseEntity;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseFireBlock;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import javax.annotation.Nullable;
import java.util.List;
import java.util.UUID;

/**
 * Flamethrower — creative / op tool that shoots fire in a cone in front of the player.
 *
 *  - Right-click (hold): consumes fuel and shoots fire particles, ignites blocks,
 *    damages living entities, and destroys corpses in a short cone.
 *  - Fire is launched as a stream of flame particles — it is shot, not placed.
 *  - Living entities in the cone take fire damage and are set on fire.
 *  - Corpses hit by the flamethrower are immediately set on fire via CorpseManager.destroyByFire.
 *  - Fuel is stored in NBT ("FlameFuel", integer 0–200).  Max 200 uses per tank.
 *  - Refuel by right-clicking the flamethrower in off-hand while holding FlameFuelItem,
 *    OR by right-clicking with the flamethrower while holding a FlameFuelItem in the
 *    other hand (handled in FlameFuelItem.use).
 *  - The item has a cooldown of 4 ticks between spray pulses so it doesn't consume
 *    fuel every single tick.
 */
public class FlameThrowerItem extends Item {

    public static final String NBT_FUEL     = "FlameFuel";
    public static final int    MAX_FUEL     = 200;
    /** Range of the flame cone in blocks. */
    public static final double FLAME_RANGE  = 6.0;
    /** Half-angle of the spray cone. */
    public static final double CONE_RADIUS  = 1.5;
    /** Ticks between uses (prevents draining a full tank in one tick). */
    public static final int    USE_COOLDOWN = 4;
    /** Fire damage dealt per hit to living entities. */
    public static final float  FIRE_DAMAGE  = 4.0f;
    /** Ticks of fire applied to living entities hit. */
    public static final int    FIRE_TICKS   = 60;

    public FlameThrowerItem(Properties props) {
        super(props);
    }

    // ── Fuel helpers ──────────────────────────────────────────────────────────────────────────────────

    public static int getFuel(ItemStack stack) {
        CompoundTag tag = stack.getTag();
        return (tag != null && tag.contains(NBT_FUEL)) ? tag.getInt(NBT_FUEL) : 0;
    }

    public static void setFuel(ItemStack stack, int fuel) {
        stack.getOrCreateTag().putInt(NBT_FUEL, Math.max(0, Math.min(MAX_FUEL, fuel)));
    }

    public static void addFuel(ItemStack stack, int amount) {
        setFuel(stack, getFuel(stack) + amount);
    }

    // ── Use ─────────────────────────────────────────────────────────────────────────────────────────────────────────────────

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);

        if (level.isClientSide) {
            return InteractionResultHolder.success(stack);
        }

        int fuel = getFuel(stack);
        if (fuel <= 0) {
            player.displayClientMessage(
                Component.literal("Flamethrower is empty! Use Flame Fuel to refill.")
                    .withStyle(ChatFormatting.RED), true);
            return InteractionResultHolder.fail(stack);
        }

        // Apply a small use cooldown so holding right-click doesn't drain instantly
        player.getCooldowns().addCooldown(this, USE_COOLDOWN);

        // Consume 1 fuel per spray pulse
        setFuel(stack, fuel - 1);

        // Fire spray on server
        if (level instanceof ServerLevel sl) {
            shootFire(sl, player);
        }

        return InteractionResultHolder.consume(stack);
    }

    // ── Shoot logic ─────────────────────────────────────────────────────────────────────────────────────

    /**
     * Shoots fire: emits flame + smoke particles along the cone and deals fire
     * damage to any LivingEntity (mob, player) in the path.  Also ignites ground
     * blocks and destroys CorpseEntities.
     */
    private static void shootFire(ServerLevel level, Player player) {
        Vec3 eye  = player.getEyePosition();
        Vec3 look = player.getLookAngle();

        // ─ Shoot flame particles along the look vector ───────────────────────────────────
        // Spawn dense flame + lava particle streams that travel away from the player.
        int steps = (int)(FLAME_RANGE * 3);
        for (int i = 1; i <= steps; i++) {
            double t = i / 3.0;
            Vec3 tip = eye.add(look.scale(t));

            // Spread the particles across a small cone
            for (double ox = -0.3; ox <= 0.3; ox += 0.3) {
                for (double oz = -0.3; oz <= 0.3; oz += 0.3) {
                    Vec3 pt = tip.add(
                        look.z * ox - look.x * oz,   // perpendicular spread
                        0,
                        look.x * ox + look.z * oz
                    );
                    // Flame particles — shot outward with a small velocity
                    level.sendParticles(ParticleTypes.FLAME,
                        pt.x, pt.y, pt.z,
                        1,
                        look.x * 0.15, look.y * 0.15, look.z * 0.15,
                        0.05);
                    // Smoke trail
                    if (i % 3 == 0) {
                        level.sendParticles(ParticleTypes.LARGE_SMOKE,
                            pt.x, pt.y + 0.1, pt.z,
                            1,
                            look.x * 0.05, 0.02, look.z * 0.05,
                            0.0);
                    }
                    // Lava splash for extra visual intensity at close range
                    if (i <= 6) {
                        level.sendParticles(ParticleTypes.LAVA,
                            pt.x, pt.y, pt.z,
                            1, 0, 0, 0, 0.0);
                    }
                }
            }

            // ─ Ignite blocks on the ground that the flame stream passes through ──────
            BlockPos bp = BlockPos.containing(tip.x, tip.y, tip.z);
            if (level.getBlockState(bp).isAir()) {
                BlockPos below = bp.below();
                if (level.getBlockState(below).isSolidRender(level, below)) {
                    level.setBlock(bp, BaseFireBlock.getState(level, bp), 11);
                }
            }
        }

        // ─ Damage living entities in the cone ──────────────────────────────────────────
        AABB searchBox = new AABB(
            eye.x - FLAME_RANGE, eye.y - 2, eye.z - FLAME_RANGE,
            eye.x + FLAME_RANGE, eye.y + 2, eye.z + FLAME_RANGE);

        DamageSource fireSrc = level.damageSources().inFire();

        for (LivingEntity living : level.getEntitiesOfClass(LivingEntity.class, searchBox)) {
            if (living == player) continue; // don't self-harm
            Vec3 toTarget = living.position().subtract(eye);
            if (toTarget.length() > FLAME_RANGE) continue;
            double dot = toTarget.normalize().dot(look);
            if (dot < 0.5) continue; // ~60° cone

            // Set on fire and apply fire damage
            living.setSecondsOnFire(FIRE_TICKS / 20);
            living.hurt(fireSrc, FIRE_DAMAGE);
        }

        // ─ Ignite CorpseEntities in the cone ──────────────────────────────────────────
        for (CorpseEntity ce : level.getEntitiesOfClass(CorpseEntity.class, searchBox)) {
            Vec3 toCorpse = ce.position().subtract(eye);
            if (toCorpse.length() > FLAME_RANGE) continue;
            double dot = toCorpse.normalize().dot(look);
            if (dot < 0.5) continue;

            UUID cid = ce.getCorpseUUID();
            boolean alreadyBurning = CorpseManager.get().isBurning(cid) || ce.isBurning();
            if (!alreadyBurning) {
                if (CorpseManager.get().get(cid).isPresent()) {
                    CorpseManager.get().destroyByFire(cid, level);
                }
                ce.setBurning(true);
                ce.discard();
                CorpseSavedData.markDirty(level);
            }
        }
    }

    // ── Tooltip ───────────────────────────────────────────────────────────────────────────────────────

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level,
                                List<Component> tooltip, TooltipFlag flag) {
        int fuel = getFuel(stack);
        tooltip.add(Component.literal("Fuel: " + fuel + " / " + MAX_FUEL)
            .withStyle(fuel > 0 ? ChatFormatting.GOLD : ChatFormatting.RED));
        tooltip.add(Component.literal("Right-click to shoot fire.")
            .withStyle(ChatFormatting.GRAY));
        tooltip.add(Component.literal("Use Flame Fuel to refill.")
            .withStyle(ChatFormatting.GRAY));
    }

    @Override
    public boolean isFoil(ItemStack stack) {
        // Glow when fuelled so it stands out in inventory
        return getFuel(stack) > 0;
    }
}
