package com.pathology.mod.item;

import com.pathology.mod.virus.Virus;
import com.pathology.mod.virus.VirusManager;
import com.pathology.mod.virus.VirusRegistry;
import net.minecraft.ChatFormatting;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;

import javax.annotation.Nullable;
import java.util.Collection;
import java.util.List;
import java.util.Optional;

/**
 * Pathogen Syringe — creative debug item.
 *
 *   ATTACK (left-click) a LivingEntity  → infect it with the loaded virus
 *   USE (right-click)   a LivingEntity  → display its infection status in chat
 *
 * The loaded virus is stored in NBT key "VirusId". Defaults to "influenza".
 * Use /pathology syringe <virusId> to change the loaded virus.
 */
public class PathogenSyringeItem extends Item {

    public static final String NBT_VIRUS_ID = "VirusId";
    public static final String DEFAULT_VIRUS = "influenza";

    public PathogenSyringeItem(Properties properties) {
        super(properties);
    }

    // -------------------------------------------------------------------------
    // NBT helpers
    // -------------------------------------------------------------------------

    public static String getLoadedVirus(ItemStack stack) {
        CompoundTag tag = stack.getTag();
        if (tag != null && tag.contains(NBT_VIRUS_ID)) {
            return tag.getString(NBT_VIRUS_ID);
        }
        return DEFAULT_VIRUS;
    }

    public static void setLoadedVirus(ItemStack stack, String virusId) {
        stack.getOrCreateTag().putString(NBT_VIRUS_ID, virusId);
    }

    // -------------------------------------------------------------------------
    // Left-click entity → infect
    // -------------------------------------------------------------------------

    @Override
    public boolean hurtEnemy(ItemStack stack, LivingEntity target, LivingEntity attacker) {
        if (attacker.level().isClientSide()) return true;

        String virusId = getLoadedVirus(stack);
        Optional<Virus> virusOpt = VirusRegistry.get(virusId);

        if (virusOpt.isEmpty()) {
            if (attacker instanceof Player player) {
                player.sendSystemMessage(Component.literal(
                    "[Pathology] Unknown virus loaded: " + virusId)
                    .withStyle(ChatFormatting.RED));
            }
            return true;
        }

        Virus virus = virusOpt.get();
        if (VirusManager.isInfected(target, virusId)) {
            if (attacker instanceof Player player) {
                player.sendSystemMessage(Component.literal(
                    "[Pathology] " + getEntityName(target) + " is already infected with " + virusId + ".")
                    .withStyle(ChatFormatting.YELLOW));
            }
        } else {
            VirusManager.infect(target, virus);
            if (attacker instanceof Player player) {
                player.sendSystemMessage(Component.literal(
                    "[Pathology] Infected " + getEntityName(target) + " with " + virusId + "!")
                    .withStyle(ChatFormatting.GREEN));
            }
        }
        return true;
    }

    // -------------------------------------------------------------------------
    // Right-click entity → status report
    // -------------------------------------------------------------------------

    @Override
    public InteractionResult interactLivingEntity(ItemStack stack, Player player,
                                                   LivingEntity target, InteractionHand hand) {
        if (player.level().isClientSide()) return InteractionResult.SUCCESS;

        Collection<VirusManager.InfectionRecord> infections = VirusManager.getInfections(target);

        if (infections.isEmpty()) {
            player.sendSystemMessage(Component.literal(
                "[Pathology] " + getEntityName(target) + " is not infected.")
                .withStyle(ChatFormatting.AQUA));
        } else {
            player.sendSystemMessage(Component.literal(
                "[Pathology] " + getEntityName(target) + " infection report:")
                .withStyle(ChatFormatting.GOLD));

            for (VirusManager.InfectionRecord r : infections) {
                int stageIdx = Math.min(r.currentStage, r.virus.getStages().size() - 1);
                int stageDuration = r.virus.getStages().get(stageIdx).getDurationTicks();
                int secondsLeft = Math.max(0, (stageDuration - r.ticksInStage) / 20);
                int totalStages = r.virus.getStages().size();

                player.sendSystemMessage(Component.literal(
                    "  ▶ " + r.virus.getId()
                    + " | Stage " + (r.currentStage + 1) + "/" + totalStages
                    + " | " + secondsLeft + "s until next stage")
                    .withStyle(ChatFormatting.WHITE));
            }
        }

        return InteractionResult.SUCCESS;
    }

    // -------------------------------------------------------------------------
    // Tooltip
    // -------------------------------------------------------------------------

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level,
                                 List<Component> tooltip, TooltipFlag flag) {
        String virusId = getLoadedVirus(stack);
        tooltip.add(Component.literal("Loaded: " + virusId).withStyle(ChatFormatting.YELLOW));
        tooltip.add(Component.literal("Left-click mob → Infect").withStyle(ChatFormatting.GRAY));
        tooltip.add(Component.literal("Right-click mob → Status").withStyle(ChatFormatting.GRAY));
        tooltip.add(Component.literal("Use /pathology syringe <virus> to reload").withStyle(ChatFormatting.DARK_GRAY));
    }

    // -------------------------------------------------------------------------
    // Helpers
    // -------------------------------------------------------------------------

    private static String getEntityName(LivingEntity entity) {
        return entity.getName().getString();
    }
}
