package com.pathology.mod.infection;

import com.pathology.mod.util.ModSounds;
import com.pathology.mod.util.ProtectionUtil;
import com.pathology.mod.virus.Virus;
import com.pathology.mod.virus.VirusManager;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.registries.ForgeRegistries;
import org.joml.Vector3f;

import java.util.*;

/**
 * Vomit vector — dark crimson particles.
 * Uses DustParticleOptions for a proper dark red colour (no orange tint).
 *
 * Warning message is sent 5 seconds (100 ticks) BEFORE the vomit event fires.
 * Vomit pool infection: 100% chance for unarmored entities (reduced by armor protection).
 * Vomit stream: entities caught in the active particle stream also roll for infection (100% - armor).
 */
public class VomitHandler {

    private static final List<VomitPool> ACTIVE_POOLS = new ArrayList<>();
    private static final Map<UUID, VomitSession> ACTIVE_SESSIONS = new HashMap<>();

    /** UUID → remaining ticks until the pending warning fires (counts down each tick). */
    private static final Map<UUID, PendingWarning> PENDING_WARNINGS = new HashMap<>();

    private static final Random RNG = new Random();
    private static final double VOMIT_RADIUS = 1.0;

    private static final int SESSION_MIN_TICKS = 60;
    private static final int SESSION_MAX_TICKS = 100;

    private static final double IDLE_FIRE_CHANCE_MULTIPLIER = 0.1;
    private static final double AGGRO_CHECK_RADIUS = 8.0;

    // Dark crimson dust — R=0.40 G=0.0 B=0.05, size 1.2
    private static final DustParticleOptions DARK_RED_DUST =
        new DustParticleOptions(new Vector3f(0.40f, 0.0f, 0.05f), 1.2f);

    // Slightly smaller for drip/puddle variation
    private static final DustParticleOptions DARK_RED_DUST_SM =
        new DustParticleOptions(new Vector3f(0.35f, 0.0f, 0.04f), 0.8f);

    // ── PendingWarning ────────────────────────────────────────────────────────

    private static class PendingWarning {
        // Stored as ServerPlayer — only the infected player ever receives the warning message.
        final ServerPlayer player;
        final Virus virus;
        int countdown; // ticks remaining until warning is sent

        PendingWarning(ServerPlayer player, Virus virus, int countdown) {
            this.player = player;
            this.virus = virus;
            this.countdown = countdown;
        }
    }

    /**
     * Called 100 ticks (5 seconds) before the vomit interval fires.
     * Queues a warning that will be displayed ONLY to the infected player.
     * Non-player entities are silently ignored — mobs never receive this message.
     */
    public static void scheduleWarning(LivingEntity source, Virus virus) {
        // Only players receive the "burning sensation" warning — not mobs or other entities
        if (!(source instanceof ServerPlayer sp)) return;
        // Only queue if not already vomiting and no warning pending
        if (ACTIVE_SESSIONS.containsKey(sp.getUUID())) return;
        if (PENDING_WARNINGS.containsKey(sp.getUUID())) return;
        PENDING_WARNINGS.put(sp.getUUID(), new PendingWarning(sp, virus, 100));
    }

    /**
     * Ticks all pending warnings. When countdown reaches 0 the message is sent
     * directly to the infected player only — no broadcast to nearby entities.
     * Call this every server tick from ModEvents.
     */
    public static void tickWarnings() {
        Iterator<Map.Entry<UUID, PendingWarning>> it = PENDING_WARNINGS.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<UUID, PendingWarning> entry = it.next();
            PendingWarning pw = entry.getValue();
            pw.countdown--;
            if (pw.countdown <= 0) {
                // Send message exclusively to the infected player — not to any other entity
                if (pw.player.isAlive()) {
                    pw.player.sendSystemMessage(Component.literal("\u00a7cYou feel a burning sensation in your throat..."));
                }
                it.remove();
            }
        }
    }

    // ── VomitSession ──────────────────────────────────────────────────────────

    public static class VomitSession {
        public final LivingEntity source;
        public final Virus virus;
        public int remainingTicks;
        public int poolSpawnCooldown;

        VomitSession(LivingEntity source, Virus virus) {
            this.source = source;
            this.virus = virus;
            this.remainingTicks = SESSION_MIN_TICKS + RNG.nextInt(SESSION_MAX_TICKS - SESSION_MIN_TICKS + 1);
            this.poolSpawnCooldown = 0;
        }

        boolean tick(ServerLevel level) {
            remainingTicks--;

            source.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 30, 1, false, false));
            source.addEffect(new MobEffectInstance(MobEffects.CONFUSION, 60, 0, false, false));

            if (source instanceof ServerPlayer sp) {
                sp.setForcedPose(net.minecraft.world.entity.Pose.CROUCHING);
            }

            Vec3 eye = source.getEyePosition();
            Vec3 look = source.getLookAngle();

            boolean sendParticles = !(source instanceof ServerPlayer);

            if (sendParticles) {
                // Main stream: dark crimson dust arc
                for (int step = 1; step <= 10; step++) {
                    double t = step / 10.0;
                    double arcY = Math.sin(t * Math.PI) * 0.4 - t * 0.5;
                    double spread = 0.04;
                    Vec3 pt = eye.add(
                        look.x * t * 2.5 + (RNG.nextDouble() - 0.5) * spread,
                        arcY + (RNG.nextDouble() - 0.5) * spread,
                        look.z * t * 2.5 + (RNG.nextDouble() - 0.5) * spread
                    );
                    level.sendParticles(DARK_RED_DUST,
                        pt.x, pt.y, pt.z,
                        1, 0.02, 0.02, 0.02, 0.0);
                }

                // Secondary drip: smaller dark red dust along the stream
                if (remainingTicks % 3 == 0) {
                    for (int step = 2; step <= 8; step++) {
                        double t = step / 10.0;
                        double arcY = Math.sin(t * Math.PI) * 0.4 - t * 0.5;
                        Vec3 pt = eye.add(look.x * t * 2.5, arcY - 0.1, look.z * t * 2.5);
                        level.sendParticles(DARK_RED_DUST_SM,
                            pt.x, pt.y, pt.z,
                            1, 0.05, 0.0, 0.05, 0.0);
                    }
                }

                // Splash at landing zone every 4 ticks
                if (remainingTicks % 4 == 0) {
                    Vec3 land = eye.add(look.x * 2.5, -1.2, look.z * 2.5);
                    for (int i = 0; i < 4; i++) {
                        double ox = (RNG.nextDouble() - 0.5) * VOMIT_RADIUS * 1.5;
                        double oz = (RNG.nextDouble() - 0.5) * VOMIT_RADIUS * 1.5;
                        level.sendParticles(DARK_RED_DUST,
                            land.x + ox, land.y + 0.05, land.z + oz,
                            1, 0.0, 0.1, 0.0, 0.2);
                    }
                }

                // ── Stream contact infection check (every 5 ticks) ────────────
                // Any entity inside the vomit arc bounding box is considered "touched
                // by the particles". 100% infection chance for unarmored; reduced by armor.
                if (remainingTicks % 5 == 0) {
                    Vec3 land = eye.add(look.x * 2.5, -1.2, look.z * 2.5);
                    AABB streamBox = new AABB(
                        Math.min(eye.x, land.x) - 0.6, Math.min(eye.y, land.y) - 0.3, Math.min(eye.z, land.z) - 0.6,
                        Math.max(eye.x, land.x) + 0.6, Math.max(eye.y, land.y) + 0.6, Math.max(eye.z, land.z) + 0.6
                    );
                    for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, streamBox,
                            en -> en != source && !VirusManager.isInfected(en, virus.getId()))) {
                        double protection = ProtectionUtil.getProtectionReduction(e);
                        // 100% infection for unarmored; scaled down by armor
                        double chance = 1.0 - protection;
                        if (RNG.nextDouble() < chance) {
                            VirusManager.infect(e, virus);
                        }
                    }
                }
            }

            // Pool spawning regardless
            poolSpawnCooldown--;
            if (poolSpawnCooldown <= 0) {
                Vec3 land = eye.add(look.x * 2.5, -1.2, look.z * 2.5);
                ACTIVE_POOLS.add(new VomitPool(land, virus));
                poolSpawnCooldown = 20;
            }

            boolean active = remainingTicks > 0;

            if (!active && source instanceof ServerPlayer sp) {
                sp.setForcedPose(null);
            }

            return active;
        }
    }

    // ── VomitPool ─────────────────────────────────────────────────────────────

    public static class VomitPool {
        public final Vec3 pos;
        public final Virus virus;
        public final double radius;
        public int remainingTicks;

        VomitPool(Vec3 pos, Virus virus) {
            this.pos = pos;
            this.virus = virus;
            this.radius = VOMIT_RADIUS;
            this.remainingTicks = 20 * 6;
        }

        boolean tick(ServerLevel level) {
            remainingTicks--;

            // Dark crimson puddle particles
            if (remainingTicks % 5 == 0) {
                for (int i = 0; i < 4; i++) {
                    double ox = (RNG.nextDouble() - 0.5) * radius * 2;
                    double oz = (RNG.nextDouble() - 0.5) * radius * 2;
                    level.sendParticles(DARK_RED_DUST,
                        pos.x + ox, pos.y + 0.05, pos.z + oz,
                        1, 0, 0.02, 0, 0.0);
                }
                level.sendParticles(DARK_RED_DUST_SM,
                    pos.x + (RNG.nextDouble() - 0.5) * radius,
                    pos.y + 0.1,
                    pos.z + (RNG.nextDouble() - 0.5) * radius,
                    1, 0.02, 0.05, 0.02, 0.0);
            }

            // Infection check every 5 ticks — 100% chance for unarmored entities
            if (remainingTicks % 5 == 0) {
                AABB box = new AABB(pos.x - radius, pos.y - 0.5, pos.z - radius,
                                    pos.x + radius, pos.y + 2.0, pos.z + radius);
                for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, box,
                        en -> !VirusManager.isInfected(en, virus.getId()))) {
                    double dist = Math.sqrt(Math.pow(e.getX() - pos.x, 2) + Math.pow(e.getZ() - pos.z, 2));
                    if (dist > radius) continue;
                    double protection = ProtectionUtil.getProtectionReduction(e);
                    // 100% infection when no armor worn; armor reduces the chance
                    double chance = 1.0 - protection;
                    if (RNG.nextDouble() < chance)
                        VirusManager.infect(e, virus);
                }
            }
            return remainingTicks > 0;
        }
    }

    // ── Called from ModEvents when vomit interval fires ───────────────────────

    // Players have a boosted fire chance (2.5x for bloodborne, 1.5x for others) so they vomit more often than mobs
    private static final double PLAYER_FIRE_CHANCE_BOOST = 1.5;
    private static final double PLAYER_BLOODBORNE_FIRE_CHANCE_BOOST = 2.5;
    // Zombies (non-aggroed) only vomit very occasionally
    private static final double ZOMBIE_IDLE_FIRE_CHANCE_MULTIPLIER = 0.05;

    public static void onVomitFire(LivingEntity source, Virus virus) {
        if (!(source.level() instanceof ServerLevel sl)) return;
        if (ACTIVE_SESSIONS.containsKey(source.getUUID())) return;

        // Remove any pending warning for this entity since it's now firing
        PENDING_WARNINGS.remove(source.getUUID());

        double fireChance = virus.getVomitFireChance();
        boolean aggroed = isAggroedOnNearbyPlayer(source);
        boolean isPlayer = source instanceof ServerPlayer;
        boolean isZombie = isZombieEntity(source);

        if (isPlayer) {
            // Players vomit more readily — extra boost for bloodborne infection
            boolean isBloodborne = virus.getId().equals("bloodbornehuskvirus");
            double boost = isBloodborne ? PLAYER_BLOODBORNE_FIRE_CHANCE_BOOST : PLAYER_FIRE_CHANCE_BOOST;
            fireChance = Math.min(1.0, fireChance * boost);
        } else if (isZombie) {
            // Zombies only vomit occasionally — very low chance when idle, slightly higher when aggroed
            if (!aggroed) {
                fireChance *= ZOMBIE_IDLE_FIRE_CHANCE_MULTIPLIER;
            } else {
                fireChance *= IDLE_FIRE_CHANCE_MULTIPLIER; // still low even when aggroed
            }
        } else {
            // Other mobs: normal idle reduction
            if (!aggroed) {
                fireChance *= IDLE_FIRE_CHANCE_MULTIPLIER;
            }
        }

        if (RNG.nextDouble() > fireChance) return;

        // NOTE: warning message is sent 5 seconds BEFORE this fires via scheduleWarning().
        // No warning message here.

        VomitSession session = new VomitSession(source, virus);
        ACTIVE_SESSIONS.put(source.getUUID(), session);

        // Play vomit sound only for the infected player (not broadcast to all nearby entities)
        if (source instanceof ServerPlayer sp) {
            sp.playNotifySound(ModSounds.VOMIT.get(), SoundSource.PLAYERS,
                    1.0f, 0.9f + RNG.nextFloat() * 0.2f);
        } else {
            sl.playSound(null, source.getX(), source.getY(), source.getZ(),
                    ModSounds.VOMIT.get(), SoundSource.HOSTILE,
                    1.0f, 0.9f + RNG.nextFloat() * 0.2f);
        }
    }

    private static boolean isAggroedOnNearbyPlayer(LivingEntity entity) {
        if (entity instanceof Mob mob) {
            LivingEntity target = mob.getTarget();
            if (target instanceof Player) {
                return mob.distanceTo(target) <= AGGRO_CHECK_RADIUS;
            }
        }
        return false;
    }

    /** Returns true if the entity is a zombie-type mob. */
    private static boolean isZombieEntity(LivingEntity entity) {
        net.minecraft.resources.ResourceLocation typeKey =
            net.minecraftforge.registries.ForgeRegistries.ENTITY_TYPES.getKey(entity.getType());
        if (typeKey == null) return false;
        String id = typeKey.toString();
        return id.equals("minecraft:zombie")
            || id.equals("minecraft:zombie_villager")
            || id.equals("minecraft:husk")
            || id.equals("minecraft:drowned")
            || id.equals("minecraft:zombified_piglin")
            || id.equals("hordes:zombie_player")
            || id.equals("mca:male_zombie_villager")
            || id.equals("mca:female_zombie_villager");
    }

    // ── Tick sessions and pools ────────────────────────────────────────────────

    public static void tickAllPools(ServerLevel level) {
        Iterator<Map.Entry<UUID, VomitSession>> it = ACTIVE_SESSIONS.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<UUID, VomitSession> entry = it.next();
            VomitSession session = entry.getValue();
            if (session.source.level() == level && session.source.isAlive()) {
                if (!session.tick(level)) {
                    it.remove();
                }
            } else if (!session.source.isAlive()) {
                it.remove();
            }
        }
        ACTIVE_POOLS.removeIf(p -> !p.tick(level));
    }

    public static boolean isVomiting(LivingEntity entity) {
        return ACTIVE_SESSIONS.containsKey(entity.getUUID());
    }

    public static void clearAll() {
        for (VomitSession session : ACTIVE_SESSIONS.values()) {
            if (session.source instanceof ServerPlayer sp) {
                sp.setForcedPose(null);
            }
        }
        ACTIVE_SESSIONS.clear();
        ACTIVE_POOLS.clear();
        PENDING_WARNINGS.clear();
    }

    public static int activePoolCount() { return ACTIVE_POOLS.size(); }
    public static int activeSessionCount() { return ACTIVE_SESSIONS.size(); }

    /** Returns true if the entity is in Creative or Spectator (immune to all infection). */
    private static boolean isImmuneGameMode(net.minecraft.world.entity.LivingEntity e) {
        if (e instanceof net.minecraft.server.level.ServerPlayer sp) {
            net.minecraft.world.level.GameType gm = sp.gameMode.getGameModeForPlayer();
            return gm == net.minecraft.world.level.GameType.CREATIVE
                || gm == net.minecraft.world.level.GameType.SPECTATOR;
        }
        return false;
    }

}
