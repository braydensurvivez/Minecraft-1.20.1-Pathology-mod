package com.pathology.mod.config;

import net.minecraftforge.common.ForgeConfigSpec;
import java.util.*;

public class VirusConfig {

    public static final ForgeConfigSpec SPEC;

    // ── Influenza ─────────────────────────────────────────────────────────────
    public static final ForgeConfigSpec.BooleanValue INFLUENZA_AIRBORNE;
    public static final ForgeConfigSpec.BooleanValue INFLUENZA_BLOODBORNE;
    public static final ForgeConfigSpec.BooleanValue INFLUENZA_BLEEDING;
    public static final ForgeConfigSpec.BooleanValue INFLUENZA_VOMIT;

    public static final ForgeConfigSpec.DoubleValue INFLUENZA_AIRBORNE_RADIUS;
    public static final ForgeConfigSpec.DoubleValue INFLUENZA_AIRBORNE_CHANCE;

    public static final ForgeConfigSpec.DoubleValue INFLUENZA_BLOODBORNE_RADIUS;
    public static final ForgeConfigSpec.DoubleValue INFLUENZA_BLOODBORNE_CHANCE;
    public static final ForgeConfigSpec.IntValue    INFLUENZA_BLOODBORNE_CLOUD_DURATION;

    public static final ForgeConfigSpec.IntValue    INFLUENZA_BLEEDING_INTERVAL;
    public static final ForgeConfigSpec.DoubleValue INFLUENZA_BLEEDING_ZONE_RADIUS;
    public static final ForgeConfigSpec.IntValue    INFLUENZA_BLEEDING_ZONE_DURATION;
    public static final ForgeConfigSpec.DoubleValue INFLUENZA_BLEEDING_INFECT_CHANCE;

    public static final ForgeConfigSpec.IntValue    INFLUENZA_VOMIT_INTERVAL;
    public static final ForgeConfigSpec.DoubleValue INFLUENZA_VOMIT_FIRE_CHANCE;
    public static final ForgeConfigSpec.DoubleValue INFLUENZA_VOMIT_INFECT_CHANCE;
    public static final ForgeConfigSpec.DoubleValue INFLUENZA_VOMIT_SPLASH_RADIUS;

    public static final ForgeConfigSpec.IntValue INFLUENZA_STAGE1_DURATION;
    public static final ForgeConfigSpec.IntValue INFLUENZA_STAGE2_DURATION;
    public static final ForgeConfigSpec.IntValue INFLUENZA_STAGE3_DURATION;

    // ── Airborne Husk Flu ─────────────────────────────────────────────────────
    public static final ForgeConfigSpec.DoubleValue AIRBORNE_HUSKFLU_AIRBORNE_RADIUS;
    public static final ForgeConfigSpec.DoubleValue AIRBORNE_HUSKFLU_AIRBORNE_CHANCE;
    public static final ForgeConfigSpec.IntValue    AIRBORNE_HUSKFLU_S1_DURATION;
    public static final ForgeConfigSpec.IntValue    AIRBORNE_HUSKFLU_S2_DURATION;
    public static final ForgeConfigSpec.IntValue    AIRBORNE_HUSKFLU_S3_DURATION;

    // ── Bloodborne Husk Virus ────────────────────────────────────────────────
    public static final ForgeConfigSpec.DoubleValue BLOODBORNE_HUSKVIRUS_BLOODBORNE_RADIUS;
    public static final ForgeConfigSpec.DoubleValue BLOODBORNE_HUSKVIRUS_BLOODBORNE_CHANCE;
    public static final ForgeConfigSpec.IntValue    BLOODBORNE_HUSKVIRUS_BLOODBORNE_CLOUD_DURATION;
    public static final ForgeConfigSpec.IntValue    BLOODBORNE_HUSKVIRUS_S1_DURATION;
    public static final ForgeConfigSpec.IntValue    BLOODBORNE_HUSKVIRUS_S2_DURATION;

    // ── Husk Flu (Legacy) ─────────────────────────────────────────────────────
    public static final ForgeConfigSpec.DoubleValue HUSK_FLU_AIRBORNE_RADIUS;
    public static final ForgeConfigSpec.DoubleValue HUSK_FLU_AIRBORNE_CHANCE;
    public static final ForgeConfigSpec.IntValue    HUSK_FLU_BLEEDING_INTERVAL;
    public static final ForgeConfigSpec.DoubleValue HUSK_FLU_BLEEDING_ZONE_RADIUS;
    public static final ForgeConfigSpec.IntValue    HUSK_FLU_BLEEDING_ZONE_DURATION;
    public static final ForgeConfigSpec.DoubleValue HUSK_FLU_BLEEDING_INFECT_CHANCE;
    public static final ForgeConfigSpec.IntValue    HUSK_FLU_VOMIT_INTERVAL;
    public static final ForgeConfigSpec.DoubleValue HUSK_FLU_VOMIT_FIRE_CHANCE;
    public static final ForgeConfigSpec.DoubleValue HUSK_FLU_VOMIT_INFECT_CHANCE;
    public static final ForgeConfigSpec.DoubleValue HUSK_FLU_VOMIT_SPLASH_RADIUS;
    public static final ForgeConfigSpec.IntValue    HUSK_FLU_S1_DURATION;
    public static final ForgeConfigSpec.IntValue    HUSK_FLU_S2_DURATION;
    public static final ForgeConfigSpec.IntValue    HUSK_FLU_S3_DURATION;
    public static final ForgeConfigSpec.IntValue    HUSK_FLU_S4_DURATION;

    // ── Natural spawn infections ──────────────────────────────────────────────
    // Flat list: ["minecraft:zombie","husk_flu","minecraft:zombie_villager","husk_flu", ...]
    public static final ForgeConfigSpec.ConfigValue<List<? extends String>> NATURAL_SPAWN_INFECTIONS;

    // ── Cure items ────────────────────────────────────────────────────────────
    // Flat list: ["minecraft:golden_apple","influenza","minecraft:honey_bottle","husk_flu", ...]
    public static final ForgeConfigSpec.ConfigValue<List<? extends String>> CURE_ITEMS;

    static {
        ForgeConfigSpec.Builder b = new ForgeConfigSpec.Builder();

        b.comment("=== Influenza ===").push("influenza");
        INFLUENZA_AIRBORNE   = b.comment("Enable airborne spread").define("airborne", true);
        INFLUENZA_BLOODBORNE = b.comment("Enable bloodborne (death cloud) spread").define("bloodborne", false);
        INFLUENZA_BLEEDING   = b.comment("Enable bleeding vector").define("bleeding", false);
        INFLUENZA_VOMIT      = b.comment("Enable vomit vector").define("vomit", false);

        INFLUENZA_AIRBORNE_RADIUS = b.defineInRange("airborneRadius", 5.0, 1.0, 64.0);
        INFLUENZA_AIRBORNE_CHANCE = b.defineInRange("airborneChance", 0.08, 0.0, 1.0);

        INFLUENZA_BLOODBORNE_RADIUS        = b.defineInRange("bloodborneRadius", 3.0, 1.0, 32.0);
        INFLUENZA_BLOODBORNE_CHANCE        = b.defineInRange("bloodborneChance", 0.45, 0.0, 1.0);
        INFLUENZA_BLOODBORNE_CLOUD_DURATION= b.defineInRange("bloodborneCloudDuration", 3, 1, 30);

        INFLUENZA_BLEEDING_INTERVAL     = b.comment("Seconds between bleed pulses").defineInRange("bleedingInterval", 15, 1, 300);
        INFLUENZA_BLEEDING_ZONE_RADIUS  = b.defineInRange("bleedingZoneRadius", 1.5, 0.5, 16.0);
        INFLUENZA_BLEEDING_ZONE_DURATION= b.comment("Seconds blood zone lingers").defineInRange("bleedingZoneDuration", 8, 1, 120);
        INFLUENZA_BLEEDING_INFECT_CHANCE= b.comment("Chance per tick of contact").defineInRange("bleedingInfectChance", 0.035, 0.0, 1.0);

        INFLUENZA_VOMIT_INTERVAL     = b.comment("Seconds between vomit attempts").defineInRange("vomitInterval", 20, 1, 300);
        INFLUENZA_VOMIT_FIRE_CHANCE  = b.comment("Chance vomit actually fires on interval").defineInRange("vomitFireChance", 0.5, 0.0, 1.0);
        INFLUENZA_VOMIT_INFECT_CHANCE= b.comment("Infection chance on direct vomit contact").defineInRange("vomitInfectChance", 1.0, 0.0, 1.0);
        INFLUENZA_VOMIT_SPLASH_RADIUS= b.defineInRange("vomitSplashRadius", 2.0, 0.5, 16.0);

        INFLUENZA_STAGE1_DURATION = b.defineInRange("stage1Duration", 300, 1, 86400);
        INFLUENZA_STAGE2_DURATION = b.defineInRange("stage2Duration", 300, 1, 86400);
        INFLUENZA_STAGE3_DURATION = b.defineInRange("stage3Duration", 300, 1, 86400);
        b.pop();

        b.comment("=== Husk Flu === (airborne + bleeding + vomit; infects all undead on spawn)").push("husk_flu");
        HUSK_FLU_AIRBORNE_RADIUS = b.defineInRange("airborneRadius", 7.0, 1.0, 64.0);
        HUSK_FLU_AIRBORNE_CHANCE = b.defineInRange("airborneChance", 0.12, 0.0, 1.0);
        HUSK_FLU_BLEEDING_INTERVAL     = b.defineInRange("bleedingInterval", 10, 1, 300);
        HUSK_FLU_BLEEDING_ZONE_RADIUS  = b.defineInRange("bleedingZoneRadius", 1.5, 0.5, 16.0);
        HUSK_FLU_BLEEDING_ZONE_DURATION= b.defineInRange("bleedingZoneDuration", 6, 1, 120);
        HUSK_FLU_BLEEDING_INFECT_CHANCE= b.defineInRange("bleedingInfectChance", 0.045, 0.0, 1.0);
        HUSK_FLU_VOMIT_INTERVAL      = b.defineInRange("vomitInterval", 15, 1, 300);
        HUSK_FLU_VOMIT_FIRE_CHANCE   = b.defineInRange("vomitFireChance", 0.6, 0.0, 1.0);
        HUSK_FLU_VOMIT_INFECT_CHANCE = b.defineInRange("vomitInfectChance", 1.0, 0.0, 1.0);
        HUSK_FLU_VOMIT_SPLASH_RADIUS = b.defineInRange("vomitSplashRadius", 2.0, 0.5, 16.0);
        HUSK_FLU_S1_DURATION = b.comment("Stage 1 – silent (seconds)").defineInRange("stage1Duration", 60, 1, 86400);
        HUSK_FLU_S2_DURATION = b.comment("Stage 2 – Slowness (seconds)").defineInRange("stage2Duration", 120, 1, 86400);
        HUSK_FLU_S3_DURATION = b.comment("Stage 3 – Nausea (seconds)").defineInRange("stage3Duration", 180, 1, 86400);
        HUSK_FLU_S4_DURATION = b.comment("Stage 4 – Hordes:infected tag (seconds)").defineInRange("stage4Duration", 240, 1, 86400);
        b.pop();

        b.comment("=== Airborne Husk Flu === (airborne only; infects zombies on spawn; 15 seconds total)").push("airbornehuskflu");
        AIRBORNE_HUSKFLU_AIRBORNE_RADIUS = b.defineInRange("airborneRadius", 6.0, 1.0, 64.0);
        AIRBORNE_HUSKFLU_AIRBORNE_CHANCE = b.defineInRange("airborneChance", 0.15, 0.0, 1.0);
        AIRBORNE_HUSKFLU_S1_DURATION = b.comment("Stage 1 – no symptoms (seconds)").defineInRange("stage1Duration", 60, 1, 86400);
        AIRBORNE_HUSKFLU_S2_DURATION = b.comment("Stage 2 – Nausea + rasp cough (seconds)").defineInRange("stage2Duration", 60, 1, 86400);
        AIRBORNE_HUSKFLU_S3_DURATION = b.comment("Stage 3 – Stronger Nausea + hordes:infected effect (seconds, loops)").defineInRange("stage3Duration", 60, 1, 86400);
        b.pop();

        b.comment("=== Bloodborne Husk Virus === (bloodborne only; infects undead on spawn; 5 seconds total; splash cloud on damage)").push("bloodbornehuskvirus");
        BLOODBORNE_HUSKVIRUS_BLOODBORNE_RADIUS = b.defineInRange("bloodborneRadius", 2.0, 1.0, 32.0);
        BLOODBORNE_HUSKVIRUS_BLOODBORNE_CHANCE = b.defineInRange("bloodborneChance", 0.6, 0.0, 1.0);
        BLOODBORNE_HUSKVIRUS_BLOODBORNE_CLOUD_DURATION = b.defineInRange("bloodborneCloudDuration", 2, 1, 30);
        BLOODBORNE_HUSKVIRUS_S1_DURATION = b.comment("Stage 1 – incubation before vomiting starts (seconds)").defineInRange("stage1Duration", 10, 1, 86400);
        BLOODBORNE_HUSKVIRUS_S2_DURATION = b.comment("Stage 2 – active vomiting loops (seconds)").defineInRange("stage2Duration", 30, 1, 86400);
        b.pop();

        b.comment(
            "=== Natural Spawn Infections ===",
            "Flat alternating list: entity resource location, then virus id.",
            "Example: [\"minecraft:zombie\",\"airbornehuskflu\",\"minecraft:husk\",\"bloodbornehuskvirus\"]"
        ).push("naturalSpawns");
        NATURAL_SPAWN_INFECTIONS = b.defineList("entries", List.of(
            "minecraft:zombie",          "airbornehuskflu",
            "minecraft:husk",            "bloodbornehuskvirus",
            "minecraft:zombie_villager", "airbornehuskflu",
            "minecraft:drowned",         "bloodbornehuskvirus",
            "minecraft:zombified_piglin","airbornehuskflu"
        ), e -> e instanceof String);
        b.pop();

        b.comment(
            "=== Cure Items ===",
            "Flat alternating list: item resource location, then virus id it cures.",
            "Use 'any' as the virus id to cure all infections.",
            "Example: [\"minecraft:golden_apple\",\"any\",\"minecraft:honey_bottle\",\"airbornehuskflu\"]"
        ).push("cureItems");
        CURE_ITEMS = b.defineList("entries", List.of(
            "minecraft:golden_apple", "any",
            "minecraft:honey_bottle", "airbornehuskflu",
            "minecraft:glow_berries", "bloodbornehuskvirus"
        ), e -> e instanceof String);
        b.pop();

        SPEC = b.build();
    }

    /** Returns map of entityId -> virusId for natural spawn infections. */
    public static Map<String, String> getNaturalSpawnMap() {
        Map<String, String> map = new LinkedHashMap<>();
        List<? extends String> entries = NATURAL_SPAWN_INFECTIONS.get();
        for (int i = 0; i+1 < entries.size(); i += 2) map.put(entries.get(i), entries.get(i+1));
        return map;
    }

    /** Returns map of itemId -> virusId it cures ("any" = all). */
    public static Map<String, String> getCureItemMap() {
        Map<String, String> map = new LinkedHashMap<>();
        List<? extends String> entries = CURE_ITEMS.get();
        for (int i = 0; i+1 < entries.size(); i += 2) map.put(entries.get(i), entries.get(i+1));
        return map;
    }
}
