package com.pathology.mod.item;

import com.pathology.mod.PathologyMod;
import com.pathology.mod.corpse.CorpseData;
import com.pathology.mod.corpse.CorpseManager;
import com.pathology.mod.corpse.CorpseSavedData;
import com.pathology.mod.entity.CorpseEntity;
import net.minecraft.ChatFormatting;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;

import javax.annotation.Nullable;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

/**
 * Body Bag — pick up and relocate corpses.
 *
 * v14 changes:
 *  - use() (RightClickItem / clicking air) now only handles PLACE (bag full).
 *    Pickup is handled by ModEvents.onPlayerRightClickEntity so clicking
 *    directly on the CorpseEntity works correctly.
 *  - use() falls back to proximity pickup when clicking air with an empty bag,
 *    so the item still works if somehow no entity is targeted.
 */
public class BodyBagItem extends Item {

    public static final String TAG_CORPSE_UUID = "storedCorpseUUID";

    public BodyBagItem(Properties props) {
        super(props);
    }

    // ── Interaction ───────────────────────────────────────────────────────────

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (level.isClientSide()) return InteractionResultHolder.pass(stack);
        ServerLevel sl = (ServerLevel) level;

        // ── Bag is FULL → place the stored corpse ────────────────────────────
        if (hasStoredCorpse(stack)) {
            UUID storedId = getStoredCorpseUUID(stack);
            Optional<CorpseData> dataOpt = CorpseManager.get().get(storedId);

            if (dataOpt.isEmpty()) {
                stack.removeTagKey(TAG_CORPSE_UUID);
                player.displayClientMessage(
                    Component.literal("The body has decomposed.")
                        .withStyle(ChatFormatting.DARK_RED), true);
                return InteractionResultHolder.fail(stack);
            }

            CorpseData data = dataOpt.get();
            data.deathPos = player.position();

            CorpseEntity newEntity = CorpseEntity.fromData(sl, data, storedId);
            populateEntityInventory(newEntity, data);
            sl.addFreshEntity(newEntity);

            stack.removeTagKey(TAG_CORPSE_UUID);
            CorpseSavedData.markDirty(sl);

            player.displayClientMessage(
                Component.literal("Corpse placed.")
                    .withStyle(ChatFormatting.YELLOW), true);
            PathologyMod.LOGGER.debug("Body bag placed corpse {} at {}", storedId, data.deathPos);
            return InteractionResultHolder.success(stack);
        }

        // ── Bag is EMPTY → fallback proximity pickup (clicking air) ──────────
        // Primary pickup path is via ModEvents.onPlayerRightClickEntity (clicking
        // the entity directly).  This fallback handles edge cases.
        Optional<CorpseEntity> target = findNearestCorpse(player, sl, 3.0);
        if (target.isEmpty()) {
            player.displayClientMessage(
                Component.literal("No corpse nearby. Right-click directly on a corpse to pick it up.")
                    .withStyle(ChatFormatting.GRAY), true);
            return InteractionResultHolder.fail(stack);
        }

        CorpseEntity ce = target.get();
        UUID corpseId = ce.getCorpseUUID();

        Optional<CorpseData> dataOpt = CorpseManager.get().get(corpseId);
        if (dataOpt.isEmpty()) {
            corpseId = CorpseManager.get().getUUIDAt(ce.position()).orElse(null);
            if (corpseId == null) {
                player.displayClientMessage(
                    Component.literal("Corpse data missing.")
                        .withStyle(ChatFormatting.RED), true);
                return InteractionResultHolder.fail(stack);
            }
        }

        CompoundTag tag = stack.getOrCreateTag();
        tag.putUUID(TAG_CORPSE_UUID, corpseId);
        ce.discard();
        CorpseSavedData.markDirty(sl);

        player.displayClientMessage(
            Component.literal("Corpse stored in body bag.")
                .withStyle(ChatFormatting.GREEN), true);
        PathologyMod.LOGGER.debug("Body bag (proximity) picked up corpse {}", corpseId);
        return InteractionResultHolder.success(stack);
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private static Optional<CorpseEntity> findNearestCorpse(Player player, ServerLevel level, double radius) {
        AABB box = player.getBoundingBox().inflate(radius);
        return level.getEntitiesOfClass(CorpseEntity.class, box).stream()
            .min((a, b) -> Double.compare(
                a.distanceToSqr(player.position()),
                b.distanceToSqr(player.position())));
    }

    public static boolean hasStoredCorpse(ItemStack stack) {
        return stack.hasTag() && stack.getTag().hasUUID(TAG_CORPSE_UUID);
    }

    public static UUID getStoredCorpseUUID(ItemStack stack) {
        return stack.getTag().getUUID(TAG_CORPSE_UUID);
    }

    private static void populateEntityInventory(CorpseEntity entity, CorpseData data) {
        var inv = entity.getInventory();
        inv.clearContent();
        for (int i = 0; i < data.lootItems.size() && i < inv.getContainerSize(); i++) {
            inv.setItem(i, data.lootItems.get(i).copy());
        }
    }

    // ── Tooltip ───────────────────────────────────────────────────────────────

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level,
                                List<Component> lines, TooltipFlag flag) {
        if (hasStoredCorpse(stack)) {
            UUID id = getStoredCorpseUUID(stack);
            Optional<CorpseData> data = CorpseManager.get().get(id);
            if (data.isPresent()) {
                lines.add(Component.literal("Contains: " + data.get().entityTypeId)
                    .withStyle(ChatFormatting.DARK_GREEN));
                String[] stages = {"Fresh", "Rotting", "Skeletal"};
                int s = Math.min(data.get().decayStage, 2);
                lines.add(Component.literal("Decay: " + stages[s])
                    .withStyle(ChatFormatting.GRAY));
            } else {
                lines.add(Component.literal("Contents: decomposed")
                    .withStyle(ChatFormatting.DARK_RED));
            }
        } else {
            lines.add(Component.literal("Empty – right-click a corpse to pick it up.")
                .withStyle(ChatFormatting.GRAY));
        }
    }
}
