package com.pathology.mod.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import com.pathology.mod.entity.CorpseEntity;
import net.minecraft.client.model.ZombieModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.monster.Zombie;

/**
 * Renders a CorpseEntity as a fallen zombie lying flat on its BACK facing the sky.
 *
 * Change from v11: The corpse now lies face-up (supine) instead of on its side.
 * Achieved by rotating -90° around ZP (tips the model backward onto its back)
 * then adjusting the Y translation so the body rests on the ground surface.
 *
 * If the corpse is on fire, a subtle orange tint is blended into the render.
 */
public class CorpseRenderer extends EntityRenderer<CorpseEntity> {

    // ── Texture constants ─────────────────────────────────────────────────────
    private static final ResourceLocation ZOMBIE_TEXTURE =
            ResourceLocation.fromNamespaceAndPath("minecraft", "textures/entity/zombie/zombie.png");
    private static final ResourceLocation HUSK_TEXTURE =
            ResourceLocation.fromNamespaceAndPath("minecraft", "textures/entity/zombie/husk.png");

    @SuppressWarnings("rawtypes")
    private final ZombieModel model;

    @SuppressWarnings("rawtypes")
    public CorpseRenderer(EntityRendererProvider.Context ctx) {
        super(ctx);
        this.model = new ZombieModel(ctx.bakeLayer(ModelLayers.ZOMBIE));
    }

    // ── Main render ───────────────────────────────────────────────────────────

    @Override
    public void render(CorpseEntity entity, float entityYaw, float partialTick,
                       PoseStack poseStack, MultiBufferSource bufferSource, int packedLight) {

        poseStack.pushPose();

        // Raise the origin so the back of the body rests on the ground.
        // A zombie is ~1.95 units tall; lying on its back the centre is ~0.975 up,
        // but the model's pivot is at the feet, so a nudge of ~0.24 sets it flush.
        poseStack.translate(0.0, 0.24, 0.0);

        // Face the direction the zombie was heading at death
        poseStack.mulPose(Axis.YP.rotationDegrees(-entity.getYRot()));

        // Tip the zombie flat onto its BACK (face pointing up at the sky).
        // Rotating -90° around ZP leans the model backward into a supine pose.
        poseStack.mulPose(Axis.ZP.rotationDegrees(-90.0f));

        float scale = 0.9375f;
        if (entity.getBodyCount() > 1) {
            poseStack.translate(0.0, 0.04 * (entity.getBodyCount() - 1), 0.0);
        }
        poseStack.scale(scale, scale, scale);

        // ── Alpha by decay stage ──────────────────────────────────────────────
        int stage = entity.getDecayStage();
        float alpha = switch (stage) {
            case 1  -> 180 / 255f;
            case 2  -> 100 / 255f;
            default -> 1.0f;
        };

        // ── Fire / char tint ──────────────────────────────────────────────────
        // When burning, we animate the colour in two phases:
        //   Phase 1 (progress 0.0 → 0.5): normal colour → deep orange/red flame glow
        //   Phase 2 (progress 0.5 → 1.0): orange/red → charred black (r,g,b all → 0)
        // When not burning, render at normal colour.
        float r = 1.0f, g = 1.0f, b = 1.0f;
        if (entity.isBurning()) {
            float progress = entity.getBurnProgress(); // 0.0 → 1.0
            if (progress < 0.5f) {
                // Phase 1: lerp from white (1,1,1) to orange (1, 0.3, 0)
                float t = progress / 0.5f; // 0→1
                r = 1.0f;
                g = 1.0f - (0.7f * t);   // 1.0 → 0.3
                b = 1.0f - (1.0f * t);   // 1.0 → 0.0
            } else {
                // Phase 2: lerp from orange (1, 0.3, 0) to charred black (0.05, 0.05, 0.05)
                float t = (progress - 0.5f) / 0.5f; // 0→1
                r = 1.0f   - (0.95f * t); // 1.0   → 0.05
                g = 0.3f   - (0.25f * t); // 0.3   → 0.05
                b = 0.0f   + (0.05f * t); // 0.0   → 0.05
            }
        }

        // ── Freeze the model ──────────────────────────────────────────────────
        resetModelPose();

        // ── Texture by type + decay stage ────────────────────────────────────
        ResourceLocation texture = getTextureForStage(entity);

        // ── Render ────────────────────────────────────────────────────────────
        VertexConsumer consumer = bufferSource.getBuffer(RenderType.entityTranslucent(texture));

        //noinspection unchecked
        model.renderToBuffer(poseStack, consumer, packedLight,
                OverlayTexture.NO_OVERLAY, r, g, b, alpha);

        poseStack.popPose();
    }

    @SuppressWarnings("unchecked")
    private void resetModelPose() {
        model.head.xRot = 0f; model.head.yRot = 0f; model.head.zRot = 0f;
        model.body.xRot = 0f; model.body.yRot = 0f; model.body.zRot = 0f;
        model.rightArm.xRot = 0f; model.rightArm.yRot = 0f; model.rightArm.zRot = 0f;
        model.leftArm.xRot  = 0f; model.leftArm.yRot  = 0f; model.leftArm.zRot  = 0f;
        model.rightLeg.xRot = 0f; model.rightLeg.yRot = 0f; model.rightLeg.zRot = 0f;
        model.leftLeg.xRot  = 0f; model.leftLeg.yRot  = 0f; model.leftLeg.zRot  = 0f;
        model.crouching = false;
        model.young     = false;
    }

    private static ResourceLocation getTextureForStage(CorpseEntity entity) {
        if (entity.getDecayStage() == 2) return HUSK_TEXTURE;
        return pickBaseTexture(entity.getEntityTypeId());
    }

    private static ResourceLocation pickBaseTexture(String typeId) {
        return switch (typeId) {
            case "minecraft:husk"             -> ResourceLocation.fromNamespaceAndPath("minecraft", "textures/entity/zombie/husk.png");
            case "minecraft:drowned"          -> ResourceLocation.fromNamespaceAndPath("minecraft", "textures/entity/zombie/drowned.png");
            case "minecraft:zombie_villager"  -> ResourceLocation.fromNamespaceAndPath("minecraft", "textures/entity/zombie/zombie_villager.png");
            case "minecraft:zombified_piglin" -> ResourceLocation.fromNamespaceAndPath("minecraft", "textures/entity/piglin/zombified_piglin.png");
            default                           -> ZOMBIE_TEXTURE;
        };
    }

    @Override
    public ResourceLocation getTextureLocation(CorpseEntity entity) {
        return pickBaseTexture(entity.getEntityTypeId());
    }
}
