package com.pathology.mod.item;

import com.pathology.mod.virus.VirusManager;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

import java.util.Set;

/**
 * Digital Thermometer – right-click any LivingEntity to get a temperature reading.
 *
 * Returns HIGH FEVER for: influenza, airbornehuskflu, bloodbornehuskvirus.
 * Returns NORMAL otherwise.
 */
public class DigitalThermometerItem extends Item {

    private static final Set<String> FEVER_VIRUSES = Set.of(
        "influenza", "airbornehuskflu", "bloodbornehuskvirus"
    );

    public DigitalThermometerItem(Properties props) {
        super(props);
    }

    @Override
    public InteractionResult interactLivingEntity(ItemStack stack, Player player, LivingEntity target, InteractionHand hand) {
        if (player.level().isClientSide()) return InteractionResult.SUCCESS;

        boolean hasFever = VirusManager.getInfections(target).stream()
            .anyMatch(rec -> FEVER_VIRUSES.contains(rec.virus.getId()));

        String targetName = target instanceof Player p
            ? p.getName().getString()
            : target.getType().getDescription().getString();

        if (hasFever) {
            player.displayClientMessage(
                Component.literal("[THERMOMETER] " + targetName + ": ")
                    .withStyle(ChatFormatting.YELLOW)
                    .append(Component.literal("HIGH FEVER DETECTED (39.5 C+)")
                        .withStyle(ChatFormatting.RED, ChatFormatting.BOLD)),
                false);
        } else {
            player.displayClientMessage(
                Component.literal("[THERMOMETER] " + targetName + ": ")
                    .withStyle(ChatFormatting.YELLOW)
                    .append(Component.literal("NORMAL (36.6 C)")
                        .withStyle(ChatFormatting.GREEN)),
                false);
        }

        player.level().playSound(null, player.blockPosition(),
            net.minecraft.sounds.SoundEvents.UI_BUTTON_CLICK.get(),
            net.minecraft.sounds.SoundSource.PLAYERS, 0.5f, 1.5f);

        return InteractionResult.SUCCESS;
    }
}
