package com.pathology.mod.infection;

import com.pathology.mod.util.ProtectionUtil;
import com.pathology.mod.virus.Virus;
import com.pathology.mod.virus.VirusManager;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.AABB;

import java.util.List;
import java.util.Random;

public class AirborneHandler {

    private static final Random RNG = new Random();

    public static void spreadFrom(LivingEntity source, Virus virus) {
        if (!virus.isAirborne()) return;
        double radius = virus.getAirborneRadius();
        double chance = virus.getAirborneChance();
        AABB box = source.getBoundingBox().inflate(radius);
        List<LivingEntity> nearby = source.level().getEntitiesOfClass(LivingEntity.class, box,
            e -> e != source && !VirusManager.isInfected(e, virus.getId()));
        for (LivingEntity target : nearby) {
            // Non-biological entities (e.g. ArmorStands) cannot be infected.
            if (com.pathology.mod.virus.VirusManager.isNonBiologicalEntity(target)) continue;
            // Creative and Spectator players are immune to airborne infection.
            if (target instanceof net.minecraft.server.level.ServerPlayer sp) {
                net.minecraft.world.level.GameType gm = sp.gameMode.getGameModeForPlayer();
                if (gm == net.minecraft.world.level.GameType.CREATIVE
                        || gm == net.minecraft.world.level.GameType.SPECTATOR) continue;
            }
            double dist = source.distanceTo(target);
            if (dist > radius) continue;
            double distFactor = 1.0 - (dist / radius);
            double protection = ProtectionUtil.getProtectionReduction(target);
            double effective = chance * distFactor * (1.0 - protection);
            if (RNG.nextDouble() < effective)
                VirusManager.infect(target, virus);
        }
    }
}
