package com.pathology.mod.events;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.DoubleArgumentType;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.pathology.mod.item.ModItems;
import com.pathology.mod.item.PathogenSyringeItem;
import com.pathology.mod.virus.*;
import com.pathology.mod.util.ProtectionUtil;
import net.minecraft.ChatFormatting;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import com.pathology.mod.corpse.CorpseData;
import com.pathology.mod.corpse.CorpseManager;
import com.pathology.mod.corpse.CorpseSavedData;
import com.pathology.mod.entity.CorpseEntity;
import com.pathology.mod.entity.ModEntityTypes;
import net.minecraft.world.phys.Vec3;
import net.minecraft.server.level.ServerLevel;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.registries.ForgeRegistries;

import java.util.*;

/**
 * All /pathology and /pathogen commands.
 *
 * /pathology infect <targets> <virusId>
 * /pathology cure <targets> <virusId>
 * /pathology cureall <targets>
 * /pathology status [target]
 * /pathology setstage <targets> <virusId> <stage>
 * /pathology virus list
 * /pathology virus <id> info
 * /pathology virus <id> airborne_radius|airborne_chance|bloodborne_radius|bloodborne_chance|
 *                        bleeding_interval|bleeding_zone_radius|bleeding_infect_chance|
 *                        vomit_interval|vomit_fire_chance|vomit_infect_chance|vomit_splash_radius <value>
 * /pathology virus <id> stage <stageNum> duration <seconds>
 * /pathology virus <id> stage <stageNum> addeffect <effectId> <amplifier>
 * /pathology virus <id> stage <stageNum> cleareffects
 * /pathology virus <id> addvector <vector>
 * /pathology virus <id> removevector <vector>
 * /pathology virus <id> addstage <durationSeconds>
 * /pathology virus <id> removestage <stageNum>
 * /pathology immune <targets> <virusId>
 * /pathology removeimmune <targets> <virusId>
 * /pathology immunestatus [target]
 * /pathology syringe <virusId>
 *
 * /pathogen create <name> <vectors> <stageCount> <finalStageEffect> [amplifier]
 *   vectors = comma-separated: airborne,bloodborne,bleeding,vomit
 *   example: /pathogen create plague airborne,bleeding 3 minecraft:poison 1
 * /pathogen delete <name>
 * /pathogen list
 */
public class CommandEvents {

    /** Players who have /pathology infection test active — they glow when in corpse radius. */
    public static final java.util.Set<java.util.UUID> INFECTION_TEST_PLAYERS =
        java.util.Collections.synchronizedSet(new java.util.HashSet<>());

    @SubscribeEvent
    public void onRegisterCommands(RegisterCommandsEvent event) {
        CommandDispatcher<CommandSourceStack> d = event.getDispatcher();
        registerPathologyCommands(d);
        registerPathogenCommands(d);
    }

    // ═════════════════════════════════════════════════════════════════════════
    // /pathology
    // ═════════════════════════════════════════════════════════════════════════

    private void registerPathologyCommands(CommandDispatcher<CommandSourceStack> d) {
        d.register(Commands.literal("pathology")
            .requires(src -> src.hasPermission(2))

            // infect
            .then(Commands.literal("infect")
                .then(Commands.argument("targets", EntityArgument.entities())
                    .then(Commands.argument("virusId", StringArgumentType.word())
                        .executes(ctx -> {
                            String vid = StringArgumentType.getString(ctx, "virusId");
                            Optional<Virus> vOpt = VirusRegistry.get(vid);
                            if (vOpt.isEmpty()) return err(ctx.getSource(), "Unknown virus: " + vid + knownViruses());
                            Virus v = vOpt.get(); int n = 0;
                            for (Entity e : EntityArgument.getEntities(ctx, "targets"))
                                if (e instanceof LivingEntity le) { VirusManager.infect(le, v); n++; }
                            int fn=n; ctx.getSource().sendSuccess(()->ok("Infected "+fn+" entities with "+vid),false);
                            return n;
                        }))))

            // cure
            .then(Commands.literal("cure")
                .then(Commands.argument("targets", EntityArgument.entities())
                    .then(Commands.argument("virusId", StringArgumentType.word())
                        .executes(ctx -> {
                            String vid = StringArgumentType.getString(ctx, "virusId"); int n=0;
                            for (Entity e : EntityArgument.getEntities(ctx, "targets"))
                                if (e instanceof LivingEntity le && VirusManager.isInfected(le,vid)) { VirusManager.cure(le,vid); n++; }
                            int fn=n; ctx.getSource().sendSuccess(()->ok("Cured "+fn+" entities of "+vid),false);
                            return n;
                        }))))

            // cureall
            .then(Commands.literal("cureall")
                .then(Commands.argument("targets", EntityArgument.entities())
                    .executes(ctx -> {
                        int n=0;
                        for (Entity e : EntityArgument.getEntities(ctx,"targets"))
                            if (e instanceof LivingEntity le && VirusManager.isInfectedByAny(le)) {
                                for (VirusManager.InfectionRecord r : VirusManager.getInfections(le)) VirusManager.cure(le,r.virus.getId());
                                n++;
                            }
                        int fn=n; ctx.getSource().sendSuccess(()->ok("Cleared all infections from "+fn+" entities"),false);
                        return n;
                    })))

            // status
            .then(Commands.literal("status")
                .executes(ctx->{ printStatus(ctx.getSource(), ctx.getSource().getPlayerOrException()); return 1; })
                .then(Commands.argument("target", EntityArgument.entity())
                    .executes(ctx->{
                        Entity e = EntityArgument.getEntity(ctx,"target");
                        if (e instanceof LivingEntity le) printStatus(ctx.getSource(),le);
                        else return err(ctx.getSource(),"Not a living entity");
                        return 1;
                    })))

            // setstage
            .then(Commands.literal("setstage")
                .then(Commands.argument("targets", EntityArgument.entities())
                    .then(Commands.argument("virusId", StringArgumentType.word())
                        .then(Commands.argument("stage", IntegerArgumentType.integer(1))
                            .executes(ctx->{
                                String vid=StringArgumentType.getString(ctx,"virusId");
                                int stage=IntegerArgumentType.getInteger(ctx,"stage")-1; int n=0;
                                for (Entity e : EntityArgument.getEntities(ctx,"targets")) {
                                    if (!(e instanceof LivingEntity le)) continue;
                                    VirusManager.InfectionRecord r=VirusManager.getRecord(le,vid);
                                    if (r==null) continue;
                                    if (stage<0||stage>=r.virus.getStages().size()) { err(ctx.getSource(),"Stage out of range"); continue; }
                                    r.currentStage=stage; r.ticksInStage=0; n++;
                                }
                                int fn=n,ds=stage+1; ctx.getSource().sendSuccess(()->ok("Set "+fn+" entities to stage "+ds+" of "+vid),false);
                                return n;
                            })))))

            // virus sub-commands
            .then(Commands.literal("virus")
                .then(Commands.literal("list").executes(ctx->{
                    StringBuilder sb=new StringBuilder("Registered viruses: "); boolean f=true;
                    for (Virus v:VirusRegistry.all()) { if(!f) sb.append(", "); sb.append(v.getId()); f=false; }
                    ctx.getSource().sendSuccess(()->ok(sb.toString()),false); return 1;
                }))
                .then(Commands.argument("virusId", StringArgumentType.word())
                    .then(Commands.literal("info").executes(ctx->{
                        String vid=StringArgumentType.getString(ctx,"virusId");
                        Optional<Virus> vOpt=VirusRegistry.get(vid);
                        if (vOpt.isEmpty()) return err(ctx.getSource(),"Unknown virus: "+vid);
                        ctx.getSource().sendSuccess(()->Component.literal(virusInfo(vOpt.get())).withStyle(ChatFormatting.AQUA),false);
                        return 1;
                    }))
                    // numeric overrides
                    .then(numericOverride("airborne_radius",   0.5, 128, (id,v)->VirusRegistry.overrideAirborneRadius(id,v)))
                    .then(numericOverride("airborne_chance",   0.0, 1.0, (id,v)->VirusRegistry.overrideAirborneChance(id,v)))
                    .then(numericOverride("bloodborne_radius", 0.5, 128, (id,v)->VirusRegistry.overrideBloodborneRadius(id,v)))
                    .then(numericOverride("bloodborne_chance", 0.0, 1.0, (id,v)->VirusRegistry.overrideBloodborneChance(id,v)))
                    .then(numericOverride("bleeding_zone_radius",  0.5, 32,  (id,v)->{ VirusRegistry.MutableVirus m=VirusRegistry.getMutable(id); if(m!=null) m.setBleedingZoneRadius(v); }))
                    .then(numericOverride("bleeding_infect_chance",0.0, 1.0, (id,v)->{ VirusRegistry.MutableVirus m=VirusRegistry.getMutable(id); if(m!=null) m.setBleedingInfectChance(v); }))
                    .then(numericOverride("vomit_fire_chance",   0.0, 1.0, (id,v)->{ VirusRegistry.MutableVirus m=VirusRegistry.getMutable(id); if(m!=null) m.setVomitFireChance(v); }))
                    .then(numericOverride("vomit_infect_chance", 0.0, 1.0, (id,v)->{ VirusRegistry.MutableVirus m=VirusRegistry.getMutable(id); if(m!=null) m.setVomitInfectChance(v); }))
                    .then(numericOverride("vomit_splash_radius", 0.5, 32,  (id,v)->{ VirusRegistry.MutableVirus m=VirusRegistry.getMutable(id); if(m!=null) m.setVomitSplashRadius(v); }))
                    // addvector / removevector
                    .then(Commands.literal("addvector")
                        .then(Commands.argument("vector", StringArgumentType.word()).executes(ctx->{
                            String vid=StringArgumentType.getString(ctx,"virusId");
                            String vec=StringArgumentType.getString(ctx,"vector").toUpperCase();
                            VirusRegistry.MutableVirus m=VirusRegistry.getMutable(vid);
                            if (m==null) return err(ctx.getSource(),"Unknown virus: "+vid);
                            try { m.addVector(Virus.InfectionType.valueOf(vec)); ctx.getSource().sendSuccess(()->ok("Added vector "+vec+" to "+vid),false); return 1; }
                            catch (IllegalArgumentException e) { return err(ctx.getSource(),"Unknown vector: "+vec+" (airborne/bloodborne/bleeding/vomit)"); }
                        })))
                    .then(Commands.literal("removevector")
                        .then(Commands.argument("vector", StringArgumentType.word()).executes(ctx->{
                            String vid=StringArgumentType.getString(ctx,"virusId");
                            String vec=StringArgumentType.getString(ctx,"vector").toUpperCase();
                            VirusRegistry.MutableVirus m=VirusRegistry.getMutable(vid);
                            if (m==null) return err(ctx.getSource(),"Unknown virus: "+vid);
                            try { m.removeVector(Virus.InfectionType.valueOf(vec)); ctx.getSource().sendSuccess(()->ok("Removed vector "+vec+" from "+vid),false); return 1; }
                            catch (IllegalArgumentException e) { return err(ctx.getSource(),"Unknown vector: "+vec); }
                        })))
                    // addstage / removestage
                    .then(Commands.literal("addstage")
                        .then(Commands.argument("durationSeconds", IntegerArgumentType.integer(1)).executes(ctx->{
                            String vid=StringArgumentType.getString(ctx,"virusId");
                            int dur=IntegerArgumentType.getInteger(ctx,"durationSeconds");
                            VirusRegistry.MutableVirus m=VirusRegistry.getMutable(vid);
                            if (m==null) return err(ctx.getSource(),"Unknown virus: "+vid);
                            m.addStage(new InfectionStage(dur*20, new ArrayList<>()));
                            ctx.getSource().sendSuccess(()->ok("Added empty stage ("+dur+"s) to "+vid),false);
                            return 1;
                        })))
                    .then(Commands.literal("removestage")
                        .then(Commands.argument("stageNum", IntegerArgumentType.integer(1)).executes(ctx->{
                            String vid=StringArgumentType.getString(ctx,"virusId");
                            int idx=IntegerArgumentType.getInteger(ctx,"stageNum")-1;
                            VirusRegistry.MutableVirus m=VirusRegistry.getMutable(vid);
                            if (m==null) return err(ctx.getSource(),"Unknown virus: "+vid);
                            if (!m.removeStage(idx)) return err(ctx.getSource(),"Stage index out of range");
                            ctx.getSource().sendSuccess(()->ok("Removed stage "+(idx+1)+" from "+vid),false);
                            return 1;
                        })))
                    // stage <n> duration / addeffect / cleareffects
                    .then(Commands.literal("stage")
                        .then(Commands.argument("stageNum", IntegerArgumentType.integer(1))
                            .then(Commands.literal("duration")
                                .then(Commands.argument("seconds", IntegerArgumentType.integer(1)).executes(ctx->{
                                    String vid=StringArgumentType.getString(ctx,"virusId");
                                    int idx=IntegerArgumentType.getInteger(ctx,"stageNum")-1;
                                    int dur=IntegerArgumentType.getInteger(ctx,"seconds");
                                    VirusRegistry.MutableVirus m=VirusRegistry.getMutable(vid);
                                    if (m==null) return err(ctx.getSource(),"Unknown virus: "+vid);
                                    if (idx<0||idx>=m.getStages().size()) return err(ctx.getSource(),"Stage out of range");
                                    InfectionStage old=m.getStages().get(idx);
                                    m.setStage(idx, new InfectionStage(dur*20, old.getEffects()));
                                    ctx.getSource().sendSuccess(()->ok("Stage "+(idx+1)+" of "+vid+" duration -> "+dur+"s"),false);
                                    return 1;
                                })))
                            .then(Commands.literal("addeffect")
                                .then(Commands.argument("effectId", StringArgumentType.word())
                                    .then(Commands.argument("amplifier", IntegerArgumentType.integer(0,9)).executes(ctx->{
                                        String vid=StringArgumentType.getString(ctx,"virusId");
                                        int idx=IntegerArgumentType.getInteger(ctx,"stageNum")-1;
                                        String eid=StringArgumentType.getString(ctx,"effectId");
                                        int amp=IntegerArgumentType.getInteger(ctx,"amplifier");
                                        VirusRegistry.MutableVirus m=VirusRegistry.getMutable(vid);
                                        if (m==null) return err(ctx.getSource(),"Unknown virus: "+vid);
                                        if (idx<0||idx>=m.getStages().size()) return err(ctx.getSource(),"Stage out of range");
                                        // ForgeRegistries covers vanilla AND all mod effects (e.g. hordes:infected).
                                        // If the effect is not found it means the mod providing it is not loaded;
                                        // we still store the entry by ID so it resolves at apply-time if the mod loads.
                                        MobEffect effect = ForgeRegistries.MOB_EFFECTS.getValue(new ResourceLocation(eid));
                                        InfectionStage old=m.getStages().get(idx);
                                        List<InfectionStage.StagedEffect> fx=new ArrayList<>(old.getEffects());
                                        fx.add(effect != null
                                            ? new InfectionStage.StagedEffect(effect, amp)
                                            : new InfectionStage.StagedEffect(eid, amp));
                                        m.setStage(idx, new InfectionStage(old.getDurationTicks(), fx));
                                        ctx.getSource().sendSuccess(()->ok("Added "+eid+" amp "+amp+" to stage "+(idx+1)+" of "+vid),false);
                                        return 1;
                                    }))))
                            .then(Commands.literal("cleareffects").executes(ctx->{
                                String vid=StringArgumentType.getString(ctx,"virusId");
                                int idx=IntegerArgumentType.getInteger(ctx,"stageNum")-1;
                                VirusRegistry.MutableVirus m=VirusRegistry.getMutable(vid);
                                if (m==null) return err(ctx.getSource(),"Unknown virus: "+vid);
                                if (idx<0||idx>=m.getStages().size()) return err(ctx.getSource(),"Stage out of range");
                                m.setStage(idx, new InfectionStage(m.getStages().get(idx).getDurationTicks(), new ArrayList<>()));
                                ctx.getSource().sendSuccess(()->ok("Cleared effects from stage "+(idx+1)+" of "+vid),false);
                                return 1;
                            }))))))

            // corpse (debug – force-spawn a corpse for a given entity type)
            .then(Commands.literal("corpse")
                .then(Commands.argument("entityTypeId", StringArgumentType.string())
                    .executes(ctx -> {
                        String rawId = StringArgumentType.getString(ctx, "entityTypeId");
                        // Normalise: strip surrounding quotes Minecraft may add
                        String entityTypeId = rawId.replaceAll("^\"|\"$", "");

                        ServerLevel sl;
                        Vec3 spawnPos;
                        try {
                            sl = ctx.getSource().getLevel();
                            spawnPos = ctx.getSource().getPosition();
                        } catch (Exception ex) {
                            return err(ctx.getSource(), "Must be run from in-game or as a positioned entity.");
                        }

                        CorpseData data = new CorpseData(
                            java.util.UUID.randomUUID(),
                            entityTypeId,
                            new net.minecraft.nbt.CompoundTag(),
                            ctx.getSource().getRotation().y,
                            0f,
                            spawnPos,
                            sl.getGameTime(),
                            false
                        );

                        java.util.UUID corpseId = CorpseManager.get().addCorpse(sl, data);
                        if (corpseId == null) corpseId = java.util.UUID.randomUUID();
                        CorpseSavedData.markDirty(sl);

                        CorpseEntity ce = CorpseEntity.fromData(sl, data, corpseId);
                        sl.addFreshEntity(ce);

                        String safeId = entityTypeId;
                        ctx.getSource().sendSuccess(
                            () -> ok("Spawned debug corpse for '" + safeId + "' at " +
                                     String.format("%.1f %.1f %.1f",
                                         spawnPos.x, spawnPos.y, spawnPos.z)),
                            false
                        );
                        return 1;
                    })))

            // immune – grant a virus immunity to targets
            .then(Commands.literal("immune")
                .then(Commands.argument("targets", EntityArgument.entities())
                    .then(Commands.argument("virusId", StringArgumentType.word())
                        .executes(ctx -> {
                            String vid = StringArgumentType.getString(ctx, "virusId");
                            if (com.pathology.mod.virus.VirusRegistry.get(vid).isEmpty())
                                return err(ctx.getSource(), "Unknown virus: " + vid + knownViruses());
                            int n = 0;
                            for (Entity e : EntityArgument.getEntities(ctx, "targets")) {
                                if (!(e instanceof LivingEntity le)) continue;
                                com.pathology.mod.virus.ImmunityManager.grantImmunity(le, vid);
                                n++;
                            }
                            int fn = n;
                            ctx.getSource().sendSuccess(() -> ok("Granted immunity to " + vid + " for " + fn + " entity/entities."), false);
                            return n;
                        }))))
            // removeimmune – revoke a virus immunity from targets
            .then(Commands.literal("removeimmune")
                .then(Commands.argument("targets", EntityArgument.entities())
                    .then(Commands.argument("virusId", StringArgumentType.word())
                        .executes(ctx -> {
                            String vid = StringArgumentType.getString(ctx, "virusId");
                            int n = 0;
                            for (Entity e : EntityArgument.getEntities(ctx, "targets")) {
                                if (!(e instanceof LivingEntity le)) continue;
                                com.pathology.mod.virus.ImmunityManager.revokeImmunity(le, vid);
                                n++;
                            }
                            int fn = n;
                            ctx.getSource().sendSuccess(() -> ok("Revoked immunity to " + vid + " from " + fn + " entity/entities."), false);
                            return n;
                        }))))
            // immunestatus – list all immunities for a target
            .then(Commands.literal("immunestatus")
                .executes(ctx -> {
                    ServerPlayer player = ctx.getSource().getPlayerOrException();
                    printImmunityStatus(ctx.getSource(), player);
                    return 1;
                })
                .then(Commands.argument("target", EntityArgument.entity())
                    .executes(ctx -> {
                        Entity e = EntityArgument.getEntity(ctx, "target");
                        if (!(e instanceof LivingEntity le))
                            return err(ctx.getSource(), "Not a living entity");
                        printImmunityStatus(ctx.getSource(), le);
                        return 1;
                    })))
            // syringe
            .then(Commands.literal("syringe")
                .then(Commands.argument("virusId", StringArgumentType.word()).executes(ctx->{
                    ServerPlayer player=ctx.getSource().getPlayerOrException();
                    String vid=StringArgumentType.getString(ctx,"virusId");
                    if (VirusRegistry.get(vid).isEmpty()) return err(ctx.getSource(),"Unknown virus: "+vid+knownViruses());
                    ItemStack held=player.getMainHandItem();
                    if (held.getItem() instanceof PathogenSyringeItem) {
                        PathogenSyringeItem.setLoadedVirus(held,vid);
                        ctx.getSource().sendSuccess(()->ok("Syringe reloaded with: "+vid),false);
                    } else {
                        ItemStack s=new ItemStack(ModItems.PATHOGEN_SYRINGE.get());
                        PathogenSyringeItem.setLoadedVirus(s,vid);
                        s.setHoverName(Component.literal("Syringe ["+vid+"]"));
                        player.addItem(s);
                        ctx.getSource().sendSuccess(()->ok("Given syringe loaded with: "+vid),false);
                    }
                    return 1;
                })))

            // vial – give a throwable virus vial loaded with a virus
            .then(Commands.literal("vial")
                .then(Commands.argument("virusId", StringArgumentType.word()).executes(ctx->{
                    ServerPlayer player=ctx.getSource().getPlayerOrException();
                    String vid=StringArgumentType.getString(ctx,"virusId");
                    if (VirusRegistry.get(vid).isEmpty()) return err(ctx.getSource(),"Unknown virus: "+vid+knownViruses());
                    ItemStack held=player.getMainHandItem();
                    if (held.getItem() instanceof com.pathology.mod.item.VirusVialItem) {
                        com.pathology.mod.item.VirusVialItem.setLoadedVirus(held,vid);
                        ctx.getSource().sendSuccess(()->ok("Vial filled with: "+vid),false);
                    } else {
                        ItemStack vial=new ItemStack(ModItems.VIRUS_VIAL.get());
                        com.pathology.mod.item.VirusVialItem.setLoadedVirus(vial,vid);
                        vial.setHoverName(Component.literal("Vial ["+vid+"]"));
                        player.addItem(vial);
                        ctx.getSource().sendSuccess(()->ok("Given virus vial filled with: "+vid),false);
                    }
                    return 1;
                })))

            // infection test – toggle glowing when in corpse airborne radius
            .then(Commands.literal("infection")
                .then(Commands.literal("test")
                    .executes(ctx -> {
                        ServerPlayer player = ctx.getSource().getPlayerOrException();
                        java.util.UUID uid = player.getUUID();
                        if (INFECTION_TEST_PLAYERS.contains(uid)) {
                            INFECTION_TEST_PLAYERS.remove(uid);
                            // Remove glow if it was active
                            player.setGlowingTag(false);
                            ctx.getSource().sendSuccess(
                                () -> ok("Infection proximity test OFF — glow disabled"), false);
                        } else {
                            INFECTION_TEST_PLAYERS.add(uid);
                            ctx.getSource().sendSuccess(
                                () -> Component.literal(
                                    "[Pathology] Infection proximity test ON — you will glow when within "
                                    + String.format("%.1f", com.pathology.mod.corpse.CorpseManager.INFECTION_RADIUS)
                                    + " blocks of a corpse.").withStyle(ChatFormatting.YELLOW), false);
                        }
                        return 1;
                    })))

            // debuginfection – toggle infection-chance display for the executing player
            .then(Commands.literal("debuginfection")
                .executes(ctx->{
                    ServerPlayer player=ctx.getSource().getPlayerOrException();
                    java.util.UUID uid=player.getUUID();
                    if (ModEvents.INFECTION_DEBUG_PLAYERS.contains(uid)) {
                        ModEvents.INFECTION_DEBUG_PLAYERS.remove(uid);
                        ctx.getSource().sendSuccess(()->ok("Infection-chance debug OFF"),false);
                    } else {
                        ModEvents.INFECTION_DEBUG_PLAYERS.add(uid);
                        double protection=ProtectionUtil.getProtectionReduction(player);
                        ctx.getSource().sendSuccess(()->Component.literal("[Pathology] Infection-chance debug ON | Armor reduction: "+String.format("%.1f%%",protection*100.0)).withStyle(ChatFormatting.YELLOW),false);
                        for (Virus v : VirusRegistry.all()) {
                            if (v.isAirborne()) {
                                double chance=v.getAirborneChance()*(1.0-protection)*100.0;
                                String line="  "+v.getId()+" airborne: "+String.format("%.1f%%",chance);
                                ctx.getSource().sendSuccess(()->Component.literal(line).withStyle(ChatFormatting.YELLOW),false);
                            }
                            if (v.isBloodborne()) {
                                double chance=v.getBloodborneChance()*(1.0-protection)*100.0;
                                String line="  "+v.getId()+" bloodborne: "+String.format("%.1f%%",chance);
                                ctx.getSource().sendSuccess(()->Component.literal(line).withStyle(ChatFormatting.YELLOW),false);
                            }
                            if (v.isBleeding()) {
                                double chance=v.getBleedingInfectChance()*(1.0-protection)*100.0;
                                String line="  "+v.getId()+" bleeding: "+String.format("%.2f%%",chance)+"/tick";
                                ctx.getSource().sendSuccess(()->Component.literal(line).withStyle(ChatFormatting.YELLOW),false);
                            }
                            if (v.isVomit()) {
                                double chance=v.getVomitInfectChance()*(1.0-protection)*100.0;
                                String line="  "+v.getId()+" vomit: "+String.format("%.1f%%",chance);
                                ctx.getSource().sendSuccess(()->Component.literal(line).withStyle(ChatFormatting.YELLOW),false);
                            }
                        }
                    }
                    return 1;
                }))
        );
    }

    // ═════════════════════════════════════════════════════════════════════════
    // /pathogen – virus creation
    // ═════════════════════════════════════════════════════════════════════════

    private void registerPathogenCommands(CommandDispatcher<CommandSourceStack> d) {
        d.register(Commands.literal("pathogen")
            .requires(src -> src.hasPermission(2))

            // create <name> <vectors> <stageCount> <finalEffectId> [amplifier]
            .then(Commands.literal("create")
                .then(Commands.argument("name", StringArgumentType.word())
                    .then(Commands.argument("vectors", StringArgumentType.word())
                        .then(Commands.argument("stageCount", IntegerArgumentType.integer(1, 10))
                            .then(Commands.argument("finalEffect", StringArgumentType.word())
                                // optional amplifier — default branch (no amplifier arg) uses 0
                                .executes(ctx -> createVirus(ctx.getSource(),
                                    StringArgumentType.getString(ctx,"name"),
                                    StringArgumentType.getString(ctx,"vectors"),
                                    IntegerArgumentType.getInteger(ctx,"stageCount"),
                                    StringArgumentType.getString(ctx,"finalEffect"), 0))
                                .then(Commands.argument("amplifier", IntegerArgumentType.integer(0,9))
                                    .executes(ctx -> createVirus(ctx.getSource(),
                                        StringArgumentType.getString(ctx,"name"),
                                        StringArgumentType.getString(ctx,"vectors"),
                                        IntegerArgumentType.getInteger(ctx,"stageCount"),
                                        StringArgumentType.getString(ctx,"finalEffect"),
                                        IntegerArgumentType.getInteger(ctx,"amplifier")))))))))

            // delete <name>
            .then(Commands.literal("delete")
                .then(Commands.argument("name", StringArgumentType.word()).executes(ctx->{
                    String name=StringArgumentType.getString(ctx,"name");
                    if (VirusRegistry.remove(name)) ctx.getSource().sendSuccess(()->ok("Deleted virus: "+name),false);
                    else return err(ctx.getSource(),"Cannot delete built-in or unknown virus: "+name);
                    return 1;
                })))

            // list
            .then(Commands.literal("list").executes(ctx->{
                StringBuilder sb=new StringBuilder("All viruses: "); boolean f=true;
                for (Virus v:VirusRegistry.all()) { if(!f) sb.append(", "); sb.append(v.getId()); f=false; }
                ctx.getSource().sendSuccess(()->ok(sb.toString()),false); return 1;
            }))
        );
    }

    private int createVirus(CommandSourceStack source, String name, String vectorsRaw,
                             int stageCount, String finalEffectId, int amplifier) {
        if (VirusRegistry.exists(name))
            return err(source, "Virus '"+name+"' already exists. Use /pathogen delete first.");

        // Parse vectors
        List<Virus.InfectionType> types = new ArrayList<>();
        for (String tok : vectorsRaw.split(",")) {
            try { types.add(Virus.InfectionType.valueOf(tok.trim().toUpperCase())); }
            catch (IllegalArgumentException e) { return err(source,"Unknown vector: "+tok+" (airborne/bloodborne/bleeding/vomit)"); }
        }

        // Parse final stage effect via ForgeRegistries (covers vanilla + all mod effects).
        // If null the mod providing it isn't loaded; store by ID for deferred resolution.
        MobEffect effect = ForgeRegistries.MOB_EFFECTS.getValue(new ResourceLocation(finalEffectId));

        // Build stages: all stages empty except last
        List<InfectionStage> stages = new ArrayList<>();
        for (int i = 0; i < stageCount - 1; i++)
            stages.add(new InfectionStage(60*20, new ArrayList<>()));
        stages.add(new InfectionStage(60*20,
            List.of(effect != null
                ? new InfectionStage.StagedEffect(effect, amplifier)
                : new InfectionStage.StagedEffect(finalEffectId, amplifier))));

        Virus v = new Virus(name, stages, types,
            5.0, 0.05,          // airborne radius/chance
            3.0, 0.3, 60,       // bloodborne radius/chance/duration
            300, 1.5, 160, 0.02,// bleeding interval/zone-radius/zone-dur/chance
            400, 0.5, 1.0, 2.0);// vomit interval/fire-chance/infect-chance/splash-radius

        VirusRegistry.register(v);
        source.sendSuccess(()->ok("Created virus '"+name+"' | vectors: "+vectorsRaw+" | "+stageCount+" stages | final effect: "+finalEffectId+" amp "+amplifier), false);
        source.sendSuccess(()->Component.literal("  Edit stages: /pathology virus "+name+" stage <n> duration <s>").withStyle(ChatFormatting.GRAY), false);
        source.sendSuccess(()->Component.literal("  Add effects:  /pathology virus "+name+" stage <n> addeffect <effectId> <amp>").withStyle(ChatFormatting.GRAY), false);
        return 1;
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    @FunctionalInterface interface Setter { void set(String id, double v); }

    private com.mojang.brigadier.builder.LiteralArgumentBuilder<CommandSourceStack> numericOverride(
            String name, double min, double max, Setter setter) {
        return Commands.literal(name)
            .then(Commands.argument("value", DoubleArgumentType.doubleArg(min,max))
                .executes(ctx->{
                    String vid=StringArgumentType.getString(ctx,"virusId");
                    double val=DoubleArgumentType.getDouble(ctx,"value");
                    if (VirusRegistry.get(vid).isEmpty()) return err(ctx.getSource(),"Unknown virus: "+vid);
                    setter.set(vid,val);
                    ctx.getSource().sendSuccess(()->ok(vid+" "+name+" -> "+val),false);
                    return 1;
                }));
    }

    private static void printStatus(CommandSourceStack src, LivingEntity entity) {
        Collection<VirusManager.InfectionRecord> infections = VirusManager.getInfections(entity);
        String name = entity.getName().getString();
        if (infections.isEmpty()) { src.sendSuccess(()->Component.literal("[Pathology] "+name+" is not infected.").withStyle(ChatFormatting.AQUA),false); return; }
        src.sendSuccess(()->Component.literal("[Pathology] "+name+" — "+infections.size()+" infection(s):").withStyle(ChatFormatting.GOLD),false);
        for (VirusManager.InfectionRecord r : infections) {
            int si=Math.min(r.currentStage,r.virus.getStages().size()-1);
            int sl=Math.max(0,(r.virus.getStages().get(si).getDurationTicks()-r.ticksInStage)/20);
            int tot=r.virus.getStages().size();
            String vectors=(r.virus.isAirborne()?"airborne ":"")+(r.virus.isBloodborne()?"bloodborne ":"")+(r.virus.isBleeding()?"bleeding ":"")+(r.virus.isVomit()?"vomit":"");
            src.sendSuccess(()->Component.literal("  > "+r.virus.getId()+" | Stage "+(r.currentStage+1)+"/"+tot+" | "+sl+"s | "+vectors.trim()).withStyle(ChatFormatting.WHITE),false);
        }
    }

    private static String virusInfo(Virus v) {
        StringBuilder sb=new StringBuilder("=== "+v.getId()+" ===\n");
        sb.append("  Vectors: ");
        if(v.isAirborne())   sb.append("airborne(r=").append(v.getAirborneRadius()).append(",c=").append(String.format("%.0f%%",v.getAirborneChance()*100)).append(") ");
        if(v.isBloodborne()) sb.append("bloodborne(r=").append(v.getBloodborneRadius()).append(",c=").append(String.format("%.0f%%",v.getBloodborneChance()*100)).append(") ");
        if(v.isBleeding())   sb.append("bleeding(every ").append(v.getBleedingIntervalTicks()/20).append("s,zone=").append(v.getBleedingZoneRadius()).append("b) ");
        if(v.isVomit())      sb.append("vomit(every ").append(v.getVomitIntervalTicks()/20).append("s,fire=").append(String.format("%.0f%%",v.getVomitFireChance()*100)).append(") ");
        sb.append("\n  Stages: ").append(v.getStages().size()).append("\n");
        for (int i=0;i<v.getStages().size();i++) {
            InfectionStage s=v.getStages().get(i);
            sb.append("    Stage ").append(i+1).append(": ").append(s.getDurationTicks()/20).append("s, ").append(s.getEffects().size()).append(" effect(s)\n");
        }
        return sb.toString().trim();
    }

    private static void printImmunityStatus(net.minecraft.commands.CommandSourceStack src, LivingEntity entity) {
        java.util.Set<String> immunities = com.pathology.mod.virus.ImmunityManager.getImmunities(entity);
        String name = entity.getName().getString();
        if (immunities.isEmpty()) {
            src.sendSuccess(() -> Component.literal("[Pathology] " + name + " has no virus immunities.").withStyle(ChatFormatting.AQUA), false);
        } else {
            src.sendSuccess(() -> Component.literal("[Pathology] " + name + " is immune to " + immunities.size() + " virus(es):").withStyle(ChatFormatting.GOLD), false);
            for (String vid : immunities) {
                src.sendSuccess(() -> Component.literal("  > " + vid).withStyle(ChatFormatting.WHITE), false);
            }
        }
    }

    private static String knownViruses() {
        StringBuilder sb=new StringBuilder(" | Known: "); boolean f=true;
        for (Virus v:VirusRegistry.all()) { if(!f) sb.append(", "); sb.append(v.getId()); f=false; }
        return sb.toString();
    }

    private static Component ok(String msg) { return Component.literal("[Pathology] "+msg).withStyle(ChatFormatting.GREEN); }
    private static int err(CommandSourceStack s, String msg) { s.sendFailure(Component.literal("[Pathology] "+msg).withStyle(ChatFormatting.RED)); return 0; }
}
