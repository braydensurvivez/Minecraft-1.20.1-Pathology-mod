package com.pathology.mod.entity;

import com.pathology.mod.corpse.CorpseData;
import com.pathology.mod.corpse.CorpseManager;
import com.pathology.mod.corpse.CorpseSavedData;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraftforge.network.NetworkHooks;

import java.util.UUID;

/**
 * CorpseEntity v15 — corpses now have 20 HP and can be destroyed by attacking them.
 *
 * Changes vs v14:
 *  - setInvulnerable(true) removed from constructor.
 *  - isInvulnerableTo() no longer returns true unconditionally; only creative-mode
 *    players are blocked (matching vanilla behaviour for most entities).
 *  - Synced HEALTH float tracks current HP (max 20.0, i.e. 10 hearts).
 *  - hurt() reduces HEALTH and, when it reaches 0, calls CorpseManager.get().remove()
 *    + discard() so the corpse fully disappears from both the world and the manager.
 *  - NBT load/save updated to persist HEALTH so corpses keep their HP across reloads.
 *  - The clearcorpses command still works because clearAll() uses discard() directly.
 */
public class CorpseEntity extends Entity {

    // ── Constants ─────────────────────────────────────────────────────────────
    public static final float MAX_HEALTH = 300.0f;

    // ── Synced data keys ──────────────────────────────────────────────────────
    public static final EntityDataAccessor<String>  ENTITY_TYPE_ID =
            SynchedEntityData.defineId(CorpseEntity.class, EntityDataSerializers.STRING);
    public static final EntityDataAccessor<Integer> DECAY_STAGE =
            SynchedEntityData.defineId(CorpseEntity.class, EntityDataSerializers.INT);
    public static final EntityDataAccessor<Integer> BODY_COUNT =
            SynchedEntityData.defineId(CorpseEntity.class, EntityDataSerializers.INT);
    public static final EntityDataAccessor<String>  CORPSE_UUID =
            SynchedEntityData.defineId(CorpseEntity.class, EntityDataSerializers.STRING);
    public static final EntityDataAccessor<Boolean> IS_BURNING =
            SynchedEntityData.defineId(CorpseEntity.class, EntityDataSerializers.BOOLEAN);
    /** 0.0 = just ignited, 1.0 = fully charred / about to despawn. Synced to clients. */
    public static final EntityDataAccessor<Float> BURN_PROGRESS =
            SynchedEntityData.defineId(CorpseEntity.class, EntityDataSerializers.FLOAT);
    /** Current hit points, synced so clients can display a health bar if desired. */
    public static final EntityDataAccessor<Float> HEALTH =
            SynchedEntityData.defineId(CorpseEntity.class, EntityDataSerializers.FLOAT);

    // ── Inventory — 27 slots so ChestMenu.threeRows() is satisfied ───────────
    private final SimpleContainer inventory = new SimpleContainer(27);

    // ── Internal lifespan timer ───────────────────────────────────────────────────────────
    /** Ticks this entity has been alive. Corpse self-destructs after 1 minute (1200 ticks). */
    private static final int SELF_DESTRUCT_TICKS = 6000; // 5 minutes
    private int entityAliveTicks = 0;

    // ── Constructor ───────────────────────────────────────────────────────────

    public CorpseEntity(EntityType<?> type, Level level) {
        super(type, level);
        this.noPhysics = true;
        this.setNoGravity(true);
        this.setSilent(true);
        // Intentionally NOT calling setInvulnerable(true) — corpses can be killed.
    }

    // ── Factory helper ────────────────────────────────────────────────────────

    public static CorpseEntity fromData(Level level, CorpseData data, UUID corpseUUID) {
        CorpseEntity e = new CorpseEntity(ModEntityTypes.CORPSE.get(), level);
        e.moveTo(data.deathPos.x, data.deathPos.y, data.deathPos.z, data.yaw, 0f);
        e.getEntityData().set(ENTITY_TYPE_ID, data.entityTypeId);
        e.getEntityData().set(DECAY_STAGE,    data.decayStage);
        e.getEntityData().set(BODY_COUNT,     data.bodyCount);
        e.getEntityData().set(CORPSE_UUID,    corpseUUID.toString());
        e.getEntityData().set(IS_BURNING,     false);
        e.getEntityData().set(BURN_PROGRESS,  0.0f);
        e.getEntityData().set(HEALTH,         MAX_HEALTH);
        return e;
    }

    // ── SynchedEntityData ─────────────────────────────────────────────────────

    @Override
    protected void defineSynchedData() {
        this.entityData.define(ENTITY_TYPE_ID, "minecraft:zombie");
        this.entityData.define(DECAY_STAGE,    0);
        this.entityData.define(BODY_COUNT,     1);
        this.entityData.define(CORPSE_UUID,    "00000000-0000-0000-0000-000000000000");
        this.entityData.define(IS_BURNING,     false);
        this.entityData.define(BURN_PROGRESS,  0.0f);
        this.entityData.define(HEALTH,         MAX_HEALTH);
    }

    // ── Damage / health ───────────────────────────────────────────────────────

    /**
     * Accepts all damage sources.  Reduces HP and removes the corpse when it
     * reaches zero.  Returns true if the hit landed (always, unless already dead).
     */
    /** Returns true if the DamageSource represents any kind of fire/burning damage. */
    private static boolean isFireSource(DamageSource src) {
        // Vanilla damage type tags — covers inFire, onFire, fireball, hotFloor, and
        // any modded source that uses the #minecraft:is_fire damage type tag.
        net.minecraft.world.damagesource.DamageType type = src.type();
        // Check by message-id strings that vanilla always uses for fire sources
        String msgId = src.getMsgId();
        return msgId.equals("inFire")
            || msgId.equals("onFire")
            || msgId.equals("fireball")
            || msgId.equals("hotFloor")
            || msgId.equals("lava")
            || msgId.equals("arrow") && src.getDirectEntity() != null
               && src.getDirectEntity().isOnFire()
            || (src.getDirectEntity() instanceof net.minecraft.world.entity.projectile.AbstractArrow arrow
                && arrow.isOnFire())
            || (src.getDirectEntity() instanceof net.minecraft.world.entity.projectile.Fireball)
            || (src.getDirectEntity() instanceof net.minecraft.world.entity.projectile.SmallFireball)
            || (src.getDirectEntity() instanceof net.minecraft.world.entity.projectile.WitherSkull ws
                && !ws.isDangerous()); // fire charge (non-charged)
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (this.isRemoved()) return false;

        // Any fire/flame source immediately ignites the corpse (destroyByFire path)
        if (!level().isClientSide && isFireSource(source) && level() instanceof ServerLevel sl) {
            UUID id = getCorpseUUID();
            if (!CorpseManager.get().isBurning(id) && !this.isBurning()) {
                if (CorpseManager.get().get(id).isPresent()) {
                    CorpseManager.get().destroyByFire(id, sl);
                }
                this.setBurning(true);
                this.discard();
                CorpseSavedData.markDirty(sl);
            }
            return true;
        }

        float hp = this.entityData.get(HEALTH) - amount;
        if (hp <= 0f) {
            // Corpse destroyed — remove from manager and world.
            if (!level().isClientSide) {
                UUID id = getCorpseUUID();
                CorpseManager.get().remove(id);
                if (level() instanceof ServerLevel sl) {
                    CorpseSavedData.markDirty(sl);
                }
            }
            this.discard();
            return true;
        }

        this.entityData.set(HEALTH, hp);
        return true;
    }

    /** Allow all damage — no invulnerability override. */
    @Override
    public boolean isInvulnerableTo(DamageSource src) {
        return false;
    }

    // ── Interaction ───────────────────────────────────────────────────────────

    /**
     * Return CONSUME (server) / SUCCESS (client) so:
     *  1. The click is NOT consumed by vanilla before Forge fires EntityInteract.
     *  2. The hand-swing animation plays on the client.
     *  3. ModEvents.onPlayerRightClickEntity handles all real logic.
     */
    @Override
    public InteractionResult interact(Player player, InteractionHand hand) {
        return level().isClientSide
                ? InteractionResult.SUCCESS
                : InteractionResult.CONSUME;
    }

    // ── Tick ────────────────────────────────────────────────────────────────────────────────────────────────────────────

    /**
     * Internal lifespan timer — each corpse self-destructs exactly 1 minute after
     * it is spawned, independent of the CorpseManager timer.  This acts as a
     * safety net so orphaned entities (e.g. after a manager desync) still despawn.
     */
    @Override
    public void tick() {
        super.tick();
        if (!level().isClientSide) {
            entityAliveTicks++;
            if (entityAliveTicks >= SELF_DESTRUCT_TICKS) {
                UUID id = getCorpseUUID();
                CorpseManager.get().remove(id);
                if (level() instanceof ServerLevel sl) {
                    CorpseSavedData.markDirty(sl);
                }
                this.kill();
            }
        }
    }

    // ── Hit-box / pickability ─────────────────────────────────────────────────
    // Corpses have NO physical collision — players and mobs walk through them.
    // isPickable() must stay true so right-click (EntityInteract) still fires.
    @Override public boolean isPickable()          { return true; }
    @Override public boolean canBeCollidedWith()   { return false; }
    @Override public boolean isPushable()          { return false; }
    @Override public float   getPickRadius()       { return 0.0F; }

    // ── Convenience getters / setters ─────────────────────────────────────────

    public String  getEntityTypeId()   { return this.entityData.get(ENTITY_TYPE_ID); }
    public int     getDecayStage()     { return this.entityData.get(DECAY_STAGE); }
    public int     getBodyCount()      { return this.entityData.get(BODY_COUNT); }
    public UUID    getCorpseUUID()     {
        try { return UUID.fromString(this.entityData.get(CORPSE_UUID)); }
        catch (IllegalArgumentException e) { return new UUID(0, 0); }
    }
    public boolean isBurning()         { return this.entityData.get(IS_BURNING); }
    public float   getBurnProgress()   { return this.entityData.get(BURN_PROGRESS); }
    public float   getHealth()         { return this.entityData.get(HEALTH); }

    /** Never report as on-fire to vanilla — the vanilla flame overlay is scaled to
     *  the entity bounding box and looks enormous on a flat corpse. We render our
     *  own fire via custom particles in ModEvents instead. */
    @Override
    public boolean isOnFire() { return false; }

    public void setDecayStage(int s)     { this.entityData.set(DECAY_STAGE, s); }
    public void setBodyCount(int n)      { this.entityData.set(BODY_COUNT, n); }
    public void setCorpseUUID(UUID id)   { this.entityData.set(CORPSE_UUID, id.toString()); }
    public void setBurning(boolean b)    { this.entityData.set(IS_BURNING, b); }
    public void setBurnProgress(float p) { this.entityData.set(BURN_PROGRESS, Math.max(0f, Math.min(1f, p))); }
    public void setHealth(float hp)      { this.entityData.set(HEALTH, Math.max(0f, Math.min(MAX_HEALTH, hp))); }

    /** Direct access to the 27-slot inventory for loot population and GUI. */
    public SimpleContainer getInventory() { return inventory; }

    // ── NBT ───────────────────────────────────────────────────────────────────

    @Override
    protected void readAdditionalSaveData(CompoundTag tag) {
        this.entityData.set(ENTITY_TYPE_ID, tag.getString("corpseEntityType"));
        this.entityAliveTicks = tag.contains("corpseAliveTicks") ? tag.getInt("corpseAliveTicks") : 0;
        this.entityData.set(DECAY_STAGE,    tag.getInt("corpseDecayStage"));
        this.entityData.set(BODY_COUNT,     Math.max(1, tag.getInt("corpseBodyCount")));
        this.entityData.set(IS_BURNING,     tag.getBoolean("corpseIsBurning"));
        this.entityData.set(BURN_PROGRESS,  tag.getFloat("corpseBurnProgress"));
        this.entityData.set(HEALTH,         tag.contains("corpseHealth")
                                            ? Math.max(1f, tag.getFloat("corpseHealth"))
                                            : MAX_HEALTH);
        if (tag.contains("corpseUUID")) {
            this.entityData.set(CORPSE_UUID, tag.getString("corpseUUID"));
        }
        if (tag.contains("corpseInventory")) {
            ListTag items = tag.getList("corpseInventory", 10);
            inventory.clearContent();
            for (int i = 0; i < items.size(); i++) {
                CompoundTag slotTag = items.getCompound(i);
                int slot = slotTag.getByte("Slot") & 0xFF;
                if (slot < inventory.getContainerSize()) {
                    inventory.setItem(slot, net.minecraft.world.item.ItemStack.of(slotTag));
                }
            }
        }
    }

    @Override
    protected void addAdditionalSaveData(CompoundTag tag) {
        tag.putString("corpseEntityType",  getEntityTypeId());
        tag.putInt("corpseAliveTicks", this.entityAliveTicks);
        tag.putInt("corpseDecayStage",     getDecayStage());
        tag.putInt("corpseBodyCount",      getBodyCount());
        tag.putBoolean("corpseIsBurning",  isBurning());
        tag.putFloat("corpseBurnProgress", getBurnProgress());
        tag.putFloat("corpseHealth",       getHealth());
        tag.putString("corpseUUID",        this.entityData.get(CORPSE_UUID));
        ListTag items = new ListTag();
        for (int i = 0; i < inventory.getContainerSize(); i++) {
            net.minecraft.world.item.ItemStack stack = inventory.getItem(i);
            if (!stack.isEmpty()) {
                CompoundTag slotTag = stack.save(new CompoundTag());
                slotTag.putByte("Slot", (byte) i);
                items.add(slotTag);
            }
        }
        tag.put("corpseInventory", items);
    }

    // ── Networking ────────────────────────────────────────────────────────────

    @Override
    public Packet<ClientGamePacketListener> getAddEntityPacket() {
        return NetworkHooks.getEntitySpawningPacket(this);
    }
}
