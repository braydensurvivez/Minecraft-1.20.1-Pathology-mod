package com.pathology.mod.entity;

import com.pathology.mod.PathologyMod;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModEntityTypes {

    public static final DeferredRegister<EntityType<?>> ENTITY_TYPES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, PathologyMod.MOD_ID);

    public static final RegistryObject<EntityType<VirusVialEntity>> VIRUS_VIAL =
            ENTITY_TYPES.register("virus_vial",
                    () -> EntityType.Builder.<VirusVialEntity>of(VirusVialEntity::new, MobCategory.MISC)
                            .sized(0.25f, 0.25f)
                            .clientTrackingRange(4)
                            .updateInterval(10)
                            .build("virus_vial"));

    /**
     * Corpse entity: non-living, no AI, no movement.
     * Sized to roughly match a prone zombie (1.95 wide, 0.5 tall when lying flat).
     * clientTrackingRange 10 so players see corpses from a reasonable distance.
     * updateInterval 40 (2 s) – decay stage changes are infrequent.
     */
    public static final RegistryObject<EntityType<CorpseEntity>> CORPSE =
            ENTITY_TYPES.register("corpse",
                    () -> EntityType.Builder.<CorpseEntity>of(CorpseEntity::new, MobCategory.MISC)
                            .sized(1.95f, 0.5f)
                            .clientTrackingRange(10)
                            .updateInterval(40)
                            .build("corpse"));
}
