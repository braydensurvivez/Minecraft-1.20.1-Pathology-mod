package com.pathology.mod.client;

import com.pathology.mod.util.ProtectionUtil;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.entity.player.ItemTooltipEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = com.pathology.mod.PathologyMod.MOD_ID, value = Dist.CLIENT)
public class ProtectionTooltipHandler {

    @SubscribeEvent
    public static void onItemTooltip(ItemTooltipEvent event) {
        double protection = ProtectionUtil.getStackProtection(event.getItemStack());
        if (protection <= 0.0) return;
        int percent = (int) Math.round(protection * 100);
        event.getToolTip().add(
            Component.translatable("tooltip.pathologymod.infection_resistance", percent)
                .withStyle(ChatFormatting.GREEN)
        );
    }
}
