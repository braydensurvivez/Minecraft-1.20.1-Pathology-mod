Place your rasp.ogg sound file here as:
  pathology-mdk/src/main/resources/assets/pathologymod/sounds/rasp.ogg

This file is played to players infected with the Airborne Husk Flu (stages 2+).
It should be a raspy coughing/breathing sound.
The file must be in OGG Vorbis format.
