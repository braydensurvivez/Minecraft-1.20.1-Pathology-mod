package com.pathology.mod.virus;

import com.pathology.mod.PathologyMod;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraftforge.registries.ForgeRegistries;

import java.util.*;
import java.util.HashSet;
import java.util.Set;

public class VirusManager {

    private static final String NBT_KEY = "pathologymod_infections";
    private static final Map<UUID, Map<String, InfectionRecord>> INFECTIONS = new HashMap<>();

    /**
     * Entities marked as carriers spread viruses normally but do NOT advance
     * through infection stages, preventing spawn-infected mobs from dying to
     * their own infections.
     */
    private static final Set<UUID> CARRIERS = new HashSet<>();

    private VirusManager() {}

    /** Returns true if the entity is a zombie-type mob (undead that should not receive hordes:infected). */
    private static boolean isZombieEntity(LivingEntity entity) {
        net.minecraft.resources.ResourceLocation typeKey =
            net.minecraftforge.registries.ForgeRegistries.ENTITY_TYPES.getKey(entity.getType());
        if (typeKey == null) return false;
        String id = typeKey.toString();
        return id.equals("minecraft:zombie")
            || id.equals("minecraft:zombie_villager")
            || id.equals("minecraft:husk")
            || id.equals("minecraft:drowned")
            || id.equals("minecraft:zombified_piglin")
            || id.equals("hordes:zombie_player")
            || id.equals("mca:male_zombie_villager")
            || id.equals("mca:female_zombie_villager");
    }

    public static void markCarrier(LivingEntity entity) { CARRIERS.add(entity.getUUID()); }
    public static boolean isCarrier(LivingEntity entity) { return CARRIERS.contains(entity.getUUID()); }

    public static class InfectionRecord {
        public final Virus virus;
        public int currentStage;
        public int ticksInStage;
        /** True once hordes:infected MobEffect has been applied for this infection's final stage. */
        public boolean hordesEffectApplied;

        public InfectionRecord(Virus virus) {
            this.virus = virus;
            this.currentStage = 0;
            this.ticksInStage = 0;
            this.hordesEffectApplied = false;
        }

        public InfectionRecord(Virus virus, int stage, int ticks) {
            this.virus = virus;
            this.currentStage = stage;
            this.ticksInStage = ticks;
            this.hordesEffectApplied = false;
        }
    }

    // ── NBT persistence ───────────────────────────────────────────────────────

    /** Save all infections for this entity into its PersistentData NBT. */
    public static void saveToNBT(LivingEntity entity) {
        Map<String, InfectionRecord> map = INFECTIONS.get(entity.getUUID());
        CompoundTag persistent = entity.getPersistentData();
        if (map == null || map.isEmpty()) {
            persistent.remove(NBT_KEY);
            return;
        }
        ListTag list = new ListTag();
        for (InfectionRecord rec : map.values()) {
            CompoundTag tag = new CompoundTag();
            tag.putString("virusId", rec.virus.getId());
            tag.putInt("stage", rec.currentStage);
            tag.putInt("ticks", rec.ticksInStage);
            list.add(tag);
        }
        persistent.put(NBT_KEY, list);
    }

    /** Load infections for this entity from its PersistentData NBT. */
    public static void loadFromNBT(LivingEntity entity) {
        if (isNonBiologicalEntity(entity)) return;
        CompoundTag persistent = entity.getPersistentData();
        if (!persistent.contains(NBT_KEY, Tag.TAG_LIST)) return;
        ListTag list = persistent.getList(NBT_KEY, Tag.TAG_COMPOUND);
        if (list.isEmpty()) return;
        Map<String, InfectionRecord> map = INFECTIONS.computeIfAbsent(entity.getUUID(), k -> new HashMap<>());
        for (int i = 0; i < list.size(); i++) {
            CompoundTag tag = list.getCompound(i);
            String virusId = tag.getString("virusId");
            int stage = tag.getInt("stage");
            int ticks = tag.getInt("ticks");
            VirusRegistry.get(virusId).ifPresent(virus -> {
                if (!map.containsKey(virusId)) {
                    map.put(virusId, new InfectionRecord(virus, stage, ticks));
                    PathologyMod.LOGGER.debug("Loaded infection {} for entity {}", virusId, entity.getUUID());
                }
            });
        }
    }

    // ── Standard API ──────────────────────────────────────────────────────────

    public static boolean isInfected(LivingEntity entity, String virusId) {
        Map<String, InfectionRecord> map = INFECTIONS.get(entity.getUUID());
        return map != null && map.containsKey(virusId);
    }

    public static boolean isInfectedByAny(LivingEntity entity) {
        Map<String, InfectionRecord> map = INFECTIONS.get(entity.getUUID());
        return map != null && !map.isEmpty();
    }

    /**
     * Returns true for non-biological LivingEntity types that should never
     * be infected — currently ArmorStands. Display entities (TextDisplay,
     * ItemDisplay, BlockDisplay), ItemFrames, and Paintings extend Entity
     * rather than LivingEntity and therefore never reach this code, but
     * ArmorStand does extend LivingEntity and must be explicitly excluded.
     */
    public static boolean isNonBiologicalEntity(LivingEntity entity) {
        return entity instanceof ArmorStand;
    }

    /** Chance (0–1) that a player gains natural immunity when recovering from a virus. */
    public static final double NATURAL_IMMUNITY_CHANCE = 0.005; // 0.5 %

    public static void infect(LivingEntity entity, Virus virus) {
        // Non-biological entities (e.g. ArmorStands) cannot be infected.
        if (isNonBiologicalEntity(entity)) return;
        // Universal immunity: Creative and Spectator players cannot be infected by any vector.
        if (entity instanceof net.minecraft.server.level.ServerPlayer sp) {
            net.minecraft.world.level.GameType gm = sp.gameMode.getGameModeForPlayer();
            if (gm == net.minecraft.world.level.GameType.CREATIVE
                    || gm == net.minecraft.world.level.GameType.SPECTATOR) return;
        }
        // Immunity check — player only discovers immunity at exposure time
        if (ImmunityManager.isImmune(entity, virus.getId())) {
            PathologyMod.LOGGER.debug("Entity {} is immune to {} — infection blocked", entity.getUUID(), virus.getId());
            // Reveal immunity to the player only when they would have been infected
            if (entity instanceof net.minecraft.server.level.ServerPlayer sp) {
                sp.sendSystemMessage(
                    net.minecraft.network.chat.Component.literal(
                        "[Pathology] You were exposed to " + virus.getId() + ", but your body resisted it — you are immune!")
                    .withStyle(net.minecraft.ChatFormatting.LIGHT_PURPLE));
            }
            return;
        }
        if (isInfected(entity, virus.getId())) return;
        INFECTIONS.computeIfAbsent(entity.getUUID(), k -> new HashMap<>())
                  .put(virus.getId(), new InfectionRecord(virus));
        saveToNBT(entity);
        PathologyMod.LOGGER.debug("Entity {} infected with {}", entity.getUUID(), virus.getId());
    }

    public static void cure(LivingEntity entity, String virusId) {
        Map<String, InfectionRecord> map = INFECTIONS.get(entity.getUUID());
        if (map != null) {
            InfectionRecord rec = map.remove(virusId);
            // For players: never remove status effects here — the player may be in the process
            // of dying and the Hordes mod needs hordes:infected (and other effects) to remain
            // on the entity until after its death logic runs. onPlayerClone handles cleanup.
            // For non-players: safe to strip effects immediately.
            if (rec != null && !(entity instanceof net.minecraft.world.entity.player.Player)) {
                for (InfectionStage stage : rec.virus.getStages()) {
                    for (InfectionStage.StagedEffect se : stage.getEffects()) {
                        net.minecraft.world.effect.MobEffect resolved = se.getEffect();
                        if (resolved != null) {
                            entity.removeEffect(resolved);
                        }
                    }
                }
            }
            if (map.isEmpty()) INFECTIONS.remove(entity.getUUID());
        }
        saveToNBT(entity);
    }

    public static Collection<InfectionRecord> getInfections(LivingEntity entity) {
        Map<String, InfectionRecord> map = INFECTIONS.get(entity.getUUID());
        return map == null ? Collections.emptyList() : new ArrayList<>(map.values());
    }

    public static InfectionRecord getRecord(LivingEntity entity, String virusId) {
        Map<String, InfectionRecord> map = INFECTIONS.get(entity.getUUID());
        return map == null ? null : map.get(virusId);
    }

    public static void tick(LivingEntity entity) {
        if (isNonBiologicalEntity(entity)) return;
        Map<String, InfectionRecord> map = INFECTIONS.get(entity.getUUID());
        if (map == null || map.isEmpty()) return;

        // Carriers spread the virus but do not advance stages or suffer effects.
        if (CARRIERS.contains(entity.getUUID())) return;

        List<String> toRemove = new ArrayList<>();
        boolean changed = false;

        for (Map.Entry<String, InfectionRecord> entry : map.entrySet()) {
            InfectionRecord record = entry.getValue();
            Virus virus = record.virus;
            List<InfectionStage> stages = virus.getStages();

            if (record.currentStage >= stages.size()) { toRemove.add(entry.getKey()); continue; }

            InfectionStage stage = stages.get(record.currentStage);

            // Reapply effects every 60 ticks with a 70-tick duration.
            // The 10-tick overlap prevents flickering while still allowing
            // effects to fully expire between cycles — this is especially
            // important for MobEffects.HUNGER, which drains food continuously;
            // applying it every 20t with 40t duration kept it permanently active.
            if (record.ticksInStage % 60 == 0) {
                boolean isPlayer = entity instanceof net.minecraft.server.level.ServerPlayer;
                boolean isZombie = isZombieEntity(entity);

                for (InfectionStage.StagedEffect se : stage.getEffects()) {
                    boolean isHordesInfected = "hordes:infected".equals(se.getEffectId());

                    // hordes:infected: only apply to players, never to zombies or carriers.
                    // Applied once and left for the Hordes mod to manage.
                    if (isHordesInfected) {
                        if (!isPlayer || isZombie) continue;
                        if (record.hordesEffectApplied) continue;
                    }

                    // getEffect() resolves through ForgeRegistries, covering all mods.
                    // Returns null only if the providing mod is not loaded – skip gracefully.
                    MobEffect resolved = se.getEffect();
                    if (resolved == null) {
                        PathologyMod.LOGGER.warn(
                            "Pathology: effect '{}' not found in ForgeRegistries (mod not loaded?), skipping.",
                            se.getEffectId());
                        continue;
                    }
                    // Apply with visible=false so potion effect particles are hidden on mobs.
                    // hordes:infected is applied with no explicit duration (0) so the Hordes
                    // mod fills in the duration from its own config, matching /effect give behaviour.
                    if (isHordesInfected) {
                        entity.addEffect(new MobEffectInstance(resolved, 0, se.getAmplifier(), false, true));
                        record.hordesEffectApplied = true;
                    } else {
                        entity.addEffect(new MobEffectInstance(resolved, 70, se.getAmplifier(), false, false));
                    }
                }
            }

            record.ticksInStage++;

            if (record.ticksInStage >= stage.getDurationTicks()) {
                boolean isPermanent = virus.getId().equals("bloodbornehuskvirus") || virus.getId().equals("airbornehuskflu");
                boolean isLastStage = (record.currentStage >= stages.size() - 1);
                if (isPermanent && isLastStage) {
                    record.ticksInStage = 0;
                    changed = true;
                } else {
                    record.currentStage++;
                    record.ticksInStage = 0;
                    changed = true;
                    if (record.currentStage >= stages.size()) {
                        PathologyMod.LOGGER.debug("Entity {} recovered from {}", entity.getUUID(), virus.getId());
                        toRemove.add(entry.getKey());
                        // Small chance to gain natural immunity on recovery (players only)
                        if (entity instanceof net.minecraft.server.level.ServerPlayer sp) {
                            if (Math.random() < NATURAL_IMMUNITY_CHANCE) {
                                ImmunityManager.grantImmunity(sp, virus.getId());
                                PathologyMod.LOGGER.info("Player {} naturally became immune to {} (will be revealed on next exposure)", sp.getName().getString(), virus.getId());
                                // Do NOT notify here — the player will discover their immunity
                                // the next time they are exposed to the virus (see VirusManager.infect)
                            }
                        }
                    } else {
                        PathologyMod.LOGGER.debug("Entity {} -> stage {} of {}", entity.getUUID(), record.currentStage, virus.getId());
                    }
                }
            }
        }

        toRemove.forEach(map::remove);
        if (map.isEmpty()) INFECTIONS.remove(entity.getUUID());

        // Persist every 100 ticks (~5 seconds) or on stage change
        if (changed || entity.tickCount % 100 == 0) {
            saveToNBT(entity);
        }
    }
}
