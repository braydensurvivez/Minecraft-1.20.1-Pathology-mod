package com.pathology.mod.config;

import net.minecraftforge.common.ForgeConfigSpec;

/**
 * Configuration for foodborne exposure vectors:
 *  - Item contamination (infected player tags held consumables)
 *  - Dirty/unpurified water (ToughAsNails canteens → random illness)
 *  - Vanilla water bottles (minecraft:potion[water]) → 15% random illness
 *  - Rotten flesh consumption (→ bloodbornehuskvirus)
 */
public class FoodborneConfig {

    public static final ForgeConfigSpec SPEC;

    // ── Item contamination ────────────────────────────────────────────────────
    public static final ForgeConfigSpec.BooleanValue ITEM_CONTAMINATION_ENABLED;
    public static final ForgeConfigSpec.DoubleValue  ITEM_CONTAMINATION_CHANCE;

    // ── Dirty water (ToughAsNails) ────────────────────────────────────────────
    public static final ForgeConfigSpec.BooleanValue DIRTY_WATER_EXPOSURE_ENABLED;
    public static final ForgeConfigSpec.DoubleValue  DIRTY_WATER_AIRBORNE_CHANCE;

    // ── Vanilla water bottle ──────────────────────────────────────────────────
    /** Master toggle for vanilla water bottle exposure (minecraft:potion with Potion=water). */
    public static final ForgeConfigSpec.BooleanValue WATER_BOTTLE_EXPOSURE_ENABLED;

    /**
     * Chance (0.0–1.0) that drinking a vanilla water bottle exposes the player
     * to a random waterborne illness.  Default 0.15 (15%).
     */
    public static final ForgeConfigSpec.DoubleValue WATER_BOTTLE_EXPOSURE_CHANCE;

    // ── Rotten flesh ──────────────────────────────────────────────────────────
    public static final ForgeConfigSpec.BooleanValue ROTTEN_FLESH_EXPOSURE_ENABLED;
    public static final ForgeConfigSpec.DoubleValue  ROTTEN_FLESH_BLOODBORNE_CHANCE;

    static {
        ForgeConfigSpec.Builder b = new ForgeConfigSpec.Builder();

        b.comment(
            "=== Foodborne Exposure: Item Contamination ===",
            "Infected players automatically tag held consumables (food, potions, water) with their virus.",
            "Any player who eats/drinks the tagged item has a configurable chance to become infected."
        ).push("itemContamination");

        ITEM_CONTAMINATION_ENABLED = b
            .comment("Enable the item contamination mechanic (infected player taints consumables they hold).")
            .define("enabled", true);

        ITEM_CONTAMINATION_CHANCE = b
            .comment(
                "Chance (0.0–1.0) per virus that consuming a contaminated item causes infection.",
                "0.0 = never, 1.0 = guaranteed. Applied independently for each virus on the item."
            )
            .defineInRange("exposureChance", 0.75, 0.0, 1.0);

        b.pop();

        b.comment(
            "=== Foodborne Exposure: Dirty / Unpurified Water (ToughAsNails) ===",
            "Drinking unpurified ToughAsNails water canteens or dirty water bottles gives a",
            "configurable chance to contract a random waterborne illness."
        ).push("dirtyWater");

        DIRTY_WATER_EXPOSURE_ENABLED = b
            .comment("Enable waterborne illness exposure from unpurified ToughAsNails water items.")
            .define("enabled", true);

        DIRTY_WATER_AIRBORNE_CHANCE = b
            .comment(
                "Chance (0.0–1.0) of contracting a waterborne illness per drink of unpurified TAN water.",
                "0.0 = safe, 1.0 = always infected."
            )
            .defineInRange("exposureChance", 0.40, 0.0, 1.0);

        b.pop();

        b.comment(
            "=== Foodborne Exposure: Vanilla Water Bottles ===",
            "Drinking vanilla Minecraft water bottles (glass bottle filled from natural water)",
            "has a 15% chance per drink to expose the player to a random waterborne illness.",
            "Natural water is not purified and carries ambient pathogens."
        ).push("waterBottle");

        WATER_BOTTLE_EXPOSURE_ENABLED = b
            .comment("Enable waterborne illness exposure from vanilla water bottles (minecraft:potion[water]).")
            .define("enabled", true);

        WATER_BOTTLE_EXPOSURE_CHANCE = b
            .comment(
                "Chance (0.0–1.0) of contracting a random waterborne illness per vanilla water bottle drink.",
                "Default 0.15 (15%). Natural water is unfiltered and potentially contaminated."
            )
            .defineInRange("exposureChance", 0.15, 0.0, 1.0);

        b.pop();

        b.comment(
            "=== Foodborne Exposure: Rotten Flesh ===",
            "Eating minecraft:rotten_flesh gives a configurable chance to contract bloodbornehuskvirus",
            "(consuming infected animal/undead tissue)."
        ).push("rottenFlesh");

        ROTTEN_FLESH_EXPOSURE_ENABLED = b
            .comment("Enable bloodbornehuskvirus exposure from eating rotten flesh.")
            .define("enabled", true);

        ROTTEN_FLESH_BLOODBORNE_CHANCE = b
            .comment(
                "Chance (0.0–1.0) of contracting bloodbornehuskvirus per piece of rotten flesh eaten.",
                "0.0 = safe, 1.0 = always infected."
            )
            .defineInRange("exposureChance", 0.55, 0.0, 1.0);

        b.pop();

        SPEC = b.build();
    }
}
