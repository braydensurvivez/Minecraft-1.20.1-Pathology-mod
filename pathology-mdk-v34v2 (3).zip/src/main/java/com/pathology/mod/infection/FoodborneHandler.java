package com.pathology.mod.infection;

import com.pathology.mod.PathologyMod;
import com.pathology.mod.config.FoodborneConfig;
import com.pathology.mod.virus.VirusManager;
import com.pathology.mod.virus.VirusRegistry;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.GameType;
import net.minecraftforge.registries.ForgeRegistries;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Handles foodborne / waterborne exposure vectors.
 *
 * 1. CONTAMINATED ITEMS
 *    Infected player holds a consumable → item is silently tagged with virus IDs.
 *    Any player who consumes that item is exposed (no tooltip hint is shown).
 *
 * 2. DIRTY WATER (ToughAsNails)
 *    Unpurified canteens / dirty bottles → random waterborne illness.
 *
 * 3. VANILLA WATER BOTTLE (minecraft:potion with Potion=minecraft:water)
 *    Natural water is unfiltered. 15% chance per drink → random waterborne illness.
 *    Possible pool: airbornehuskflu, swine_flu, swamp_fever (whichever are registered).
 *
 * 4. ROTTEN FLESH
 *    Eating rotten flesh → configurable bloodbornehuskvirus chance.
 *
 * NOTE: All infection messages have been removed. Players are not informed of
 * exposure through chat — symptoms manifest naturally.
 */
public class FoodborneHandler {

    // NBT key written onto contaminated ItemStacks
    public static final String CONTAM_NBT_KEY = "pathology_contaminated_viruses";

    private static final Random RNG = new Random();

    // ── Waterborne illness pool (viruses that can be contracted from water) ───
    // Checked in order; any that are registered are eligible for random selection.
    private static final String[] WATERBORNE_POOL = {
        "airbornehuskflu",
        "swine_flu",
        "swamp_fever",
        "bone_fever"
    };

    // ── ToughAsNails dirty/unpurified water items ─────────────────────────────
    private static final List<String> DIRTY_WATER_ITEMS = List.of(
        "toughasnails:copper_dirty_water_canteen",
        "toughasnails:copper_water_canteen",
        "toughasnails:diamond_dirty_water_canteen",
        "toughasnails:diamond_water_canteen",
        "toughasnails:dirty_water_bottle",
        "toughasnails:gold_dirty_water_canteen",
        "toughasnails:gold_water_canteen",
        "toughasnails:iron_dirty_water_canteen",
        "toughasnails:iron_water_canteen",
        "toughasnails:leather_dirty_water_canteen",
        "toughasnails:leather_water_canteen",
        "toughasnails:netherite_dirty_water_canteen",
        "toughasnails:netherite_water_canteen"
    );

    private static final String ROTTEN_FLESH_ID = "minecraft:rotten_flesh";

    // ── Item classification ───────────────────────────────────────────────────

    /**
     * Returns true if this item should be auto-tagged when held by an infected player.
     * Covers food, potions, milk buckets, ToughAsNails water, and vanilla water bottles.
     */
    public static boolean isContaminatable(ItemStack stack) {
        if (stack.isEmpty()) return false;
        net.minecraft.world.item.Item item = stack.getItem();
        if (item.isEdible()) return true;
        if (item instanceof net.minecraft.world.item.PotionItem) return true;
        if (item instanceof net.minecraft.world.item.SplashPotionItem) return true;
        if (item instanceof net.minecraft.world.item.LingeringPotionItem) return true;
        ResourceLocation rl = ForgeRegistries.ITEMS.getKey(item);
        if (rl != null && rl.toString().equals("minecraft:milk_bucket")) return true;
        if (rl != null && DIRTY_WATER_ITEMS.contains(rl.toString())) return true;
        // Vanilla water bottles (minecraft:potion with water content) are contaminatable
        if (isVanillaWaterBottle(stack)) return true;
        return false;
    }

    public static boolean isDirtyWater(ItemStack stack) {
        if (stack.isEmpty()) return false;
        ResourceLocation rl = ForgeRegistries.ITEMS.getKey(stack.getItem());
        return rl != null && DIRTY_WATER_ITEMS.contains(rl.toString());
    }

    /**
     * Returns true if this is a vanilla Minecraft water bottle
     * (minecraft:potion item with NBT Potion tag of "minecraft:water").
     * These are filled from natural water sources and are NOT purified.
     */
    public static boolean isVanillaWaterBottle(ItemStack stack) {
        if (stack.isEmpty()) return false;
        ResourceLocation rl = ForgeRegistries.ITEMS.getKey(stack.getItem());
        if (rl == null || !rl.toString().equals("minecraft:potion")) return false;
        CompoundTag tag = stack.getTag();
        if (tag == null) return false;
        String potion = tag.getString("Potion");
        return "minecraft:water".equals(potion) || "water".equals(potion);
    }

    public static boolean isRottenFlesh(ItemStack stack) {
        if (stack.isEmpty()) return false;
        ResourceLocation rl = ForgeRegistries.ITEMS.getKey(stack.getItem());
        return rl != null && rl.toString().equals(ROTTEN_FLESH_ID);
    }

    // ── Contamination tagging ─────────────────────────────────────────────────

    /**
     * Called every ~1 second for each infected player's held items.
     * Silently tags the item with virus IDs — no tooltip or message is shown.
     */
    public static void tagHeldItemIfNeeded(ServerPlayer player) {
        if (!FoodborneConfig.ITEM_CONTAMINATION_ENABLED.get()) return;
        if (!VirusManager.isInfectedByAny(player)) return;

        GameType gm = player.gameMode.getGameModeForPlayer();
        if (gm == GameType.CREATIVE || gm == GameType.SPECTATOR) return;

        tagStack(player, player.getMainHandItem());
        tagStack(player, player.getOffhandItem());
    }

    private static void tagStack(ServerPlayer player, ItemStack stack) {
        if (!isContaminatable(stack)) return;

        List<String> virusIds = new ArrayList<>();
        for (VirusManager.InfectionRecord rec : VirusManager.getInfections(player)) {
            virusIds.add(rec.virus.getId());
        }
        if (virusIds.isEmpty()) return;

        CompoundTag tag = stack.getOrCreateTag();
        java.util.Set<String> existing = new java.util.LinkedHashSet<>();
        if (tag.contains(CONTAM_NBT_KEY, net.minecraft.nbt.Tag.TAG_LIST)) {
            ListTag list = tag.getList(CONTAM_NBT_KEY, net.minecraft.nbt.Tag.TAG_STRING);
            for (int i = 0; i < list.size(); i++) existing.add(list.getString(i));
        }
        boolean changed = existing.addAll(virusIds);
        if (!changed) return;

        ListTag list = new ListTag();
        for (String id : existing) list.add(StringTag.valueOf(id));
        tag.put(CONTAM_NBT_KEY, list);
        PathologyMod.LOGGER.debug("Tagged {} with viruses: {}", ForgeRegistries.ITEMS.getKey(stack.getItem()), existing);
    }

    // ── Consumption exposure ──────────────────────────────────────────────────

    /**
     * Called when a player finishes using/consuming an item.
     * Infection is silent — no chat messages are sent to the player.
     */
    public static void onItemConsumed(LivingEntity entity, ItemStack stack) {
        if (!(entity instanceof ServerPlayer player)) return;
        if (stack.isEmpty()) return;

        GameType gm = player.gameMode.getGameModeForPlayer();
        if (gm == GameType.CREATIVE || gm == GameType.SPECTATOR) return;

        // a) Contaminated item check
        if (FoodborneConfig.ITEM_CONTAMINATION_ENABLED.get()) {
            applyContaminationExposure(player, stack);
        }

        // b) ToughAsNails dirty water check
        if (FoodborneConfig.DIRTY_WATER_EXPOSURE_ENABLED.get() && isDirtyWater(stack)) {
            applyDirtyWaterExposure(player, stack);
        }

        // c) Vanilla water bottle check (15% chance, unfiltered natural water)
        if (FoodborneConfig.WATER_BOTTLE_EXPOSURE_ENABLED.get() && isVanillaWaterBottle(stack)) {
            applyWaterBottleExposure(player);
        }

        // d) Rotten flesh check
        if (FoodborneConfig.ROTTEN_FLESH_EXPOSURE_ENABLED.get() && isRottenFlesh(stack)) {
            applyRottenFleshExposure(player, stack);
        }
    }

    private static void applyContaminationExposure(ServerPlayer player, ItemStack stack) {
        CompoundTag tag = stack.getTag();
        if (tag == null || !tag.contains(CONTAM_NBT_KEY, net.minecraft.nbt.Tag.TAG_LIST)) return;

        ListTag list = tag.getList(CONTAM_NBT_KEY, net.minecraft.nbt.Tag.TAG_STRING);
        if (list.isEmpty()) return;

        for (int i = 0; i < list.size(); i++) {
            String virusId = list.getString(i);
            if (VirusManager.isInfected(player, virusId)) continue;

            double chance = FoodborneConfig.ITEM_CONTAMINATION_CHANCE.get();
            if (RNG.nextDouble() < chance) {
                VirusRegistry.get(virusId).ifPresent(virus -> {
                    VirusManager.infect(player, virus);
                    // Silent — no message. Player discovers via symptoms.
                    PathologyMod.LOGGER.debug("Player {} exposed to {} via contaminated item (silent)",
                        player.getName().getString(), virusId);
                });
            }
        }
    }

    private static void applyDirtyWaterExposure(ServerPlayer player, ItemStack stack) {
        double chance = FoodborneConfig.DIRTY_WATER_AIRBORNE_CHANCE.get();
        if (RNG.nextDouble() >= chance) return;

        String virusId = pickWaterborneVirus();
        if (virusId == null || VirusManager.isInfected(player, virusId)) return;

        VirusRegistry.get(virusId).ifPresent(virus -> {
            VirusManager.infect(player, virus);
            PathologyMod.LOGGER.debug("Player {} exposed to {} via TAN dirty water (silent)",
                player.getName().getString(), virusId);
        });
    }

    /**
     * Vanilla water bottle exposure — 15% chance of a random waterborne illness.
     * Natural water is not purified and carries ambient pathogens.
     */
    private static void applyWaterBottleExposure(ServerPlayer player) {
        double chance = FoodborneConfig.WATER_BOTTLE_EXPOSURE_CHANCE.get();
        if (RNG.nextDouble() >= chance) return;

        String virusId = pickWaterborneVirus();
        if (virusId == null || VirusManager.isInfected(player, virusId)) return;

        VirusRegistry.get(virusId).ifPresent(virus -> {
            VirusManager.infect(player, virus);
            // Silent — no message, no hint. Player finds out when they feel sick.
            PathologyMod.LOGGER.debug("Player {} exposed to {} via vanilla water bottle (silent)",
                player.getName().getString(), virusId);
        });
    }

    /**
     * Picks a random registered waterborne illness from the pool.
     * Falls back to airbornehuskflu if nothing else is registered.
     */
    public static String pickWaterborneVirus() {
        List<String> available = new ArrayList<>();
        for (String id : WATERBORNE_POOL) {
            if (VirusRegistry.exists(id)) available.add(id);
        }
        if (available.isEmpty()) return "airbornehuskflu";
        return available.get(RNG.nextInt(available.size()));
    }

    /** Returns the full waterborne pool (for debug commands). */
    public static String[] getWaterbornePool() { return WATERBORNE_POOL; }

    /** Returns all dirty-water item IDs (for debug commands). */
    public static List<String> getDirtyWaterItems() { return DIRTY_WATER_ITEMS; }

    private static void applyRottenFleshExposure(ServerPlayer player, ItemStack stack) {
        double chance = FoodborneConfig.ROTTEN_FLESH_BLOODBORNE_CHANCE.get();
        if (RNG.nextDouble() >= chance) return;

        String virusId = "bloodbornehuskvirus";
        if (VirusManager.isInfected(player, virusId)) return;

        VirusRegistry.get(virusId).ifPresent(virus -> {
            VirusManager.infect(player, virus);
            PathologyMod.LOGGER.debug("Player {} exposed to bloodbornehuskvirus via rotten flesh (silent)",
                player.getName().getString());
        });
    }

    // ── Tooltip helper ────────────────────────────────────────────────────────

    /**
     * Returns an empty list — contamination is intentionally hidden from players.
     * The method is kept for API compatibility but no longer emits tooltip lines.
     */
    public static List<net.minecraft.network.chat.Component> getContaminationTooltip(ItemStack stack) {
        return new ArrayList<>();
    }
}
