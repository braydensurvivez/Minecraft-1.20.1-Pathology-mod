package com.pathology.mod.client;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.common.Mod;

/**
 * Client-side Forge event handlers for Pathology.
 *
 * NOTE: The contamination tooltip has been intentionally removed.
 * Uninformed players will not see any "Contaminated" hint when hovering
 * over infected items — discovery happens through gameplay consequence only.
 */
@Mod.EventBusSubscriber(modid = com.pathology.mod.PathologyMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public class ClientEvents {
    // Tooltip handler intentionally absent — contamination is hidden from uninformed players.
}
