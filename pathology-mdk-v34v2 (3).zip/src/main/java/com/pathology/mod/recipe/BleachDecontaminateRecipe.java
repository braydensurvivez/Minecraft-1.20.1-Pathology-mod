package com.pathology.mod.recipe;

import com.google.gson.JsonObject;
import com.pathology.mod.infection.FoodborneHandler;
import com.pathology.mod.item.ModItems;
import net.minecraft.core.RegistryAccess;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.GsonHelper;
import net.minecraft.world.inventory.CraftingContainer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.CraftingBookCategory;
import net.minecraft.world.item.crafting.CustomRecipe;
import net.minecraft.world.item.crafting.RecipeSerializer;
import net.minecraft.world.level.Level;

/**
 * BleachDecontaminateRecipe — special crafting recipe for Forge 47.x / MC 1.20.1.
 *
 * Matches: exactly 1x Bleach + exactly 1x item tagged with
 * {@code pathology_contaminated_viruses}, all other slots empty.
 *
 * Result: a clean copy of the contaminated item with the contamination NBT removed.
 */
public class BleachDecontaminateRecipe extends CustomRecipe {

    public BleachDecontaminateRecipe(ResourceLocation id, CraftingBookCategory category) {
        super(id, category);
    }

    @Override
    public boolean matches(CraftingContainer inv, Level level) {
        boolean foundBleach = false;
        boolean foundContaminated = false;

        for (int i = 0; i < inv.getContainerSize(); i++) {
            ItemStack stack = inv.getItem(i);
            if (stack.isEmpty()) continue;

            if (stack.getItem() == ModItems.BLEACH.get()) {
                if (foundBleach) return false;
                foundBleach = true;
            } else if (isContaminated(stack)) {
                if (foundContaminated) return false;
                foundContaminated = true;
            } else {
                return false; // unexpected item in grid
            }
        }

        return foundBleach && foundContaminated;
    }

    @Override
    public ItemStack assemble(CraftingContainer inv, RegistryAccess registryAccess) {
        for (int i = 0; i < inv.getContainerSize(); i++) {
            ItemStack stack = inv.getItem(i);
            if (!stack.isEmpty()
                    && stack.getItem() != ModItems.BLEACH.get()
                    && isContaminated(stack)) {
                ItemStack clean = stack.copy();
                clean.setCount(1);
                CompoundTag tag = clean.getTag();
                if (tag != null) {
                    tag.remove(FoodborneHandler.CONTAM_NBT_KEY);
                    if (tag.isEmpty()) clean.setTag(null);
                }
                return clean;
            }
        }
        return ItemStack.EMPTY;
    }

    @Override
    public boolean canCraftInDimensions(int width, int height) {
        return width * height >= 2;
    }

    @Override
    public RecipeSerializer<?> getSerializer() {
        return ModRecipes.BLEACH_DECONTAMINATE.get();
    }

    // ── Helpers ──────────────────────────────────────────────────────────────

    private static boolean isContaminated(ItemStack stack) {
        if (stack.isEmpty()) return false;
        CompoundTag tag = stack.getTag();
        return tag != null && tag.contains(FoodborneHandler.CONTAM_NBT_KEY);
    }

    // ── Serializer (Forge 47.x style) ────────────────────────────────────────

    public static final class Serializer implements RecipeSerializer<BleachDecontaminateRecipe> {

        @Override
        public BleachDecontaminateRecipe fromJson(ResourceLocation id, JsonObject json) {
            CraftingBookCategory category = CraftingBookCategory.CODEC
                .byName(GsonHelper.getAsString(json, "category", null),
                        CraftingBookCategory.MISC);
            return new BleachDecontaminateRecipe(id, category);
        }

        @Override
        public BleachDecontaminateRecipe fromNetwork(ResourceLocation id, FriendlyByteBuf buf) {
            CraftingBookCategory category = buf.readEnum(CraftingBookCategory.class);
            return new BleachDecontaminateRecipe(id, category);
        }

        @Override
        public void toNetwork(FriendlyByteBuf buf, BleachDecontaminateRecipe recipe) {
            buf.writeEnum(recipe.category());
        }
    }
}
