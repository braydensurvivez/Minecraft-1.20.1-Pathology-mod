package com.pathology.mod.recipe;

import com.pathology.mod.PathologyMod;
import net.minecraft.world.item.crafting.RecipeSerializer;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModRecipes {

    public static final DeferredRegister<RecipeSerializer<?>> RECIPE_SERIALIZERS =
        DeferredRegister.create(ForgeRegistries.RECIPE_SERIALIZERS, PathologyMod.MOD_ID);

    public static final RegistryObject<RecipeSerializer<BleachDecontaminateRecipe>> BLEACH_DECONTAMINATE =
        RECIPE_SERIALIZERS.register("bleach_decontaminate",
            BleachDecontaminateRecipe.Serializer::new);
}
