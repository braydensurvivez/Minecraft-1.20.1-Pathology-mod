package com.pathology.mod.item;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

import javax.annotation.Nullable;
import java.util.List;

/**
 * Bleach — a disinfectant item.
 *
 * Crafting: combine Bleach with any contaminated item in a crafting grid
 * (shapeless, any slot). The contamination tags ({@code pathology_contaminated_viruses})
 * are stripped from the item and a clean copy is returned.
 *
 * The bleach itself is consumed in the process.
 *
 * Crafted from: 1x Water Bucket + 1x Sand (bleaching powder, simple recipe)
 */
public class BleachItem extends Item {

    public BleachItem(Properties props) {
        super(props);
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level,
                                List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.literal("A powerful disinfectant.")
            .withStyle(ChatFormatting.GRAY));
        tooltip.add(Component.literal("Combine with a contaminated item")
            .withStyle(ChatFormatting.DARK_GRAY));
        tooltip.add(Component.literal("in a crafting grid to purify it.")
            .withStyle(ChatFormatting.DARK_GRAY));
    }
}
