package com.pathology.mod.item;

import com.pathology.mod.PathologyMod;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import com.pathology.mod.item.FlameThrowerItem;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

public class ModCreativeTab {

    public static final DeferredRegister<CreativeModeTab> CREATIVE_TABS =
        DeferredRegister.create(Registries.CREATIVE_MODE_TAB, PathologyMod.MOD_ID);

    public static final RegistryObject<CreativeModeTab> PATHOLOGY_TAB =
        CREATIVE_TABS.register("pathology_tab", () ->
            CreativeModeTab.builder()
                .title(Component.literal("Pathology"))
                .icon(() -> new ItemStack(ModItems.PATHOGEN_SYRINGE.get()))
                .displayItems((params, output) -> {
                    // Syringe
                    output.accept(ModItems.PATHOGEN_SYRINGE.get());

                    ItemStack influenzaSyringe = new ItemStack(ModItems.PATHOGEN_SYRINGE.get());
                    PathogenSyringeItem.setLoadedVirus(influenzaSyringe, "influenza");
                    influenzaSyringe.setHoverName(Component.literal("Syringe [influenza]"));
                    output.accept(influenzaSyringe);

                    // Virus Vials
                    for (String virusId : new String[]{"influenza", "airbornehuskflu", "bloodbornehuskvirus"}) {
                        ItemStack vial = new ItemStack(ModItems.VIRUS_VIAL.get());
                        VirusVialItem.setLoadedVirus(vial, virusId);
                        vial.setHoverName(Component.literal("Vial [" + virusId + "]"));
                        output.accept(vial);
                    }

                    // Body Bag – for picking up and relocating corpses
                    output.accept(ModItems.BODY_BAG.get());

                    // Diagnostic Tools
                    output.accept(ModItems.DIGITAL_THERMOMETER.get());
                    output.accept(ModItems.FIELD_ASSESSMENT_KIT.get());

                    // Flamethrower + Fuel
                    ItemStack thrower = new ItemStack(ModItems.FLAME_THROWER.get());
                    FlameThrowerItem.setFuel(thrower, FlameThrowerItem.MAX_FUEL);
                    thrower.setHoverName(Component.literal("Flamethrower (Full)"));
                    output.accept(thrower);
                    output.accept(ModItems.FLAME_FUEL.get());

                    // Bleach - decontaminates contaminated items
                    output.accept(ModItems.BLEACH.get());
                })
                .build()
        );
}
