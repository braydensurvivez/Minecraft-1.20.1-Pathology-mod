package com.pathology.mod.virus;

import com.pathology.mod.config.VirusConfig;
import com.pathology.mod.corpse.DecayDisease;
import net.minecraft.world.effect.MobEffects;

import java.util.*;

/**
 * Central virus registry.
 *
 * Built-in (protected, cannot be deleted):
 *   influenza, airbornehuskflu, bloodbornehuskvirus, decay_disease
 *
 * New viruses (randomly occurring, varying severity):
 *   swine_flu     – mild, airborne, pig/piglin vector. Silent incubation, never escalates past amplifier I.
 *   necrotica     – severe, bleeding+vomit, wound/necrotic-tissue vector. Sepsis-style 4-stage escalation.
 *   bone_fever    – medium, airborne, skeleton vector. Rheumatic-fever-style joint/fatigue illness.
 *   creeper_toxin – medium-severe, bloodborne, toxin/envenomation vector. Near-instant onset, neurotoxic crisis.
 *   swamp_fever   – mild-medium, airborne+vomit, witch/swamp vector. Mosquito-fever-style chills/fatigue/nausea.
 *
 * All five secondary viruses now open with a genuinely asymptomatic
 * incubation stage (no effects) before any symptom appears, mirroring how
 * real infections/illnesses are picked up well before they're noticeable —
 * this also keeps exposure silent and undetectable until the body actually
 * starts reacting, consistent with the rest of the mod's "no infection
 * pop-ups" design.
 */
public class VirusRegistry {

    // ── MutableVirus ──────────────────────────────────────────────────────────
    public static class MutableVirus extends Virus {
        private double mAirborneRadius, mAirborneChance;
        private double mBloodborneRadius, mBloodborneChance;
        private int    mBloodborneDurationTicks;
        private int    mBleedingIntervalTicks;
        private double mBleedingZoneRadius;
        private int    mBleedingZoneDurationTicks;
        private double mBleedingInfectChance;
        private int    mVomitIntervalTicks;
        private double mVomitFireChance, mVomitInfectChance, mVomitSplashRadius;
        private final List<InfectionStage> mStages;
        private final List<InfectionType>  mTypes;

        public MutableVirus(Virus b) {
            super(b.getId(), b.getStages(), b.getInfectionTypes(),
                  b.getAirborneRadius(), b.getAirborneChance(),
                  b.getBloodborneRadius(), b.getBloodborneChance(), b.getBloodborneDurationTicks(),
                  b.getBleedingIntervalTicks(), b.getBleedingZoneRadius(),
                  b.getBleedingZoneDurationTicks(), b.getBleedingInfectChance(),
                  b.getVomitIntervalTicks(), b.getVomitFireChance(),
                  b.getVomitInfectChance(), b.getVomitSplashRadius());
            mStages = new ArrayList<>(b.getStages());
            mTypes  = new ArrayList<>(b.getInfectionTypes());
            mAirborneRadius          = b.getAirborneRadius();
            mAirborneChance          = b.getAirborneChance();
            mBloodborneRadius        = b.getBloodborneRadius();
            mBloodborneChance        = b.getBloodborneChance();
            mBloodborneDurationTicks = b.getBloodborneDurationTicks();
            mBleedingIntervalTicks   = b.getBleedingIntervalTicks();
            mBleedingZoneRadius      = b.getBleedingZoneRadius();
            mBleedingZoneDurationTicks = b.getBleedingZoneDurationTicks();
            mBleedingInfectChance    = b.getBleedingInfectChance();
            mVomitIntervalTicks      = b.getVomitIntervalTicks();
            mVomitFireChance         = b.getVomitFireChance();
            mVomitInfectChance       = b.getVomitInfectChance();
            mVomitSplashRadius       = b.getVomitSplashRadius();
        }

        @Override public List<InfectionStage> getStages()         { return mStages; }
        @Override public List<InfectionType>  getInfectionTypes() { return mTypes; }
        @Override public double getAirborneRadius()               { return mAirborneRadius; }
        @Override public double getAirborneChance()               { return mAirborneChance; }
        @Override public double getBloodborneRadius()             { return mBloodborneRadius; }
        @Override public double getBloodborneChance()             { return mBloodborneChance; }
        @Override public int    getBloodborneDurationTicks()      { return mBloodborneDurationTicks; }
        @Override public int    getBleedingIntervalTicks()        { return mBleedingIntervalTicks; }
        @Override public double getBleedingZoneRadius()           { return mBleedingZoneRadius; }
        @Override public int    getBleedingZoneDurationTicks()    { return mBleedingZoneDurationTicks; }
        @Override public double getBleedingInfectChance()         { return mBleedingInfectChance; }
        @Override public int    getVomitIntervalTicks()           { return mVomitIntervalTicks; }
        @Override public double getVomitFireChance()              { return mVomitFireChance; }
        @Override public double getVomitInfectChance()            { return mVomitInfectChance; }
        @Override public double getVomitSplashRadius()            { return mVomitSplashRadius; }
        @Override public boolean isAirborne()   { return mTypes.contains(InfectionType.AIRBORNE); }
        @Override public boolean isBloodborne() { return mTypes.contains(InfectionType.BLOODBORNE); }
        @Override public boolean isBleeding()   { return mTypes.contains(InfectionType.BLEEDING); }
        @Override public boolean isVomit()      { return mTypes.contains(InfectionType.VOMIT); }

        public void setAirborneRadius(double v)          { mAirborneRadius = v; }
        public void setAirborneChance(double v)          { mAirborneChance = v; }
        public void setBloodborneRadius(double v)        { mBloodborneRadius = v; }
        public void setBloodborneChance(double v)        { mBloodborneChance = v; }
        public void setBloodborneDurationTicks(int v)    { mBloodborneDurationTicks = v; }
        public void setBleedingIntervalTicks(int v)      { mBleedingIntervalTicks = v; }
        public void setBleedingZoneRadius(double v)      { mBleedingZoneRadius = v; }
        public void setBleedingZoneDurationTicks(int v)  { mBleedingZoneDurationTicks = v; }
        public void setBleedingInfectChance(double v)    { mBleedingInfectChance = v; }
        public void setVomitIntervalTicks(int v)         { mVomitIntervalTicks = v; }
        public void setVomitFireChance(double v)         { mVomitFireChance = v; }
        public void setVomitInfectChance(double v)       { mVomitInfectChance = v; }
        public void setVomitSplashRadius(double v)       { mVomitSplashRadius = v; }
        public void addVector(InfectionType t)           { if (!mTypes.contains(t)) mTypes.add(t); }
        public void removeVector(InfectionType t)        { mTypes.remove(t); }
        public void addStage(InfectionStage s)           { mStages.add(s); }
        public void setStage(int i, InfectionStage s)    { while (mStages.size() <= i) mStages.add(new InfectionStage(60*20, new ArrayList<>())); mStages.set(i, s); }
        public boolean removeStage(int i)                { if (i<0||i>=mStages.size()) return false; mStages.remove(i); return true; }
    }

    private static final Map<String, MutableVirus> REGISTRY = new LinkedHashMap<>();

    public static void reload() {
        REGISTRY.clear();
        // ── Core built-ins ────────────────────────────────────────────────────
        registerInfluenza();
        registerAirborneHuskFlu();
        registerBloodborneHuskVirus();
        registerDecayDisease();
        // ── New randomly-occurring viruses ────────────────────────────────────
        registerSwineFlu();
        registerNecrotica();
        registerBoneFever();
        registerCreeperToxin();
        registerSwampFever();
    }

    // ══════════════════════════════════════════════════════════════════════════
    // Core built-in viruses
    // ══════════════════════════════════════════════════════════════════════════

    private static void registerDecayDisease() {
        InfectionStage s1 = new InfectionStage(30 * 20, new ArrayList<>());
        InfectionStage s2 = new InfectionStage(60 * 20,
            List.of(
                new InfectionStage.StagedEffect(MobEffects.WEAKNESS,  0),
                new InfectionStage.StagedEffect(MobEffects.MOVEMENT_SLOWDOWN, 0)
            ));
        InfectionStage s3 = new InfectionStage(90 * 20,
            List.of(
                new InfectionStage.StagedEffect(MobEffects.WITHER,    0),
                new InfectionStage.StagedEffect(MobEffects.WEAKNESS,  1),
                new InfectionStage.StagedEffect("hordes:infected",    0)
            ));
        List<Virus.InfectionType> types = List.of(Virus.InfectionType.BLOODBORNE);
        REGISTRY.put(DecayDisease.VIRUS_ID, new MutableVirus(new Virus(
            DecayDisease.VIRUS_ID,
            List.of(s1, s2, s3), types,
            0.0, 0.0,
            4.0, 0.50, 5 * 20,
            0, 0.0, 0, 0.0,
            0, 0.0, 0.0, 0.0
        )));
    }

    private static void registerInfluenza() {
        List<InfectionStage> stages = new ArrayList<>();
        stages.add(InfectionStage.buildDefault(0, VirusConfig.INFLUENZA_STAGE1_DURATION.get() * 20));
        stages.add(InfectionStage.buildDefault(1, VirusConfig.INFLUENZA_STAGE2_DURATION.get() * 20));
        stages.add(InfectionStage.buildDefault(2, VirusConfig.INFLUENZA_STAGE3_DURATION.get() * 20));
        List<Virus.InfectionType> types = new ArrayList<>();
        if (VirusConfig.INFLUENZA_AIRBORNE.get())   types.add(Virus.InfectionType.AIRBORNE);
        if (VirusConfig.INFLUENZA_BLOODBORNE.get()) types.add(Virus.InfectionType.BLOODBORNE);
        if (VirusConfig.INFLUENZA_BLEEDING.get())   types.add(Virus.InfectionType.BLEEDING);
        if (VirusConfig.INFLUENZA_VOMIT.get())      types.add(Virus.InfectionType.VOMIT);
        REGISTRY.put("influenza", new MutableVirus(new Virus("influenza", stages, types,
            VirusConfig.INFLUENZA_AIRBORNE_RADIUS.get(), VirusConfig.INFLUENZA_AIRBORNE_CHANCE.get(),
            VirusConfig.INFLUENZA_BLOODBORNE_RADIUS.get(), VirusConfig.INFLUENZA_BLOODBORNE_CHANCE.get(),
            VirusConfig.INFLUENZA_BLOODBORNE_CLOUD_DURATION.get() * 20,
            VirusConfig.INFLUENZA_BLEEDING_INTERVAL.get() * 20,
            VirusConfig.INFLUENZA_BLEEDING_ZONE_RADIUS.get(),
            VirusConfig.INFLUENZA_BLEEDING_ZONE_DURATION.get() * 20,
            VirusConfig.INFLUENZA_BLEEDING_INFECT_CHANCE.get(),
            VirusConfig.INFLUENZA_VOMIT_INTERVAL.get() * 20,
            VirusConfig.INFLUENZA_VOMIT_FIRE_CHANCE.get(),
            VirusConfig.INFLUENZA_VOMIT_INFECT_CHANCE.get(),
            VirusConfig.INFLUENZA_VOMIT_SPLASH_RADIUS.get())));
    }

    private static void registerAirborneHuskFlu() {
        InfectionStage s1 = new InfectionStage(VirusConfig.AIRBORNE_HUSKFLU_S1_DURATION.get() * 20,
            List.of(new InfectionStage.StagedEffect(MobEffects.HUNGER, 0)));
        InfectionStage s2 = new InfectionStage(VirusConfig.AIRBORNE_HUSKFLU_S2_DURATION.get() * 20,
            List.of(
                new InfectionStage.StagedEffect(MobEffects.CONFUSION, 0),
                new InfectionStage.StagedEffect(MobEffects.WEAKNESS, 0)
            ));
        InfectionStage s3 = new InfectionStage(VirusConfig.AIRBORNE_HUSKFLU_S3_DURATION.get() * 20,
            List.of(
                new InfectionStage.StagedEffect(MobEffects.CONFUSION, 1),
                new InfectionStage.StagedEffect(MobEffects.WEAKNESS, 1),
                new InfectionStage.StagedEffect("hordes:infected", 0)
            ));
        List<Virus.InfectionType> types = List.of(Virus.InfectionType.AIRBORNE);
        REGISTRY.put("airbornehuskflu", new MutableVirus(new Virus("airbornehuskflu",
            List.of(s1, s2, s3), types,
            VirusConfig.AIRBORNE_HUSKFLU_AIRBORNE_RADIUS.get(),
            VirusConfig.AIRBORNE_HUSKFLU_AIRBORNE_CHANCE.get(),
            0.0, 0.0, 0,
            0, 0.0, 0, 0.0,
            0, 0.0, 0.0, 0.0)));
    }

    private static void registerBloodborneHuskVirus() {
        InfectionStage s1 = new InfectionStage(VirusConfig.BLOODBORNE_HUSKVIRUS_S1_DURATION.get() * 20,
            List.of(new InfectionStage.StagedEffect(MobEffects.HUNGER, 0)));
        InfectionStage s2 = new InfectionStage(VirusConfig.BLOODBORNE_HUSKVIRUS_S2_DURATION.get() * 20,
            List.of(
                new InfectionStage.StagedEffect(MobEffects.WEAKNESS, 0),
                new InfectionStage.StagedEffect(MobEffects.MOVEMENT_SLOWDOWN, 0)
            ));
        InfectionStage s3 = new InfectionStage(VirusConfig.BLOODBORNE_HUSKVIRUS_S2_DURATION.get() * 20,
            List.of(
                new InfectionStage.StagedEffect(MobEffects.WEAKNESS, 1),
                new InfectionStage.StagedEffect(MobEffects.MOVEMENT_SLOWDOWN, 1),
                new InfectionStage.StagedEffect("hordes:infected", 0)
            ));
        List<Virus.InfectionType> types = new ArrayList<>(List.of(Virus.InfectionType.BLOODBORNE, Virus.InfectionType.VOMIT));
        REGISTRY.put("bloodbornehuskvirus", new MutableVirus(new Virus("bloodbornehuskvirus",
            List.of(s1, s2, s3), types,
            0.0, 0.0,
            VirusConfig.BLOODBORNE_HUSKVIRUS_BLOODBORNE_RADIUS.get(),
            VirusConfig.BLOODBORNE_HUSKVIRUS_BLOODBORNE_CHANCE.get(),
            VirusConfig.BLOODBORNE_HUSKVIRUS_BLOODBORNE_CLOUD_DURATION.get() * 20,
            0, 0.0, 0, 0.0,
            200, 0.8, 1.0, 2.0)));
    }

    // ══════════════════════════════════════════════════════════════════════════
    // New randomly-occurring viruses
    // ══════════════════════════════════════════════════════════════════════════

    /**
     * SWINE FLU — Mild severity.  Airborne.
     * Primary vector: pigs and piglins.  Models a real seasonal-flu-style
     * zoonotic infection in an otherwise healthy adult: a silent incubation
     * window, then mild malaise that never escalates past amplifier I before
     * the body clears it on its own.
     * Stage 1 (50 s) : (none)              — incubation, no detectable symptoms
     * Stage 2 (60 s) : Hunger I             — appetite loss, early fatigue
     * Stage 3 (70 s) : Hunger I, Weakness I — body aches, mild fever malaise
     * Airborne radius 8, chance 5%.
     */
    private static void registerSwineFlu() {
        InfectionStage s1 = new InfectionStage(50 * 20, new ArrayList<>());
        InfectionStage s2 = new InfectionStage(60 * 20,
            List.of(new InfectionStage.StagedEffect(MobEffects.HUNGER, 0)));
        InfectionStage s3 = new InfectionStage(70 * 20,
            List.of(
                new InfectionStage.StagedEffect(MobEffects.HUNGER, 0),
                new InfectionStage.StagedEffect(MobEffects.WEAKNESS, 0)
            ));
        REGISTRY.put("swine_flu", new MutableVirus(new Virus("swine_flu",
            List.of(s1, s2, s3), List.of(Virus.InfectionType.AIRBORNE),
            /* airborne   */ 8.0, 0.05,
            /* bloodborne */ 0.0, 0.0, 0,
            /* bleeding   */ 0, 0.0, 0, 0.0,
            /* vomit      */ 0, 0.0, 0.0, 0.0)));
    }

    /**
     * NECROTICA — Severe.  Bleeding + Vomit.
     * Models a wound infection that progresses to sepsis: contact with
     * necrotic tissue seeds bacteria into the bloodstream through an open
     * wound, which (unlike an airborne cold) takes hold fast and worsens in
     * clear, escalating stages rather than spiking straight to crisis.
     * Stage 1 (20 s) : (none)                                  — short incubation, wound looks clean
     * Stage 2 (45 s) : Weakness I, Poison I                     — localized infection, low-grade toxins
     * Stage 3 (70 s) : Weakness I, Slowness I, Poison I, Nausea — infection spreading, fever delirium
     * Stage 4 (90 s) : Wither I, Weakness II, Slowness I, Poison I — septic crisis, tissue necrosis
     * Bleeding interval 10 s, bleeding-zone infect chance 15%.
     * Vomit every 15 s (70% fire chance, 90% infect chance).
     */
    private static void registerNecrotica() {
        InfectionStage s1 = new InfectionStage(20 * 20, new ArrayList<>());
        InfectionStage s2 = new InfectionStage(45 * 20,
            List.of(
                new InfectionStage.StagedEffect(MobEffects.WEAKNESS, 0),
                new InfectionStage.StagedEffect(MobEffects.POISON, 0)
            ));
        InfectionStage s3 = new InfectionStage(70 * 20,
            List.of(
                new InfectionStage.StagedEffect(MobEffects.WEAKNESS, 0),
                new InfectionStage.StagedEffect(MobEffects.MOVEMENT_SLOWDOWN, 0),
                new InfectionStage.StagedEffect(MobEffects.POISON, 0),
                new InfectionStage.StagedEffect(MobEffects.CONFUSION, 0)
            ));
        InfectionStage s4 = new InfectionStage(90 * 20,
            List.of(
                new InfectionStage.StagedEffect(MobEffects.WITHER, 0),
                new InfectionStage.StagedEffect(MobEffects.WEAKNESS, 1),
                new InfectionStage.StagedEffect(MobEffects.MOVEMENT_SLOWDOWN, 0),
                new InfectionStage.StagedEffect(MobEffects.POISON, 0)
            ));
        List<Virus.InfectionType> types = List.of(Virus.InfectionType.BLEEDING, Virus.InfectionType.VOMIT);
        REGISTRY.put("necrotica", new MutableVirus(new Virus("necrotica",
            List.of(s1, s2, s3, s4), types,
            /* airborne   */ 0.0, 0.0,
            /* bloodborne */ 0.0, 0.0, 0,
            /* bleeding   */ 200, 2.0, 160, 0.15,
            /* vomit      */ 300, 0.70, 0.90, 2.5)));
    }

    /**
     * BONE FEVER — Medium severity.  Airborne.
     * Carried by skeletons and strays.  Models a rheumatic-fever-style
     * illness: joint inflammation and deep fatigue rather than anything
     * affecting the eyes — vision loss has no real connection to joint or
     * skeletal pain, so it has been replaced with appetite loss consistent
     * with a sustained low-grade fever.
     * Stage 1 (50 s) : (none)                              — incubation
     * Stage 2 (60 s) : Slowness I                           — stiffening joints
     * Stage 3 (60 s) : Slowness I, Weakness I                — deep ache, heavy limbs
     * Stage 4 (60 s) : Slowness I, Weakness I, Mining Fatigue I, Hunger I — feverish, joints locking up
     * Airborne radius 6, chance 8%.
     */
    private static void registerBoneFever() {
        InfectionStage s1 = new InfectionStage(50 * 20, new ArrayList<>());
        InfectionStage s2 = new InfectionStage(60 * 20,
            List.of(new InfectionStage.StagedEffect(MobEffects.MOVEMENT_SLOWDOWN, 0)));
        InfectionStage s3 = new InfectionStage(60 * 20,
            List.of(
                new InfectionStage.StagedEffect(MobEffects.MOVEMENT_SLOWDOWN, 0),
                new InfectionStage.StagedEffect(MobEffects.WEAKNESS, 0)
            ));
        InfectionStage s4 = new InfectionStage(60 * 20,
            List.of(
                new InfectionStage.StagedEffect(MobEffects.MOVEMENT_SLOWDOWN, 0),
                new InfectionStage.StagedEffect(MobEffects.WEAKNESS, 0),
                new InfectionStage.StagedEffect(MobEffects.DIG_SLOWDOWN, 0),
                new InfectionStage.StagedEffect(MobEffects.HUNGER, 0)
            ));
        REGISTRY.put("bone_fever", new MutableVirus(new Virus("bone_fever",
            List.of(s1, s2, s3, s4), List.of(Virus.InfectionType.AIRBORNE),
            /* airborne   */ 6.0, 0.08,
            /* bloodborne */ 0.0, 0.0, 0,
            /* bleeding   */ 0, 0.0, 0, 0.0,
            /* vomit      */ 0, 0.0, 0.0, 0.0)));
    }

    /**
     * CREEPER TOXIN — Medium-severe.  Bloodborne.
     * Models acute envenomation/chemical poisoning: unlike an infection,
     * toxins absorbed directly into the bloodstream act almost immediately
     * (no meaningful incubation) and the dose response is roughly linear,
     * building from a localized sting to systemic neurotoxic effects —
     * blurred vision is a documented symptom of real neurotoxin exposure,
     * so it is kept here (and only here) rather than on the joint-pain virus.
     * Stage 1 (10 s) : Poison I                            — sting takes hold almost immediately
     * Stage 2 (45 s) : Poison I, Weakness I                — toxin spreading through the bloodstream
     * Stage 3 (60 s) : Poison I, Weakness I, Confusion      — neurotoxic disorientation
     * Stage 4 (60 s) : Poison I, Weakness I, Blindness      — neurotoxic vision impairment, crisis
     * Bloodborne radius 3, chance 35%.
     */
    private static void registerCreeperToxin() {
        InfectionStage s1 = new InfectionStage(10 * 20,
            List.of(new InfectionStage.StagedEffect(MobEffects.POISON, 0)));
        InfectionStage s2 = new InfectionStage(45 * 20,
            List.of(
                new InfectionStage.StagedEffect(MobEffects.POISON, 0),
                new InfectionStage.StagedEffect(MobEffects.WEAKNESS, 0)
            ));
        InfectionStage s3 = new InfectionStage(60 * 20,
            List.of(
                new InfectionStage.StagedEffect(MobEffects.POISON, 0),
                new InfectionStage.StagedEffect(MobEffects.WEAKNESS, 0),
                new InfectionStage.StagedEffect(MobEffects.CONFUSION, 0)
            ));
        InfectionStage s4 = new InfectionStage(60 * 20,
            List.of(
                new InfectionStage.StagedEffect(MobEffects.POISON, 0),
                new InfectionStage.StagedEffect(MobEffects.WEAKNESS, 0),
                new InfectionStage.StagedEffect(MobEffects.BLINDNESS, 0)
            ));
        REGISTRY.put("creeper_toxin", new MutableVirus(new Virus("creeper_toxin",
            List.of(s1, s2, s3, s4), List.of(Virus.InfectionType.BLOODBORNE),
            /* airborne   */ 0.0, 0.0,
            /* bloodborne */ 3.0, 0.35, 4 * 20,
            /* bleeding   */ 0, 0.0, 0, 0.0,
            /* vomit      */ 0, 0.0, 0.0, 0.0)));
    }

    /**
     * SWAMP FEVER — Mild-medium severity.  Airborne + Vomit.
     * Endemic to swamp biomes; carried by witches and slimes.  Models a
     * mosquito-borne tropical fever (malaria/typhoid-like): a longer
     * incubation window, then a chills-fatigue-nausea progression that
     * matches how those illnesses actually present.
     * Stage 1 (60 s) : (none)                                — incubation
     * Stage 2 (60 s) : Hunger I, Slowness I                   — chills and fatigue
     * Stage 3 (75 s) : Hunger I, Weakness I, Confusion        — fever sweats, disorientation
     * Stage 4 (60 s) : Weakness I, Confusion, Nausea (vomit)  — fever peak
     * Airborne radius 7, chance 6%.  Vomit every 400 ticks (30% fire chance, 60% infect).
     */
    private static void registerSwampFever() {
        InfectionStage s1 = new InfectionStage(60 * 20, new ArrayList<>());
        InfectionStage s2 = new InfectionStage(60 * 20,
            List.of(
                new InfectionStage.StagedEffect(MobEffects.HUNGER, 0),
                new InfectionStage.StagedEffect(MobEffects.MOVEMENT_SLOWDOWN, 0)
            ));
        InfectionStage s3 = new InfectionStage(75 * 20,
            List.of(
                new InfectionStage.StagedEffect(MobEffects.HUNGER, 0),
                new InfectionStage.StagedEffect(MobEffects.WEAKNESS, 0),
                new InfectionStage.StagedEffect(MobEffects.CONFUSION, 0)
            ));
        InfectionStage s4 = new InfectionStage(60 * 20,
            List.of(
                new InfectionStage.StagedEffect(MobEffects.WEAKNESS, 0),
                new InfectionStage.StagedEffect(MobEffects.CONFUSION, 0)
            ));
        List<Virus.InfectionType> types = List.of(Virus.InfectionType.AIRBORNE, Virus.InfectionType.VOMIT);
        REGISTRY.put("swamp_fever", new MutableVirus(new Virus("swamp_fever",
            List.of(s1, s2, s3, s4), types,
            /* airborne   */ 7.0, 0.06,
            /* bloodborne */ 0.0, 0.0, 0,
            /* bleeding   */ 0, 0.0, 0, 0.0,
            /* vomit      */ 400, 0.30, 0.60, 2.0)));
    }

    // ── Registry API ──────────────────────────────────────────────────────────

    public static Optional<Virus>   get(String id)       { return Optional.ofNullable(REGISTRY.get(id)); }
    public static MutableVirus      getMutable(String id) { return REGISTRY.get(id); }
    public static Collection<Virus> all()                { return Collections.unmodifiableCollection(REGISTRY.values()); }
    public static boolean           exists(String id)    { return REGISTRY.containsKey(id); }
    public static void              register(Virus v)    { REGISTRY.put(v.getId(), new MutableVirus(v)); }

    private static final Set<String> PROTECTED = Set.of(
        "influenza", "airbornehuskflu", "bloodbornehuskvirus", DecayDisease.VIRUS_ID
    );

    public static boolean remove(String id) {
        if (PROTECTED.contains(id)) return false;
        return REGISTRY.remove(id) != null;
    }

    public static void overrideAirborneRadius(String id, double v)   { MutableVirus m=REGISTRY.get(id); if(m!=null) m.setAirborneRadius(v); }
    public static void overrideAirborneChance(String id, double v)   { MutableVirus m=REGISTRY.get(id); if(m!=null) m.setAirborneChance(v); }
    public static void overrideBloodborneRadius(String id, double v) { MutableVirus m=REGISTRY.get(id); if(m!=null) m.setBloodborneRadius(v); }
    public static void overrideBloodborneChance(String id, double v) { MutableVirus m=REGISTRY.get(id); if(m!=null) m.setBloodborneChance(v); }
}
